/**
 * snapshot_writer.js
 * 
 * 职责：将 StockRecord[] 保存为 Parquet 文件
 * 职责边界：
 *   - 只负责写入，不做任何数据转换
 *   - 文件名必须为日期格式：YYYY-MM-DD.parquet
 *   - 目录结构：data/snapshot/YYYY/MM/
 * 
 * 接口契约：
 *   save(records, date) → { path, count }
 * 
 * 依赖：
 *   - parquetjs（npm install parquetjs）
 */

const fs = require('fs');
const path = require('path');
const { ParquetSchema, ParquetWriter } = require('parquetjs');

// Snapshot Parquet Schema（冻结 v1.0）
const SNAPSHOT_SCHEMA = new ParquetSchema({
  date:         { type: 'UTF8' },
  code:         { type: 'UTF8' },
  name:         { type: 'UTF8' },
  market:       { type: 'UTF8' },
  industry:     { type: 'UTF8' },
  close:        { type: 'DOUBLE' },
  change_pct:   { type: 'DOUBLE', optional: true },
  open:         { type: 'DOUBLE' },
  high:         { type: 'DOUBLE' },
  low:          { type: 'DOUBLE' },
  volume:       { type: 'DOUBLE' },
  amount:       { type: 'DOUBLE' },
  turnover:     { type: 'DOUBLE', optional: true },
  pe:           { type: 'DOUBLE', optional: true },
  pb:           { type: 'DOUBLE', optional: true },
  is_st:        { type: 'BOOLEAN' },
  is_suspend:   { type: 'BOOLEAN' }
});

class SnapshotWriter {
  constructor(config = {}) {
    this.dataRoot = config.dataRoot || path.join(__dirname, '../../data');
    this.snapshotDir = path.join(this.dataRoot, 'snapshot');
  }

  /**
   * 保存全市场快照
   * @param {StockRecord[]} records - 从 adapter 获取的标准化数据
   * @param {string} date - YYYY-MM-DD 格式日期
   * @returns {Promise<{path: string, count: number}>}
   */
  async save(records, date) {
    if (!records || records.length === 0) {
      throw new Error('保存失败：records 为空');
    }

    const dirPath = this._ensureDirectory(date);
    const filePath = path.join(dirPath, `${date}.parquet`);

    const writer = await ParquetWriter.openFile(SNAPSHOT_SCHEMA, filePath);

    for (const record of records) {
      await writer.appendRow({
        date:         record.date,
        code:         record.code,
        name:         record.name,
        market:       record.market,
        industry:     record.industry || '',
        close:        record.close,
        change_pct:   record.change_pct,
        open:         record.open,
        high:         record.high,
        low:          record.low,
        volume:       record.volume,
        amount:       record.amount,
        turnover:     record.turnover,
        pe:           record.pe,
        pb:           record.pb,
        is_st:        record.is_st,
        is_suspend:   record.is_suspend
      });
    }

    await writer.close();

    return {
      path: filePath,
      count: records.length
    };
  }

  /**
   * 确保目录存在，按年/月分目录
   * @param {string} date - YYYY-MM-DD
   * @returns {string} - 目录路径
   */
  _ensureDirectory(date) {
    const [year, month] = date.split('-');
    const dirPath = path.join(this.snapshotDir, year, month);
    fs.mkdirSync(dirPath, { recursive: true });
    return dirPath;
  }
}

module.exports = { SnapshotWriter };
