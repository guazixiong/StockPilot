/**
 * eastmoney_adapter.js
 * 
 * 职责：获取全市场实时行情数据
 * 职责边界：
 *   - 只负责 HTTP 请求 + JSON 解析 + 字段映射
 *   - 不做任何计算（breadth、涨跌统计等）
 *   - 不做数据清洗或异常判断
 * 
 * 数据源策略：
 *   - 股票列表：datacenter-web.eastmoney.com（无IP限制）
 *   - 行情数据：qt.gtimg.cn（腾讯行情，无IP限制，返回完整OHLCV）
 *   - 原因：push2.eastmoney.com 对云服务器IP有访问限制
 * 
 * 接口契约：
 *   fetchMarketSnapshot() → StockRecord[]
 */

const https = require('https');
const http = require('http');

class EastMoneyAdapter {
  constructor(config = {}) {
    this.timeout = config.timeout || 30000;
    this.batchSize = config.batchSize || 800;  // 腾讯接口每批最多约800只
  }

  /**
   * 获取沪深A股全市场实时行情
   * @returns {Promise<StockRecord[]>}
   */
  async fetchMarketSnapshot() {
    const today = this._getDateStr();

    // Step 1: 从 datacenter-web 获取全市场股票列表
    console.log('[Adapter] 获取股票列表...');
    const stockList = await this._fetchStockList();
    console.log(`[Adapter] 获取 ${stockList.length} 只股票`);

    // Step 2: 从腾讯行情接口批量获取行情数据
    console.log('[Adapter] 获取行情数据...');
    const records = await this._fetchQuotesBatch(stockList, today);
    console.log(`[Adapter] 获取 ${records.length} 条完整行情`);

    return records;
  }

  /**
   * 从东方财富 datacenter-web 获取全市场股票列表
   * 该接口无IP限制，返回 SECURITY_CODE + SECUCODE
   */
  async _fetchStockList() {
    const allStocks = [];
    let page = 1;
    const pageSize = 500;

    while (true) {
      const url = `https://datacenter-web.eastmoney.com/api/data/v1/get?reportName=RPT_DMSK_TS_STOCKNEW&columns=SECURITY_CODE,SECURITY_NAME_ABBR,SECUCODE,TRADE_MARKET_CODE&pageSize=${pageSize}&pageNumber=${page}&sortColumns=SECURITY_CODE&sortTypes=1`;
      
      const data = await this._httpGet(url);
      
      if (!data || !data.result || !data.result.data || data.result.data.length === 0) {
        break;
      }

      for (const item of data.result.data) {
        const secucode = item.SECUCODE || '';
        const parts = secucode.split('.');
        const code = item.SECURITY_CODE || parts[0] || '';
        const suffix = parts[1] || '';
        
        // 确定市场前缀（腾讯格式）
        let prefix = 'sz';
        if (suffix === 'SH') prefix = 'sh';
        else if (suffix === 'BJ') prefix = 'bj';

        allStocks.push({
          code: code,
          name: (item.SECURITY_NAME_ABBR || '').replace(/\s+/g, ''),
          market: suffix,
          tencentSymbol: `${prefix}${code}`
        });
      }

      // 检查是否还有更多页
      if (data.result.data.length < pageSize || page >= data.result.pages) {
        break;
      }
      page++;
    }

    return allStocks;
  }

  /**
   * 从腾讯行情接口批量获取行情数据
   * qt.gtimg.cn 支持批量查询，每批建议不超过800只
   */
  async _fetchQuotesBatch(stockList, date) {
    const allRecords = [];
    
    for (let i = 0; i < stockList.length; i += this.batchSize) {
      const batch = stockList.slice(i, i + this.batchSize);
      const symbols = batch.map(s => s.tencentSymbol).join(',');
      
      try {
        const records = await this._fetchQuotes(symbols, batch, date);
        allRecords.push(...records);
      } catch (err) {
        console.warn(`[Adapter] 批次 ${Math.floor(i/this.batchSize)+1} 失败: ${err.message}`);
      }
    }

    return allRecords;
  }

  /**
   * 请求腾讯行情接口
   * 返回格式：v_sh600519="1~贵州茅台~600519~1297.41~..."
   * 字段用 ~ 分隔
   */
  async _fetchQuotes(symbols, stockList, date) {
    const url = `http://qt.gtimg.cn/q=${symbols}`;
    const raw = await this._httpGetText(url);
    
    // 转换为UTF-8（腾讯返回GBK）
    const text = Buffer.isBuffer(raw) ? raw.toString('binary') : raw;
    
    // 解析每行
    const lines = text.split('\n').filter(l => l.includes('~'));
    const records = [];

    // 建立 code -> stockInfo 映射
    const stockMap = {};
    for (const s of stockList) {
      stockMap[s.code] = s;
    }

    for (const line of lines) {
      try {
        const record = this._parseQuoteLine(line, stockMap, date);
        if (record) records.push(record);
      } catch (e) {
        // 跳过解析失败的行
      }
    }

    return records;
  }

  /**
   * 解析腾讯行情单行数据
   * 
   * 字段索引（~分隔）：
   *  0: 市场标识(v_sh/v_sz)
   *  1: 名称
   *  2: 代码
   *  3: 最新价(收盘价)
   *  4: 昨收
   *  5: 开盘价
   *  6: 成交量(手)
   *  7-28: 买卖盘(略)
   * 30: 日期时间(YYYYMMDDHHmmss)
   * 31: 涨跌额
   * 32: 涨跌幅(%)
   * 33: 最高价
   * 34: 最低价
   * 35: 收盘价/成交量/成交额
   * 36: 成交量(手)
   * 37: 成交额(万元)
   * 38: 换手率(%)
   * 39: 市盈率
   * 46: 市净率
   */
  _parseQuoteLine(line, stockMap, date) {
    const match = line.match(/v_\w+="(.+)"/);
    if (!match) return null;

    const fields = match[1].split('~');
    if (fields.length < 40) return null;

    const code = fields[2];
    const stockInfo = stockMap[code];
    if (!stockInfo) return null;

    const close = this._safeNumber(fields[3]);
    const prevClose = this._safeNumber(fields[4]);
    
    // 跳过停牌/退市股票（价格为0或无交易）
    const volume = this._safeNumber(fields[36]);
    if (close === 0) return null;

    // 涨跌幅：优先用接口值，否则自己计算
    let changePct = this._safeNumber(fields[32]);
    if (changePct === 0 && prevClose > 0 && close !== prevClose) {
      changePct = ((close - prevClose) / prevClose) * 100;
    }

    // 成交额：字段37单位是万元，转为元
    const amountWan = this._safeNumber(fields[37]);
    const amount = amountWan * 10000;

    // 成交量：字段36单位是手，转为股
    const volumeShares = volume * 100;

    return {
      date: date,
      code: code,
      name: stockInfo.name,
      market: stockInfo.market,
      industry: '',  // 腾讯接口不返回行业，后续可补充
      close: close,
      change_pct: changePct,
      open: this._safeNumber(fields[5]),
      high: this._safeNumber(fields[33]),
      low: this._safeNumber(fields[34]),
      volume: volumeShares,
      amount: amount,
      turnover: this._safeNumber(fields[38]),
      pe: this._safeNullable(fields[39]),
      pb: this._safeNullable(fields[46]),
      is_st: stockInfo.name.includes('ST'),
      is_suspend: volume === 0
    };
  }

  _safeNumber(val) {
    if (val === null || val === undefined || val === '' || val === '-') return 0;
    const num = Number(val);
    return isNaN(num) ? 0 : num;
  }

  _safeNullable(val) {
    if (val === null || val === undefined || val === '' || val === '-') return null;
    const num = Number(val);
    return isNaN(num) ? null : num;
  }

  _getDateStr() {
    const now = new Date();
    const offset = 8 * 60;
    const local = new Date(now.getTime() + offset * 60 * 1000);
    return local.toISOString().split('T')[0];
  }

  _httpGet(url, retries = 2) {
    return new Promise((resolve, reject) => {
      const protocol = url.startsWith('https') ? https : http;
      const req = protocol.get(url, { timeout: this.timeout }, (res) => {
        let data = '';
        res.on('data', chunk => data += chunk);
        res.on('end', () => {
          if (!data || data.trim() === '') {
            // 空响应，尝试重试
            if (retries > 0) {
              console.warn(`[Adapter] 空响应，剩余重试次数: ${retries}`);
              setTimeout(() => {
                this._httpGet(url, retries - 1).then(resolve).catch(reject);
              }, 1000);
              return;
            }
            reject(new Error(`空响应: ${url}`));
            return;
          }
          try {
            resolve(JSON.parse(data));
          } catch (e) {
            reject(new Error(`JSON解析失败: ${e.message}`));
          }
        });
      });
      req.on('error', (err) => {
        if (retries > 0) {
          console.warn(`[Adapter] 请求错误，剩余重试次数: ${retries}: ${err.message}`);
          setTimeout(() => {
            this._httpGet(url, retries - 1).then(resolve).catch(reject);
          }, 1000);
        } else {
          reject(err);
        }
      });
      req.on('timeout', () => {
        req.destroy();
        if (retries > 0) {
          console.warn(`[Adapter] 请求超时，剩余重试次数: ${retries}`);
          setTimeout(() => {
            this._httpGet(url, retries - 1).then(resolve).catch(reject);
          }, 1000);
        } else {
          reject(new Error(`请求超时: ${url}`));
        }
      });
    });
  }

  /**
   * HTTP GET 返回原始文本（用于腾讯接口，需要GBK解码）
   */
  _httpGetText(url, retries = 2) {
    return new Promise((resolve, reject) => {
      const req = http.get(url, { timeout: this.timeout }, (res) => {
        const chunks = [];
        res.on('data', chunk => chunks.push(chunk));
        res.on('end', () => {
          const buf = Buffer.concat(chunks);
          if (buf.length === 0) {
            // 空响应，尝试重试
            if (retries > 0) {
              console.warn(`[Adapter] 空响应，剩余重试次数: ${retries}`);
              setTimeout(() => {
                this._httpGetText(url, retries - 1).then(resolve).catch(reject);
              }, 1000);
              return;
            }
            reject(new Error(`空响应: ${url}`));
            return;
          }
          // 尝试用 iconv 解码 GBK
          try {
            const iconv = require('iconv-lite');
            resolve(iconv.decode(buf, 'gbk'));
          } catch (e) {
            // 没有 iconv-lite 就用 binary
            resolve(buf.toString('binary'));
          }
        });
      });
      req.on('error', (err) => {
        if (retries > 0) {
          console.warn(`[Adapter] 请求错误，剩余重试次数: ${retries}: ${err.message}`);
          setTimeout(() => {
            this._httpGetText(url, retries - 1).then(resolve).catch(reject);
          }, 1000);
        } else {
          reject(err);
        }
      });
      req.on('timeout', () => {
        req.destroy();
        if (retries > 0) {
          console.warn(`[Adapter] 请求超时，剩余重试次数: ${retries}`);
          setTimeout(() => {
            this._httpGetText(url, retries - 1).then(resolve).catch(reject);
          }, 1000);
        } else {
          reject(new Error(`请求超时: ${url}`));
        }
      });
    });
  }
}

module.exports = { EastMoneyAdapter };
