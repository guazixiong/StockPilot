/**
 * akshare_adapter.js
 * 
 * 职责：通过 AKShare 获取 ETF 历史行情数据
 * 职责边界：
 *   - 只负责调用 Python 子进程获取数据 + 字段映射
 *   - 不做数据清洗、异常判断
 *   - change_pct 通过相邻收盘价计算（第一天设为 null）
 * 
 * 数据源：AKShare fund_etf_hist_sina（新浪源，无IP限制）
 * 
 * 接口契约：
 *   fetchHistoricalSnapshot(etfConfig, startDate, endDate) → StockRecord[]
 */

const { execSync } = require('child_process');
const path = require('path');

class AkshareAdapter {
  constructor(config = {}) {
    this.timeout = config.timeout || 60000;
    this.retryCount = config.retryCount || 3;
    this.retryDelay = config.retryDelay || 2000;
  }

  /**
   * 获取单只 ETF 的历史行情
   * @param {object} etfConfig - 来自 etf.json 的 ETF 配置
   * @param {string} startDate - YYYY-MM-DD
   * @param {string} endDate - YYYY-MM-DD
   * @returns {Promise<StockRecord[]>}
   */
  async fetchHistoricalSnapshot(etfConfig, startDate, endDate) {
    const symbol = etfConfig.akshare_symbol;
    const code = etfConfig.code;
    const name = etfConfig.name;
    const market = etfConfig.market;

    let lastError;
    for (let attempt = 1; attempt <= this.retryCount; attempt++) {
      try {
        const rawData = this._callAkshare(symbol);
        const filtered = this._filterByDate(rawData, startDate, endDate);
        return this._transformRecords(filtered, code, name, market, etfConfig);
      } catch (err) {
        lastError = err;
        if (attempt < this.retryCount) {
          console.warn(`[AkshareAdapter] ${code} 第${attempt}次失败，${this.retryDelay}ms后重试: ${err.message}`);
          await this._sleep(this.retryDelay);
        }
      }
    }
    throw new Error(`[AkshareAdapter] ${code} 所有重试失败: ${lastError.message}`);
  }

  /**
   * 通过 Python 子进程调用 AKShare
   * 返回 JSON 格式的 ETF 历史数据
   */
  _callAkshare(symbol) {
    const pythonScript = `
import akshare as ak
import json
import sys

try:
    df = ak.fund_etf_hist_sina(symbol="${symbol}")
    records = []
    for _, row in df.iterrows():
        records.append({
            "date": str(row["date"]),
            "open": float(row["open"]) if row["open"] else 0,
            "high": float(row["high"]) if row["high"] else 0,
            "low": float(row["low"]) if row["low"] else 0,
            "close": float(row["close"]) if row["close"] else 0,
            "volume": float(row["volume"]) if row["volume"] else 0,
            "amount": float(row["amount"]) if row["amount"] else 0
        })
    print(json.dumps(records))
except Exception as e:
    print(json.dumps({"error": str(e)}), file=sys.stderr)
    sys.exit(1)
`;

    const result = execSync(`python3 -c '${pythonScript.replace(/'/g, "\\'")}'`, {
      encoding: 'utf8',
      timeout: this.timeout,
      maxBuffer: 50 * 1024 * 1024  // 50MB buffer for large datasets
    });

    const data = JSON.parse(result.trim());
    if (data.error) throw new Error(data.error);
    return data;
  }

  /**
   * 按日期范围过滤数据
   */
  _filterByDate(records, startDate, endDate) {
    return records.filter(r => r.date >= startDate && r.date <= endDate);
  }

  /**
   * 将 AKShare 原始数据映射为标准 StockRecord
   * 关键：change_pct 通过相邻收盘价计算，第一天设为 null
   */
  _transformRecords(rawRecords, code, name, market, etfConfig) {
    const records = [];
    const isSt = false; // ETF 不可能是 ST
    const industry = this._getIndustry(etfConfig);

    for (let i = 0; i < rawRecords.length; i++) {
      const raw = rawRecords[i];
      const close = raw.close;

      // 计算涨跌幅：第一天设为 null
      let changePct = null;
      if (i > 0) {
        const prevClose = rawRecords[i - 1].close;
        if (prevClose > 0) {
          changePct = ((close - prevClose) / prevClose) * 100;
          changePct = Math.round(changePct * 100) / 100; // 保留2位小数
        } else {
          changePct = 0;
        }
      }

      records.push({
        date: raw.date,
        code: code,
        name: name,
        market: market,
        industry: industry,
        close: close,
        change_pct: changePct,
        open: raw.open,
        high: raw.high,
        low: raw.low,
        volume: raw.volume,
        amount: raw.amount,
        turnover: null,      // 新浪源不提供
        pe: null,            // ETF 无 PE
        pb: null,            // ETF 无 PB
        is_st: isSt,
        is_suspend: raw.volume === 0
      });
    }

    return records;
  }

  /**
   * 从 ETF 配置中获取行业分类
   */
  _getIndustry(etfConfig) {
    const typeLabels = {
      'broad': '宽基',
      'industry': '行业',
      'theme': '主题',
      'cross_border': '跨境'
    };
    return `${typeLabels[etfConfig.type] || ''}-${etfConfig.tracking_index || ''}`;
  }

  _sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

module.exports = { AkshareAdapter };
