/**
 * daily_pipeline.js
 * 
 * 职责：编排每日数据采集流程
 * 职责边界：
 *   - 只做流程编排，不写业务逻辑
 *   - 严格按照：采集 → 校验 → 保存 → 报告 的顺序执行
 *   - 任何步骤失败则中止，不保存脏数据
 * 
 * 执行流程：
 *   1. EastMoneyAdapter.fetchMarketSnapshot()  → raw records
 *   2. QualityChecker.validate(records)         → quality report
 *   3. 如果 quality == "ERROR"，中止并报警
 *   4. SnapshotWriter.save(records, date)        → parquet file
 *   5. 保存 quality report 到 metadata/quality.jsonl
 *   6. 输出运行摘要
 * 
 * 使用方式：
 *   node daily_pipeline.js
 *   node daily_pipeline.js --date 2026-07-26  (回测/补数据)
 */

const path = require('path');
const fs = require('fs');
const { EastMoneyAdapter } = require('../adapters/eastmoney_adapter');
const { SnapshotWriter } = require('../writers/snapshot_writer');
const { QualityChecker } = require('../validators/quality_checker');

class DailyPipeline {
  constructor(config = {}) {
    this.dataRoot = config.dataRoot || path.join(__dirname, '../../data');
    
    this.adapter = new EastMoneyAdapter(config.adapter || {});
    this.writer = new SnapshotWriter({ dataRoot: this.dataRoot });
    this.checker = new QualityChecker(config.quality || {});
  }

  /**
   * 执行每日采集流程
   * @param {string} [overrideDate] - 可选，指定日期（用于历史回补）
   * @returns {PipelineResult}
   */
  async run(overrideDate) {
    const startTime = Date.now();
    const date = overrideDate || this._getDateStr();
    
    console.log(`[Pipeline] 开始采集 ${date}`);
    console.log(`[Pipeline] 时间: ${new Date().toISOString()}`);

    try {
      // Step 1: 采集
      console.log('[Pipeline] Step 1/4: 从东方财富获取全市场行情...');
      const records = await this.adapter.fetchMarketSnapshot();
      console.log(`[Pipeline] 获取 ${records.length} 条记录`);

      // Step 2: 校验
      console.log('[Pipeline] Step 2/4: 数据质量校验...');
      const quality = this.checker.validate(records);
      console.log(`[Pipeline] 质量: ${quality.quality}, 股票数: ${quality.stock_count}`);

      // Step 3: 如果质量为 ERROR，中止
      if (quality.quality === 'ERROR') {
        console.error('[Pipeline] ❌ 数据质量为 ERROR，中止保存');
        console.error('[Pipeline] 错误:', quality.errors);
        this._saveQualityReport(quality);
        return {
          success: false,
          date,
          quality: quality.quality,
          errors: quality.errors,
          duration: Date.now() - startTime
        };
      }

      if (quality.quality === 'WARNING') {
        console.warn('[Pipeline] ⚠️ 数据质量告警，继续保存:');
        quality.warnings.forEach(w => console.warn(`  - ${w}`));
      }

      // Step 4: 保存 snapshot
      console.log('[Pipeline] Step 3/4: 保存 Parquet...');
      const saveResult = await this.writer.save(records, date);
      console.log(`[Pipeline] 已保存: ${saveResult.path} (${saveResult.count} 条)`);

      // Step 5: 保存质量报告
      console.log('[Pipeline] Step 4/4: 保存质量报告...');
      this._saveQualityReport(quality);

      const duration = Date.now() - startTime;
      console.log(`[Pipeline] ✅ 完成，耗时 ${duration}ms`);

      return {
        success: true,
        date,
        quality: quality.quality,
        stock_count: quality.stock_count,
        snapshot_path: saveResult.path,
        warnings: quality.warnings,
        duration
      };

    } catch (error) {
      console.error(`[Pipeline] ❌ 流程失败: ${error.message}`);
      console.error(error.stack);
      return {
        success: false,
        date,
        error: error.message,
        duration: Date.now() - startTime
      };
    }
  }

  /**
   * 保存质量报告到 metadata/quality.jsonl
   * JSONL 格式：每行一条 JSON，追加写入
   */
  _saveQualityReport(quality) {
    const metadataDir = path.join(this.dataRoot, 'metadata');
    fs.mkdirSync(metadataDir, { recursive: true });

    const filePath = path.join(metadataDir, 'quality.jsonl');
    const line = JSON.stringify(quality) + '\n';
    fs.appendFileSync(filePath, line, 'utf8');
  }

  _getDateStr() {
    const now = new Date();
    const offset = 8 * 60;
    const local = new Date(now.getTime() + offset * 60 * 1000);
    return local.toISOString().split('T')[0];
  }
}

// CLI 入口
async function main() {
  const args = process.argv.slice(2);
  let overrideDate = null;

  // 解析 --date 参数
  const dateIndex = args.indexOf('--date');
  if (dateIndex !== -1 && args[dateIndex + 1]) {
    overrideDate = args[dateIndex + 1];
  }

  const pipeline = new DailyPipeline();
  const result = await pipeline.run(overrideDate);

  console.log('\n[Pipeline] 运行结果:');
  console.log(JSON.stringify(result, null, 2));

  process.exit(result.success ? 0 : 1);
}

main().catch(err => {
  console.error('[Pipeline] 未捕获异常:', err);
  process.exit(1);
});

module.exports = { DailyPipeline };
