/**
 * historical_pipeline.js
 * 
 * 职责：编排 ETF 历史数据回补流程
 * 职责边界：
 *   - 读取 etf.json 配置
 *   - 调用 AkshareAdapter 获取历史数据
 *   - 复用 SnapshotWriter 保存 Parquet
 *   - 复用 QualityChecker 校验数据质量
 *   - 增量模式：跳过已有 snapshot 的日期
 * 
 * 使用方式：
 *   node historical_pipeline.js                           # 回补全部ETF，2020-01-01至今
 *   node historical_pipeline.js --start 2025-01-01       # 指定起始日期
 *   node historical_pipeline.js --code 512010            # 只回补指定ETF
 *   node historical_pipeline.js --dry-run                # 只预览，不实际保存
 */

const fs = require('fs');
const path = require('path');
const { AkshareAdapter } = require('../adapters/akshare_adapter');
const { SnapshotWriter } = require('../writers/snapshot_writer');
const { QualityChecker } = require('../validators/quality_checker');

class HistoricalPipeline {
  constructor(config = {}) {
    this.dataRoot = config.dataRoot || path.join(__dirname, '../../data');
    this.adapter = new AkshareAdapter(config.adapter || {});
    this.writer = new SnapshotWriter({ dataRoot: this.dataRoot });
    this.checker = new QualityChecker(config.quality || {});
    
    this.etfConfig = this._loadEtfConfig();
    this.delayBetweenEtf = config.delayBetweenEtf || 1000; // ETF间隔1秒
  }

  /**
   * 执行历史回补
   * @param {object} options
   * @param {string} options.startDate - YYYY-MM-DD
   * @param {string} options.endDate - YYYY-MM-DD
   * @param {string} [options.code] - 只回补指定ETF代码
   * @param {boolean} [options.dryRun] - 只预览不保存
   */
  async run(options = {}) {
    const startDate = options.startDate || '2020-01-01';
    const endDate = options.endDate || this._getDateStr();
    const targetCode = options.code || null;
    const dryRun = options.dryRun || false;

    const etfs = targetCode 
      ? this.etfConfig.portfolio.filter(e => e.code === targetCode)
      : this.etfConfig.portfolio;

    if (etfs.length === 0) {
      console.error(`[Historical] 未找到ETF: ${targetCode}`);
      return { success: false, error: 'ETF not found' };
    }

    console.log(`[Historical] 开始回补 ${etfs.length} 只ETF`);
    console.log(`[Historical] 日期范围: ${startDate} ~ ${endDate}`);
    console.log(`[Historical] 模式: ${dryRun ? 'DRY RUN' : '正式保存'}`);
    console.log('');

    const results = [];
    const startTime = Date.now();

    for (let i = 0; i < etfs.length; i++) {
      const etf = etfs[i];
      console.log(`[Historical] [${i+1}/${etfs.length}] ${etf.code} ${etf.name}`);

      try {
        const result = await this._processOneEtf(etf, startDate, endDate, dryRun);
        results.push(result);
        console.log(`[Historical]   ✅ ${result.record_count} 条记录, ${result.saved_dates} 个日期`);
      } catch (err) {
        const errMsg = err.message || String(err);
        console.error(`[Historical]   ❌ 失败: ${errMsg}`);
        results.push({ code: etf.code, success: false, error: errMsg });
      }

      // ETF间隔限速
      if (i < etfs.length - 1) {
        await this._sleep(this.delayBetweenEtf);
      }
    }

    const duration = Date.now() - startTime;
    const successCount = results.filter(r => r.success).length;
    const failCount = results.filter(r => !r.success).length;

    console.log('');
    console.log(`[Historical] 回补完成`);
    console.log(`[Historical] 成功: ${successCount}, 失败: ${failCount}, 耗时: ${(duration/1000).toFixed(1)}s`);

    return {
      success: failCount === 0,
      total: etfs.length,
      success_count: successCount,
      fail_count: failCount,
      results,
      duration
    };
  }

  /**
   * 处理单只ETF的回补
   */
  async _processOneEtf(etf, startDate, endDate, dryRun) {
    // 获取历史数据
    const records = await this.adapter.fetchHistoricalSnapshot(etf, startDate, endDate);
    
    if (!records || records.length === 0) {
      return { code: etf.code, success: true, record_count: 0, saved_dates: 0 };
    }

    // 按日期分组
    const byDate = {};
    for (const record of records) {
      if (!byDate[record.date]) byDate[record.date] = [];
      byDate[record.date].push(record);
    }

    const dates = Object.keys(byDate).sort();
    let savedCount = 0;

    if (!dryRun) {
      for (const date of dates) {
        const dateRecords = byDate[date];
        
        // 检查是否已有snapshot
        if (this._snapshotExists(date)) {
          // 追加到已有snapshot（多只ETF同一天）
          await this._appendToSnapshot(dateRecords, date);
        } else {
          // 保存新snapshot
          await this.writer.save(dateRecords, date);
        }
        
        savedCount++;
      }

      // 保存质量报告
      const quality = this.checker.validate(records);
      this._saveQualityReport(quality, etf.code);
    }

    return {
      code: etf.code,
      name: etf.name,
      success: true,
      record_count: records.length,
      saved_dates: savedCount,
      date_range: `${dates[0]} ~ ${dates[dates.length - 1]}`
    };
  }

  /**
   * 检查某日期的snapshot是否已存在
   */
  _snapshotExists(date) {
    const [year, month] = date.split('-');
    const filePath = path.join(this.dataRoot, 'snapshot', year, month, `${date}.parquet`);
    return fs.existsSync(filePath);
  }

  /**
   * 追加记录到已有snapshot（用于多只ETF同一天的数据合并）
   * 注意：Parquet不支持原地追加，需要读取-合并-重写
   */
  async _appendToSnapshot(newRecords, date) {
    const [year, month] = date.split('-');
    const filePath = path.join(this.dataRoot, 'snapshot', year, month, `${date}.parquet`);
    
    // 读取已有数据
    let existingRecords = [];
    try {
      const parquet = require('parquetjs');
      const reader = await parquet.ParquetReader.openFile(filePath);
      const cursor = reader.getCursor();
      let record;
      while (record = await cursor.next()) {
        existingRecords.push(record);
      }
      await reader.close();
    } catch (e) {
      // 文件读取失败，可能已损坏，直接覆盖
      existingRecords = [];
    }
    
    // 合并数据：新记录覆盖同code的旧记录
    const mergedMap = new Map();
    for (const r of existingRecords) {
      mergedMap.set(r.code, r);
    }
    for (const r of newRecords) {
      mergedMap.set(r.code, r);
    }
    
    const mergedRecords = Array.from(mergedMap.values());
    
    // 写入合并后的数据
    await this.writer.save(mergedRecords, date);
  }

  _saveQualityReport(quality, etfCode) {
    const metadataDir = path.join(this.dataRoot, 'metadata');
    fs.mkdirSync(metadataDir, { recursive: true });
    
    const report = { ...quality, source: 'historical', etf_code: etfCode };
    const filePath = path.join(metadataDir, 'quality.jsonl');
    fs.appendFileSync(filePath, JSON.stringify(report) + '\n', 'utf8');
  }

  _loadEtfConfig() {
    const configPath = path.join(__dirname, '../../config/etf.json');
    return JSON.parse(fs.readFileSync(configPath, 'utf8'));
  }

  _getDateStr() {
    const now = new Date();
    const offset = 8 * 60;
    const local = new Date(now.getTime() + offset * 60 * 1000);
    return local.toISOString().split('T')[0];
  }

  _sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

// CLI 入口
async function main() {
  const args = process.argv.slice(2);
  const options = {
    startDate: '2020-01-01',
    endDate: null,
    code: null,
    dryRun: false
  };

  for (let i = 0; i < args.length; i++) {
    switch (args[i]) {
      case '--start':
        options.startDate = args[++i];
        break;
      case '--end':
        options.endDate = args[++i];
        break;
      case '--code':
        options.code = args[++i];
        break;
      case '--dry-run':
        options.dryRun = true;
        break;
    }
  }

  const pipeline = new HistoricalPipeline();
  const result = await pipeline.run(options);

  console.log('\n[Historical] 运行结果:');
  console.log(JSON.stringify(result, null, 2));

  process.exit(result.success ? 0 : 1);
}

main().catch(err => {
  console.error('[Historical] 未捕获异常:', err);
  process.exit(1);
});

module.exports = { HistoricalPipeline };
