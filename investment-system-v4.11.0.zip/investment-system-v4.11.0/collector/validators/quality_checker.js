/**
 * quality_checker.js
 * 
 * 职责：校验 StockRecord[] 数据质量
 * 职责边界：
 *   - 只做检查，不做修复
 *   - 输出标准化质量报告
 *   - 不修改原始数据
 * 
 * 接口契约：
 *   validate(records) → QualityReport
 * 
 * QualityReport 契约：
 * {
 *   date: string,
 *   quality: "GOOD" | "WARNING" | "ERROR",
 *   stock_count: number,
 *   checks: {
 *     stock_count:   { value, status, message? },
 *     price_range:   { value, status, message? },
 *     change_range:  { value, status, message? },
 *     volume_check:  { value, status, message? },
 *     timestamp:     { value, status }
 *   },
 *   warnings: string[],
 *   errors: string[]
 * }
 */

class QualityChecker {
  constructor(config = {}) {
    this.minStockCount = config.minStockCount || 4000;
    this.maxChangePct = config.maxChangePct || 20.0;
    this.lowLiquidityThreshold = config.lowLiquidityThreshold || 0.2;
  }

  /**
   * 校验全市场快照数据质量
   * @param {StockRecord[]} records
   * @returns {QualityReport}
   */
  validate(records) {
    const date = records.length > 0 ? records[0].date : 'unknown';
    const warnings = [];
    const errors = [];

    const stockCountCheck = this._checkStockCount(records);
    const priceRangeCheck = this._checkPriceRange(records);
    const changeRangeCheck = this._checkChangeRange(records);
    const volumeCheck = this._checkVolume(records);
    const timestampCheck = this._checkTimestamp();

    // 收集告警
    if (stockCountCheck.status === 'warning') warnings.push(stockCountCheck.message);
    if (priceRangeCheck.status === 'warning') warnings.push(priceRangeCheck.message);
    if (changeRangeCheck.status === 'warning') warnings.push(changeRangeCheck.message);
    if (volumeCheck.status === 'warning') warnings.push(volumeCheck.message);

    // 检查是否有错误（数据不可用）
    if (stockCountCheck.status === 'error') errors.push(stockCountCheck.message);
    if (priceRangeCheck.status === 'error') errors.push(priceRangeCheck.message);

    // 综合质量判定
    let quality = 'GOOD';
    if (errors.length > 0) quality = 'ERROR';
    else if (warnings.length > 0) quality = 'WARNING';

    return {
      date,
      quality,
      stock_count: records.length,
      checks: {
        stock_count:  stockCountCheck,
        price_range:  priceRangeCheck,
        change_range: changeRangeCheck,
        volume_check: volumeCheck,
        timestamp:    timestampCheck
      },
      warnings,
      errors
    };
  }

  /**
   * 检查1：股票数量
   * 规则：正常交易日应有 4000+ 只股票
   */
  _checkStockCount(records) {
    const count = records.length;
    const activeCount = records.filter(r => !r.is_suspend).length;

    if (count < 1000) {
      return {
        value: count,
        active: activeCount,
        status: 'error',
        message: `股票数量异常偏低: ${count}（可能数据获取失败）`
      };
    }

    if (count < this.minStockCount) {
      return {
        value: count,
        active: activeCount,
        status: 'warning',
        message: `股票数量偏低: ${count}（阈值: ${this.minStockCount}）`
      };
    }

    return { value: count, active: activeCount, status: 'ok' };
  }

  /**
   * 检查2：价格范围
   * 规则：排除停牌后，价格应 > 0 且 < 5000
   */
  _checkPriceRange(records) {
    const active = records.filter(r => !r.is_suspend && r.close > 0);
    if (active.length === 0) {
      return { value: 0, status: 'error', message: '无有效价格数据' };
    }

    const maxPrice = Math.max(...active.map(r => r.close));
    const minPrice = Math.min(...active.map(r => r.close));
    const zeroPriceCount = records.filter(r => !r.is_suspend && r.close === 0).length;

    if (zeroPriceCount > records.length * 0.1) {
      return {
        value: `${zeroPriceCount}只零价`,
        status: 'warning',
        message: `非停牌股票中零价占比偏高: ${zeroPriceCount}/${records.length}`
      };
    }

    if (maxPrice > 5000) {
      return {
        value: `最高价${maxPrice}`,
        status: 'warning',
        message: `异常高价: ${maxPrice}，可能数据错误`
      };
    }

    return {
      value: `范围[${minPrice}, ${maxPrice}]`,
      status: 'ok'
    };
  }

  /**
   * 检查3：涨跌幅范围
   * 规则：正常股票涨跌幅应在 [-22, +22]（含ST ±5%容差）
   * 异常：全市场涨跌比极端（如 5000:0）
   */
  _checkChangeRange(records) {
    const active = records.filter(r => !r.is_suspend);
    if (active.length === 0) {
      return { value: '无数据', status: 'ok' };
    }

    const maxChange = Math.max(...active.map(r => r.change_pct));
    const minChange = Math.min(...active.map(r => r.change_pct));
    const advance = active.filter(r => r.change_pct > 0).length;
    const decline = active.filter(r => r.change_pct < 0).length;
    const flat = active.filter(r => r.change_pct === 0).length;

    const extremeCount = active.filter(r => Math.abs(r.change_pct) > 22).length;

    if (extremeCount > active.length * 0.05) {
      return {
        value: `${extremeCount}只超限`,
        status: 'warning',
        message: `涨跌幅超±22%的股票: ${extremeCount}只（可能含新股/复牌）`
      };
    }

    // 全市场极端涨跌比
    if (active.length > 100) {
      if (advance === 0 && decline > 0) {
        return {
          value: `涨${advance}/跌${decline}`,
          status: 'warning',
          message: `市场极端：无上涨股票（可能是数据异常）`
        };
      }
      if (decline === 0 && advance > 0) {
        return {
          value: `涨${advance}/跌${decline}`,
          status: 'warning',
          message: `市场极端：无下跌股票（可能是数据异常）`
        };
      }
    }

    return {
      value: `涨${advance}/跌${decline}/平${flat}`,
      range: `[${minChange.toFixed(2)}%, ${maxChange.toFixed(2)}%]`,
      status: 'ok'
    };
  }

  /**
   * 检查4：成交量/成交额
   * 规则：检测流动性异常日（如节假日前、极端行情日）
   * 判定：今日总成交额 < 20日均值 × 阈值
   * 注意：这里只做单日检查，历史均值对比需要 feature_calculator 完成
   */
  _checkVolume(records) {
    const active = records.filter(r => !r.is_suspend);
    if (active.length === 0) {
      return { value: 0, status: 'ok' };
    }

    const totalAmount = active.reduce((sum, r) => sum + r.amount, 0);
    const zeroVolumeCount = active.filter(r => r.volume === 0 && !r.is_suspend).length;

    // 检查是否有大量股票零成交（非停牌）
    if (zeroVolumeCount > active.length * 0.1) {
      return {
        value: `${zeroVolumeCount}只零成交`,
        total_amount: totalAmount,
        status: 'warning',
        message: `非停牌股票零成交占比偏高: ${zeroVolumeCount}只`
      };
    }

    return {
      value: `总成交额${(totalAmount / 1e8).toFixed(0)}亿`,
      total_amount: totalAmount,
      status: 'ok'
    };
  }

  /**
   * 检查5：时间戳
   */
  _checkTimestamp() {
    const now = new Date();
    const offset = 8 * 60;
    const local = new Date(now.getTime() + offset * 60 * 1000);
    const fetchTime = local.toISOString().replace('Z', '+08:00');

    return {
      value: fetchTime,
      status: 'ok'
    };
  }
}

module.exports = { QualityChecker };
