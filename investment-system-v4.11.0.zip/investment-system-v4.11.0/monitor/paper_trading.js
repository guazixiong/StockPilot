/**
 * Regime Engine v3.5 - 纸上交易模拟系统
 * 每日记录策略信号，模拟下单，跟踪收益
 */

const fs = require('fs');
const path = require('path');
const { calculateRegime, getAllocationSuggestion } = require('./daily_monitor');

const DATA_DIR = path.join(__dirname, '../data/paper_trading');
fs.mkdirSync(DATA_DIR, { recursive: true });

/**
 * 加载历史交易记录
 */
function loadHistory() {
    const historyPath = path.join(DATA_DIR, 'history.json');
    if (fs.existsSync(historyPath)) {
        return JSON.parse(fs.readFileSync(historyPath, 'utf-8'));
    }
    return { trades: [], portfolio: { capital: 1000000, positions: {}, nav: 1.0 } };
}

/**
 * 保存交易记录
 */
function saveHistory(history) {
    fs.writeFileSync(path.join(DATA_DIR, 'history.json'), JSON.stringify(history, null, 2));
}

/**
 * 记录每日信号
 */
function recordSignal(date, etfData) {
    const regime = calculateRegime(etfData);
    const suggestion = getAllocationSuggestion(regime.state);
    const history = loadHistory();
    
    const record = {
        date,
        regime: regime.state,
        ratio: regime.ratio,
        advancing: regime.advancing,
        total: regime.total,
        positionSize: suggestion.positionSize,
        investAmount: suggestion.investAmount,
        suggestion: suggestion.suggestions,
        timestamp: new Date().toISOString()
    };
    
    history.trades.push(record);
    saveHistory(history);
    
    return record;
}

/**
 * 生成模拟报告
 */
function generateSimulationReport(days = 30) {
    const history = loadHistory();
    const recentTrades = history.trades.slice(-days);
    
    if (recentTrades.length === 0) {
        return '暂无交易记录';
    }
    
    let report = `📊 纸上交易模拟报告（最近${days}天）\n`;
    report += `${'='.repeat(50)}\n\n`;
    
    report += `总交易天数: ${recentTrades.length}\n`;
    
    // Regime 分布
    const regimeCount = {};
    recentTrades.forEach(t => {
        regimeCount[t.regime] = (regimeCount[t.regime] || 0) + 1;
    });
    
    report += `\nRegime分布:\n`;
    for (const [regime, count] of Object.entries(regimeCount)) {
        report += `  ${regime}: ${count}天 (${(count/recentTrades.length*100).toFixed(1)}%)\n`;
    }
    
    return report;
}

module.exports = { recordSignal, generateSimulationReport, loadHistory };

if (require.main === module) {
    const args = process.argv.slice(2);
    if (args[0] === 'report') {
        console.log(generateSimulationReport(parseInt(args[1]) || 30));
    }
}
