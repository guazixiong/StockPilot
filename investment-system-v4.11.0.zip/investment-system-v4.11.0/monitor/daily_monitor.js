/**
 * Regime Engine v3.5 - 实时监控系统
 * 每日15:00后运行，计算当日Regime状态和配置建议
 */

const fs = require('fs');
const path = require('path');

// v3.5 配置
const ALLOCATION = {
    BULL: {
        "159330": 0.10,  // 沪深300
        "515070": 0.15,  // 人工智能
        "159599": 0.15,  // 芯片
        "516160": 0.10,  // 新能源
        "512880": 0.10,  // 证券
        "513650": 0.20,  // 标普500
        "513880": 0.20   // 日经225
    },
    BEAR: {
        "512010": 0.30,  // 医药
        "159611": 0.30,  // 电力
        "513650": 0.20,  // 标普500
        "513880": 0.20   // 日经225
    },
    RANGE: {
        "159330": 0.15,  // 沪深300
        "515070": 0.15,  // 人工智能
        "159599": 0.15,  // 芯片
        "513650": 0.20,  // 标普500
        "513880": 0.20,  // 日经225
        "512010": 0.15   // 医药
    }
};

const POSITION_SIZING = { BULL: 1.0, BEAR: 0.4, RANGE: 0.7 };
const BULL_THRESHOLD = 0.60;
const BEAR_THRESHOLD = 0.30;

const ETF_NAMES = {
    "159330": "沪深300ETF",
    "515070": "人工智能ETF",
    "159599": "芯片ETF",
    "516160": "新能源ETF",
    "512880": "证券ETF",
    "513650": "标普500ETF",
    "513880": "日经225ETF",
    "512010": "医药ETF",
    "159611": "电力ETF",
    "159825": "农业ETF"
};

function calculateRegime(etfData) {
    if (!etfData || etfData.length === 0) {
        return { state: 'RANGE', ratio: 0.5, advancing: 0, total: 0 };
    }
    const total = etfData.length;
    const advancing = etfData.filter(etf => etf.change_pct > 0).length;
    const ratio = advancing / total;
    let state = 'RANGE';
    if (ratio >= BULL_THRESHOLD) state = 'BULL';
    else if (ratio <= BEAR_THRESHOLD) state = 'BEAR';
    return { state, ratio, advancing, total };
}

function getAllocationSuggestion(regime, capital = 1000000) {
    const allocation = ALLOCATION[regime] || ALLOCATION.RANGE;
    const positionSize = POSITION_SIZING[regime] || 0.7;
    const investAmount = capital * positionSize;
    const suggestions = [];
    for (const [code, weight] of Object.entries(allocation)) {
        suggestions.push({
            code,
            name: ETF_NAMES[code] || code,
            weight: weight * 100,
            amount: Math.round(investAmount * weight)
        });
    }
    return { regime, positionSize: positionSize * 100, investAmount: Math.round(investAmount), cash: Math.round(capital - investAmount), suggestions };
}

function generateReport(date, etfData) {
    const regime = calculateRegime(etfData);
    const suggestion = getAllocationSuggestion(regime.state);
    let report = `📊 Regime Engine v3.5 - ${date}\n`;
    report += `状态: ${regime.state} | 上涨ETF: ${regime.advancing}/${regime.total}\n`;
    report += `仓位: ${suggestion.positionSize}% | 投资: ¥${suggestion.investAmount.toLocaleString()}\n`;
    for (const item of suggestion.suggestions) {
        report += `  ${item.name}: ${item.weight.toFixed(0)}% ¥${item.amount.toLocaleString()}\n`;
    }
    return { date, regime: regime.state, report };
}

module.exports = { calculateRegime, getAllocationSuggestion, generateReport };
