#!/usr/bin/env node
/**
 * Scheduled human-readable report for the V4.5 live decision layer.
 *
 * This is deliberately a renderer, not a second strategy engine: every
 * executable ETF action must come from latest_live_trade_decisions.json.
 */
const fs = require('fs');
const path = require('path');

const BASE = path.join(__dirname, '..');
const DECISIONS_PATH = path.join(BASE, 'data', 'paper_trading_v4.0', 'latest_live_trade_decisions.json');
const HOLDINGS_PATH = path.join(BASE, 'config', 'holdings.json');
const phase = process.argv[2] ?? 'close';

function load(file) {
    return JSON.parse(fs.readFileSync(file, 'utf8'));
}

function shanghaiDate() {
    return new Intl.DateTimeFormat('en-CA', {
        timeZone: 'Asia/Shanghai', year: 'numeric', month: '2-digit', day: '2-digit'
    }).format(new Date());
}

function titleFor(currentPhase) {
    return {
        preopen: '开盘前决策核验',
        close: '收盘交易计划',
        nightly: '夜间交易计划',
        open: '开盘决策核验'
    }[currentPhase] ?? '交易计划';
}

function quoteDateFor(decisions) {
    const dates = (decisions.decisions ?? []).map(item => item.quoteDate).filter(Boolean);
    return dates.length ? dates[0] : null;
}

function renderAction(action) {
    const label = action.action === 'BUY'
        ? '买入'
        : action.action === 'SELL_ALL'
            ? '卖出全部'
            : '卖出部分';
    const quantity = action.action === 'BUY' ? action.buyShares : action.sellShares;
    const amount = action.action === 'BUY' ? `，约¥${Math.round(action.estimatedAmount)}` : '';
    const range = action.action === 'BUY'
        ? `区间 ${action.buyRange.lower}-${action.buyRange.upper}`
        : `现价 ${Number(action.close).toFixed(3)}`;
    return `- 【${label}】${action.name}（${action.code}）：${range}，建议 ${quantity} 份${amount}；原因：${action.reason}。`;
}

function main() {
    if (!fs.existsSync(DECISIONS_PATH) || !fs.existsSync(HOLDINGS_PATH)) {
        throw new Error('V4.5 decision artifact or holdings file is missing');
    }
    const decisions = load(DECISIONS_PATH);
    const holdings = load(HOLDINGS_PATH);
    const today = shanghaiDate();
    const quoteDate = quoteDateFor(decisions);
    const isFresh = quoteDate === today;
    const lines = [
        `📊 V${decisions.version ?? '4.5.0'} ${titleFor(phase)}`,
        '',
        '【统一决策层】'
    ];

    if (!isFresh) {
        lines.push(`- 当前行情日期 ${quoteDate ?? '未知'}，不是 ${today}；不输出可执行买卖动作。`);
    } else if ((decisions.actions ?? []).length) {
        lines.push('- 以下动作已通过真实持仓、趋势与风险门控：');
        lines.push(...decisions.actions.map(renderAction));
    } else {
        lines.push('- 当前无通过 V4.5 门控的可执行买卖动作。');
    }

    const holds = (decisions.decisions ?? []).filter(item => item.action === 'HOLD');
    if (holds.length) {
        lines.push('', '【持仓观察】');
        lines.push(...holds.map(item => `- ${item.name}（${item.code}）：维持；${item.reason}。`));
    }
    if ((decisions.blockedBuys ?? []).length) {
        lines.push('', '【候选买入拦截】');
        lines.push(...decisions.blockedBuys.map(item => `- ${item.name}（${item.code}）：${item.reason}。`));
    }

    lines.push('', '【真实账户】');
    lines.push(`- ETF持仓 ${holdings.holdings.length} 只，可用现金 ¥${Number(holdings.available_cash).toFixed(2)}。`);
    lines.push('- 仅供人工复核和手动执行；系统不连接券商、不自动下单。');
    console.log(lines.join('\n'));
}

main();
