/**
 * 获取实时ETF数据
 * 使用akshare获取今日ETF行情
 */

const { execSync } = require('child_process');
const path = require('path');

// ETF配置
const ETF_CONFIGS = [
    { code: "510210", name: "上证指数ETF富国", akshare_symbol: "sh510210" },
    { code: "159107", name: "创业板软件ETF富国", akshare_symbol: "sz159107" },
    { code: "159599", name: "芯片ETF东财", akshare_symbol: "sz159599" },
    { code: "159611", name: "电力ETF", akshare_symbol: "sz159611" },
    { code: "512010", name: "医药ETF易方达", akshare_symbol: "sh512010" },
    { code: "512880", name: "证券ETF", akshare_symbol: "sh512880" },
    { code: "513650", name: "标普500ETF南方", akshare_symbol: "sh513650" },
    { code: "513880", name: "日经225ETF", akshare_symbol: "sh513880" },
    { code: "515070", name: "人工智能ETF", akshare_symbol: "sh515070" },
    { code: "516160", name: "新能源ETF", akshare_symbol: "sh516160" },
    { code: "159825", name: "农业ETF富国", akshare_symbol: "sz159825" }
];

function fetchETFData(symbol) {
    const pythonScript = `
import akshare as ak
import json
import sys

try:
    df = ak.fund_etf_hist_sina(symbol="${symbol}")
    if df.empty:
        print(json.dumps({"error": "No data"}))
        sys.exit(1)
    
    # 获取最新一天的数据
    latest = df.iloc[-1]
    prev = df.iloc[-2] if len(df) > 1 else None
    
    close = float(latest["close"])
    prev_close = float(prev["close"]) if prev is not None else None
    
    # 计算涨跌幅
    change_pct = None
    if prev_close and prev_close > 0:
        change_pct = round(((close - prev_close) / prev_close) * 100, 2)
    
    result = {
        "date": str(latest["date"]),
        "close": close,
        "open": float(latest["open"]),
        "high": float(latest["high"]),
        "low": float(latest["low"]),
        "volume": float(latest["volume"]),
        "amount": float(latest["amount"]),
        "change_pct": change_pct,
        "prev_close": prev_close
    }
    print(json.dumps(result))
except Exception as e:
    print(json.dumps({"error": str(e)}), file=sys.stderr)
    sys.exit(1)
`;

    try {
        const result = execSync(`python3 -c '${pythonScript.replace(/'/g, "\\'")}'`, {
            encoding: 'utf8',
            timeout: 30000,
            maxBuffer: 10 * 1024 * 1024
        });
        return JSON.parse(result.trim());
    } catch (error) {
        console.error(`Error fetching ${symbol}:`, error.message);
        return null;
    }
}

async function main() {
    console.log('📊 获取实时ETF数据...\n');
    
    const results = [];
    
    for (const config of ETF_CONFIGS) {
        const data = fetchETFData(config.akshare_symbol);
        if (data && !data.error) {
            results.push({
                code: config.code,
                name: config.name,
                ...data
            });
            console.log(`✅ ${config.name}: ${data.change_pct !== null ? data.change_pct.toFixed(2) + '%' : 'N/A'}`);
        } else {
            console.log(`❌ ${config.name}: 获取失败`);
        }
    }
    
    // 保存结果
    const fs = require('fs');
    const outputPath = path.join(__dirname, '../data/etf_realtime.json');
    fs.writeFileSync(outputPath, JSON.stringify(results, null, 2));
    console.log(`\n💾 数据已保存到: ${outputPath}`);
    
    return results;
}

main().catch(console.error);
