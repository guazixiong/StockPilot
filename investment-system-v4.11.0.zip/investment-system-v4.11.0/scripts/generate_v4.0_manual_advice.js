#!/usr/bin/env node
/** Produce a human-review-only V4.0 recommendation artifact. */
const fs = require('fs');
const path = require('path');
const BASE = path.join(__dirname, '..');
const statePath = path.join(BASE, 'data/paper_trading_v4.0/state.json');
const signalsPath = path.join(BASE, 'data/paper_trading_v4.0/latest_stock_signals.json');
const outputPath = path.join(BASE, 'data/paper_trading_v4.0/latest_manual_advice.json');
const config = JSON.parse(fs.readFileSync(path.join(BASE, 'config/v4.0_universe.json')));
const holdings = JSON.parse(fs.readFileSync(path.join(BASE, 'config/holdings.json')));
const snapshot = JSON.parse(fs.readFileSync(path.join(BASE, 'data/market_snapshot.json')));
const state = JSON.parse(fs.readFileSync(statePath));
const signals = JSON.parse(fs.readFileSync(signalsPath));
const reviewPath = path.join(BASE, 'data/paper_trading_v4.0/latest_stock_satellite_review.json');
const review = fs.existsSync(reviewPath) ? JSON.parse(fs.readFileSync(reviewPath, 'utf8')) : { candidates: [] };
const quotes = new Map((snapshot.etfs ?? []).map(q => [String(q.code ?? q.symbol ?? '').replace(/^(sh|sz)/, ''), q]));
const realHoldings = holdings.holdings.map(h => {
  const quote = quotes.get(String(h.code)); const close = Number(quote?.close);
  return { code: h.code, name: h.name, shares: h.shares, cost: h.cost, latestClose: close || null, quoteTradeDate: quote?.trade_date ?? null, dayChangePct: Number.isFinite(Number(quote?.change_pct)) ? Number(quote.change_pct) : null, unrealizedPct: close > 0 ? Number((((close / h.cost) - 1) * 100).toFixed(2)) : null };
});
const reviewByCode = new Map(review.candidates.map(item => [item.code, item]));
const stockSatellite = signals.signals.map(item => {
  const admission = reviewByCode.get(item.code);
  const eligible = admission?.admissionStatus === 'ELIGIBLE_FOR_SIGNAL' && item.status === 'WATCH_BUY_SETUP';
  const action = !eligible ? '继续观察，不生成买入指令。'
    : item.positionPlan.sizingStatus === 'WITHIN_POSITION_LIMIT' ? '满足条件：按建议价格区间、仓位、止盈和止损线手动执行；不自动下单。'
    : '信号有效但一手金额超过单只仓位上限，暂不买入。';
  return { ...item, admissionStatus: admission?.admissionStatus ?? 'BLOCKED', admissionBlockers: admission?.blockers ?? ['review_missing'], action };
});
const actionable = stockSatellite.filter(item => item.status === 'WATCH_BUY_SETUP' && item.admissionStatus === 'ELIGIBLE_FOR_SIGNAL' && item.positionPlan.sizingStatus === 'WITHIN_POSITION_LIMIT');
const sizingBlocked = stockSatellite.filter(item => item.status === 'WATCH_BUY_SETUP' && item.admissionStatus === 'ELIGIBLE_FOR_SIGNAL' && item.positionPlan.sizingStatus !== 'WITHIN_POSITION_LIMIT');
const result = { generatedAt: new Date().toISOString(), recommendationStatus: actionable.length ? 'ACTIONABLE_MANUAL_EXECUTION' : sizingBlocked.length ? 'BLOCKED_POSITION_SIZE' : 'BLOCKED_NO_ACTIONABLE_SIGNAL', modelValidationStatus: 'SPLIT_SAMPLE_RESEARCH_ONLY', signalDate: state.latestSignal?.date ?? null, confirmedState: state.confirmedState, capitalAssumption: holdings.available_cash, intendedExecution: 'next_trading_day_open_only', brokerOrderSent: false, etfCore: { targetWeights: state.latestSignal?.targetWeights ?? {}, action: state.latestSignal?.nextAction ?? 'HOLD' }, stockSatellite, actionableStocks: actionable.map(item => ({ code: item.code, name: item.name, referencePrice: item.referencePrice, suggestedRange: item.suggestedRange, positionPlan: item.positionPlan, riskPlan: item.riskPlan })), sizingBlockedStocks: sizingBlocked.map(item => ({ code: item.code, name: item.name, positionPlan: item.positionPlan, riskPlan: item.riskPlan })), blockers: actionable.length ? [] : sizingBlocked.length ? ['one_lot_exceeds_single_stock_limit'] : ['no_stock_passed_all_current_gates'], riskNotice: '不连接券商、不自动下单；跳空超过±2%、涨停买入、跌停卖出、停牌、行情过期或现金/整手/参与率不足时必须跳过。' };
fs.writeFileSync(outputPath, `${JSON.stringify(result, null, 2)}\n`);
console.log(JSON.stringify(result, null, 2));
