#!/usr/bin/env node
/** Stable V4.2 schedule entry point for post-close data and decision refresh. */
const { spawnSync } = require('child_process');
const path = require('path');

const BASE = path.join(__dirname, '..');
const result = spawnSync(process.execPath, [path.join(__dirname, 'refresh_v4.0_data_pipeline.js')], { cwd: BASE, encoding: 'utf8' });
if (result.status !== 0) {
    console.error(result.stderr || result.stdout || 'V4.2 refresh failed');
    process.exit(result.status || 1);
}
process.stdout.write(result.stdout);
