/**
 * fetch_market_snapshot.js
 * 
 * 获取沪深A股全市场实时行情快照
 * 
 * 数据源策略：
 *   - 股票列表：datacenter-web.eastmoney.com（无IP限制）
 *   - 行情数据：qt.gtimg.cn（腾讯行情，无IP限制）
 *   - 备用：push2.eastmoney.com（云服务器可能被限制）
 * 
 * 输出：JSON格式的行情数据，包含涨跌幅、成交量等
 * 
 * 用法：node fetch_market_snapshot.js [--index] [--etf]
 */

const https = require('https');
const http = require('http');
const fs = require('fs');
const path = require('path');

const V4_UNIVERSE_PATH = path.join(__dirname, '..', 'config', 'v4.0_universe.json');
const MONITOR_POOL_PATH = path.join(__dirname, '..', 'data', 'stock_monitor_pool.json');

class MarketSnapshot {
  constructor(config = {}) {
    this.timeout = config.timeout || 30000;
    this.batchSize = config.batchSize || 800;
  }

  /**
   * 获取市场快照
   * @param {Object} options - { index: bool, etf: bool, stocks: bool }
   * @returns {Promise<Object>}
   */
  async fetch(options = { index: true, etf: true, stocks: true }) {
    const result = {
      timestamp: new Date().toISOString(),
      indices: [],
      etfs: [],
      watchStocks: [],
      marketStocks: [],
      stocks: { total: 0, up: 0, down: 0, flat: 0, limit_up: 0, limit_down: 0 },
      errors: []
    };

    // 并发获取各类型数据
    const tasks = [];

    if (options.index) {
      tasks.push(this.fetchIndices().then(d => result.indices = d).catch(e => result.errors.push({ type: 'index', error: e.message })));
    }

    if (options.etf) {
      tasks.push(this.fetchETFs().then(d => result.etfs = d).catch(e => result.errors.push({ type: 'etf', error: e.message })));
      tasks.push(this.fetchWatchStocks().then(d => result.watchStocks = d).catch(e => result.errors.push({ type: 'watch_stock', error: e.message })));
    }

    if (options.stocks) {
      tasks.push(this.fetchStockBreadth().then(d => {
        result.stocks = { ...result.stocks, ...d };
        result.marketStocks = d.quotes ?? [];
      }).catch(e => result.errors.push({ type: 'stock', error: e.message })));
    }

    await Promise.all(tasks);

    return result;
  }

  /**
   * 获取主要指数行情（上证指数、深证成指、创业板指、科创50）
   * 使用腾讯行情接口
   */
  async fetchIndices() {
    const indices = [
      { symbol: 'sh000001', name: '上证指数' },
      { symbol: 'sz399001', name: '深证成指' },
      { symbol: 'sz399006', name: '创业板指' },
      { symbol: 'sh000688', name: '科创50' }
    ];

    const symbols = indices.map(i => i.symbol).join(',');
    const url = `http://qt.gtimg.cn/q=${symbols}`;
    
    try {
      const text = await this._httpGetText(url);
      const lines = text.split('\n').filter(l => l.includes('~'));
      
      return lines.map(line => {
        const match = line.match(/v_(\w+)="(.+)"/);
        if (!match) return null;
        
        const symbol = match[1];
        const fields = match[2].split('~');
        if (fields.length < 40) return null;
        
        const info = indices.find(i => i.symbol === symbol);
        return {
          symbol: symbol,
          name: info ? info.name : fields[1],
          trade_date: /^\d{8}/.test(fields[30] || '')
            ? `${fields[30].slice(0, 4)}-${fields[30].slice(4, 6)}-${fields[30].slice(6, 8)}`
            : null,
          close: this._safeNumber(fields[3]),
          prevClose: this._safeNumber(fields[4]),
          open: this._safeNumber(fields[5]),
          high: this._safeNumber(fields[33]),
          low: this._safeNumber(fields[34]),
          change_pct: this._safeNumber(fields[32]),
          volume: this._safeNumber(fields[36]),
          amount: this._safeNumber(fields[37]) * 10000
        };
      }).filter(Boolean);
    } catch (error) {
      console.error('[MarketSnapshot] 获取指数失败:', error.message);
      // 尝试备用接口
      return await this._fetchIndicesFallback();
    }
  }

  /**
   * 备用指数获取（东方财富）
   */
  async _fetchIndicesFallback() {
    const indices = [
      { secid: '1.000001', name: '上证指数' },
      { secid: '0.399001', name: '深证成指' },
      { secid: '0.399006', name: '创业板指' }
    ];

    const results = [];
    for (const idx of indices) {
      try {
        const url = `http://push2.eastmoney.com/api/qt/stock/get?secid=${idx.secid}&fields=f43,f44,f45,f46,f170,f58`;
        const data = await this._httpGetJson(url);
        if (data && data.data) {
          results.push({
            name: idx.name,
            close: data.data.f43 / 100,
            open: data.data.f44 / 100,
            high: data.data.f45 / 100,
            low: data.data.f46 / 100,
            change_pct: data.data.f170 / 100,
            prevClose: data.data.f58 / 100
          });
        }
      } catch (e) {
        console.warn(`[MarketSnapshot] 备用接口获取 ${idx.name} 失败: ${e.message}`);
      }
    }
    return results;
  }

  /**
   * 获取ETF实时行情
   */
  async fetchETFs() {
    // V3.8 paper-tracking core universe plus current holdings/watch ETFs.
    const etfs = [
      { symbol: 'sh510300', name: '沪深300ETF' },
      { symbol: 'sh510210', name: '上证指数ETF富国' },
      { symbol: 'sh515070', name: '人工智能ETF' },
      { symbol: 'sz159599', name: '芯片ETF' },
      { symbol: 'sz159611', name: '电力ETF' },
      { symbol: 'sh512010', name: '医药ETF' },
      { symbol: 'sh512880', name: '证券ETF' },
      { symbol: 'sh560710', name: '船舶ETF富国' },
      { symbol: 'sh513650', name: '标普500ETF' },
      { symbol: 'sh513880', name: '日经225ETF' },
      { symbol: 'sh516160', name: '新能源ETF' },
      { symbol: 'sh510050', name: '上证50ETF' },
      { symbol: 'sh510500', name: '中证500ETF' },
      { symbol: 'sz159915', name: '创业板ETF' },
      { symbol: 'sh588000', name: '科创50ETF' }
    ];

    const symbols = etfs.map(e => e.symbol).join(',');
    const url = `http://qt.gtimg.cn/q=${symbols}`;
    
    try {
      const text = await this._httpGetText(url);
      const lines = text.split('\n').filter(l => l.includes('~'));
      
      return lines.map(line => {
        const match = line.match(/v_(\w+)="(.+)"/);
        if (!match) return null;
        
        const symbol = match[1];
        const fields = match[2].split('~');
        if (fields.length < 40) return null;
        
        const info = etfs.find(e => e.symbol === symbol);
        return {
          symbol: symbol,
          name: info ? info.name : fields[1],
          trade_date: /^\d{8}/.test(fields[30] || '')
            ? `${fields[30].slice(0, 4)}-${fields[30].slice(4, 6)}-${fields[30].slice(6, 8)}`
            : null,
          close: this._safeNumber(fields[3]),
          prevClose: this._safeNumber(fields[4]),
          open: this._safeNumber(fields[5]),
          high: this._safeNumber(fields[33]),
          low: this._safeNumber(fields[34]),
          change_pct: this._safeNumber(fields[32]),
          volume: this._safeNumber(fields[36]),
          amount: this._safeNumber(fields[37]) * 10000
        };
      }).filter(Boolean);
    } catch (error) {
      console.error('[MarketSnapshot] 获取ETF失败:', error.message);
      return [];
    }
  }

  /**
   * Fetch V4.0 stock-satellite quotes independently from the ETF core universe.
   * Missing configuration returns an empty list, never an inferred stock pool.
   */
  async fetchWatchStocks() {
    if (!fs.existsSync(V4_UNIVERSE_PATH) && !fs.existsSync(MONITOR_POOL_PATH)) return [];
    const config = fs.existsSync(MONITOR_POOL_PATH)
      ? JSON.parse(fs.readFileSync(MONITOR_POOL_PATH, 'utf8'))
      : JSON.parse(fs.readFileSync(V4_UNIVERSE_PATH, 'utf8'));
    const configuredStocks = config.candidates ?? config.stockSatellite?.candidates ?? [];
    const stocks = configuredStocks.map(stock => ({
      symbol: `${String(stock.market).toLowerCase() === 'sh' ? 'sh' : String(stock.market).toLowerCase() === 'bj' ? 'bj' : 'sz'}${stock.code}`,
      code: String(stock.code),
      name: stock.name
    }));
    if (!stocks.length) return [];

    const text = await this._httpGetText(`http://qt.gtimg.cn/q=${stocks.map(stock => stock.symbol).join(',')}`);
    return text.split('\n').filter(line => line.includes('~')).map(line => {
      const match = line.match(/v_(\w+)="(.+)"/);
      if (!match) return null;
      const fields = match[2].split('~');
      if (fields.length < 40) return null;
      const stock = stocks.find(item => item.symbol === match[1]);
      if (!stock) return null;
      return {
        symbol: stock.symbol,
        code: stock.code,
        name: stock.name,
        trade_date: /^\d{8}/.test(fields[30] || '')
          ? `${fields[30].slice(0, 4)}-${fields[30].slice(4, 6)}-${fields[30].slice(6, 8)}`
          : null,
        close: this._safeNumber(fields[3]),
        prevClose: this._safeNumber(fields[4]),
        open: this._safeNumber(fields[5]),
        high: this._safeNumber(fields[33]),
        low: this._safeNumber(fields[34]),
        change_pct: this._safeNumber(fields[32]),
        volume: this._safeNumber(fields[36]),
        amount: this._safeNumber(fields[37]) * 10000
      };
    }).filter(Boolean);
  }

  /**
   * 获取全市场涨跌广度（breadth）
   */
  async fetchStockBreadth() {
    const today = this._getDateStr();
    
    // 从 datacenter-web 获取股票列表
    const stockList = await this._fetchStockList();
    if (stockList.length === 0) {
      throw new Error('获取股票列表失败');
    }

    // 从腾讯行情批量获取涨跌数据
    const quotes = await this._fetchQuotesBatch(stockList);
    
    // 统计涨跌
    let up = 0, down = 0, flat = 0, limit_up = 0, limit_down = 0;
    
    for (const q of quotes) {
      if (q.change_pct > 0) up++;
      else if (q.change_pct < 0) down++;
      else flat++;
      
      // 涨停/跌停判断
      if (q.change_pct >= 9.9) limit_up++;
      else if (q.change_pct <= -9.9) limit_down++;
    }

    return {
      total: quotes.length,
      up,
      down,
      flat,
      limit_up,
      limit_down,
      breadth: quotes.length > 0 ? up / quotes.length : 0.5,
      quotes
    };
  }

  async _fetchStockList() {
    const allStocks = [];
    let page = 1;
    const pageSize = 500;

    while (true) {
      const url = `https://datacenter-web.eastmoney.com/api/data/v1/get?reportName=RPT_DMSK_TS_STOCKNEW&columns=SECURITY_CODE,SECUCODE&pageSize=${pageSize}&pageNumber=${page}&sortColumns=SECURITY_CODE&sortTypes=1`;
      
      try {
        const data = await this._httpGetJson(url);
        if (!data || !data.result || !data.result.data || data.result.data.length === 0) break;

        for (const item of data.result.data) {
          const secucode = item.SECUCODE || '';
          const parts = secucode.split('.');
          const code = parts[0] || '';
          const suffix = parts[1] || '';
          
          let prefix = 'sz';
          if (suffix === 'SH') prefix = 'sh';
          else if (suffix === 'BJ') prefix = 'bj';

          allStocks.push({
            code, tencentSymbol: `${prefix}${code}`,
            name: item.SECURITY_NAME_ABBR || item.SECURITY_NAME || item.SECURITY_NAME_ABBR
          });
        }

        if (data.result.data.length < pageSize || page >= data.result.pages) break;
        page++;
      } catch (e) {
        console.warn(`[MarketSnapshot] 获取股票列表第${page}页失败: ${e.message}`);
        break;
      }
    }

    return allStocks;
  }

  async _fetchQuotesBatch(stockList) {
    const allQuotes = [];
    
    for (let i = 0; i < stockList.length; i += this.batchSize) {
      const batch = stockList.slice(i, i + this.batchSize);
      const symbols = batch.map(s => s.tencentSymbol).join(',');
      
      try {
        const text = await this._httpGetText(`http://qt.gtimg.cn/q=${symbols}`);
        const lines = text.split('\n').filter(l => l.includes('~'));
        
        for (const line of lines) {
          const match = line.match(/v_\w+="(.+)"/);
          if (!match) continue;
          
          const fields = match[1].split('~');
          if (fields.length < 40) continue;
          
          allQuotes.push({
            code: fields[2],
            close: this._safeNumber(fields[3]),
            prevClose: this._safeNumber(fields[4]),
            open: this._safeNumber(fields[5]),
            high: this._safeNumber(fields[33]),
            low: this._safeNumber(fields[34]),
            change_pct: this._safeNumber(fields[32]),
            volume: this._safeNumber(fields[36]),
            amount: this._safeNumber(fields[37]) * 10000
          });
        }
      } catch (e) {
        console.warn(`[MarketSnapshot] 批次 ${Math.floor(i/this.batchSize)+1} 失败: ${e.message}`);
      }
    }

    return allQuotes;
  }

  // ========== 工具函数 ==========

  _safeNumber(val) {
    if (val === null || val === undefined || val === '' || val === '-') return 0;
    const num = Number(val);
    return isNaN(num) ? 0 : num;
  }

  _getDateStr() {
    const now = new Date();
    const offset = 8 * 60;
    const local = new Date(now.getTime() + offset * 60 * 1000);
    return local.toISOString().split('T')[0];
  }

  _httpGetJson(url) {
    return new Promise((resolve, reject) => {
      const protocol = url.startsWith('https') ? https : http;
      const req = protocol.get(url, { timeout: this.timeout }, (res) => {
        let data = '';
        res.on('data', chunk => data += chunk);
        res.on('end', () => {
          try {
            resolve(JSON.parse(data));
          } catch (e) {
            reject(new Error(`JSON解析失败: ${e.message}`));
          }
        });
      });
      req.on('error', reject);
      req.on('timeout', () => {
        req.destroy();
        reject(new Error(`请求超时`));
      });
    });
  }

  _httpGetText(url) {
    return new Promise((resolve, reject) => {
      const req = http.get(url, { timeout: this.timeout }, (res) => {
        const chunks = [];
        res.on('data', chunk => chunks.push(chunk));
        res.on('end', () => {
          const buf = Buffer.concat(chunks);
          try {
            const iconv = require('iconv-lite');
            resolve(iconv.decode(buf, 'gbk'));
          } catch (e) {
            resolve(buf.toString('binary'));
          }
        });
      });
      req.on('error', reject);
      req.on('timeout', () => {
        req.destroy();
        reject(new Error(`请求超时`));
      });
    });
  }
}

// ========== 主函数 ==========

async function main() {
  const args = process.argv.slice(2);
  const options = {
    index: args.includes('--index') || args.length === 0,
    etf: args.includes('--etf') || args.length === 0,
    stocks: args.includes('--stocks') || args.length === 0
  };

  const jsonOnly = process.argv.includes('--json');
  const log = jsonOnly ? (...args) => process.stderr.write(args.join(' ') + '\n') : console.log;
  const logWarn = jsonOnly ? (...args) => process.stderr.write('[WARN] ' + args.join(' ') + '\n') : console.warn;
  
  log('📊 获取市场快照...');
  log('选项:', JSON.stringify(options));
  
  const market = new MarketSnapshot({ timeout: 15000 });
  
  try {
    const snapshot = await market.fetch(options);
    
    // --json 模式: stdout 只输出纯净 JSON，方便脚本解析
    if (jsonOnly) {
      process.stdout.write(JSON.stringify(snapshot));
    } else {
      console.log('\n' + JSON.stringify(snapshot, null, 2));
    }
    
    // 保存到文件
    const outputPath = path.join(__dirname, '../data/market_snapshot.json');
    fs.mkdirSync(path.dirname(outputPath), { recursive: true });
    fs.writeFileSync(outputPath, JSON.stringify(snapshot, null, 2));
    log(`\n💾 已保存到: ${outputPath}`);
    
    // 返回退出码
    if (snapshot.errors.length > 0) {
      logWarn(`\n⚠️ 有 ${snapshot.errors.length} 个错误`);
      process.exit(1);
    }
  } catch (error) {
    console.error('❌ 获取市场快照失败:', error.message);
    process.exit(1);
  }
}

if (require.main === module) {
  main();
}

module.exports = { MarketSnapshot };
