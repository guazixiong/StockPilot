#!/usr/bin/env node
/**
 * V4.0 stock-satellite admission review.
 * Stock candidates are assessed independently from ETF regime allocation.
 * This script never sends broker orders or invents an order when data is absent.
 */

const fs = require('fs');
const path = require('path');

const BASE = path.join(__dirname, '..');
const UNIVERSE_PATH = path.join(BASE, 'config', 'v4.0_universe.json');
const MONITOR_POOL_PATH = path.join(BASE, 'data', 'stock_monitor_pool.json');
const SELECTION_STRATEGY_PATH = path.join(BASE, 'config', 'stock_selection_strategy_v1.json');
const SNAPSHOT_PATH = path.join(BASE, 'data', 'market_snapshot.json');
const HISTORY_DIR = path.join(BASE, 'data', 'v4.0', 'history', 'stocks');
const VALIDATION_PATH = path.join(BASE, 'data', 'paper_trading_v4.0', 'stock_satellite_backtest.json');
const OUTPUT_DIR = path.join(BASE, 'data', 'paper_trading_v4.0');
const OUTPUT_PATH = path.join(OUTPUT_DIR, 'latest_stock_satellite_review.json');

function loadJson(file) {
    return JSON.parse(fs.readFileSync(file, 'utf8'));
}

function quoteCode(quote) {
    return String(quote?.code ?? quote?.symbol ?? '').replace(/^(sh|sz)/, '');
}

function loadHistory(code) {
    const file = path.join(HISTORY_DIR, `${code}.json`);
    if (!fs.existsSync(file)) return { records: [], reason: 'history_file_missing' };
    try {
        const parsed = loadJson(file);
        return { records: Array.isArray(parsed) ? parsed : parsed.records ?? [], reason: null };
    } catch (_) {
        return { records: [], reason: 'history_file_invalid' };
    }
}

function validOhlc(record) {
    const open = Number(record?.open);
    const high = Number(record?.high);
    const low = Number(record?.low);
    const close = Number(record?.close);
    return open > 0 && high > 0 && low > 0 && close > 0 && high >= Math.max(open, close) && low <= Math.min(open, close);
}

function reviewCandidate(candidate, quotes, requirements, riskRules, validationByCode) {
    const quote = quotes.get(candidate.code);
    const history = loadHistory(candidate.code);
    const validRecords = history.records.filter(validOhlc);
    const historyDays = history.records.length;
    const invalidHistoryDays = historyDays - validRecords.length;
    const missingRatio = historyDays ? invalidHistoryDays / historyDays : 1;
    const blockers = [];

    const validation = validationByCode.get(candidate.code);
    if (!validation) blockers.push('strategy_validation_missing');
    else if (validation.validationStatus !== 'PASSED_RESEARCH_ONLY') blockers.push('strategy_validation_failed');
    if (history.reason) blockers.push(history.reason);
    if (historyDays < requirements.minHistoryTradingDays) blockers.push('insufficient_history_days');
    if (missingRatio > requirements.maxMissingHistoryRatio) blockers.push('history_quality_below_threshold');
    if (!quote) blockers.push('latest_quote_missing');
    if (quote && !validOhlc(quote)) blockers.push('latest_quote_invalid_ohlc');
    if (quote && Number(quote.amount) < requirements.minLatestAmountCny) blockers.push('latest_amount_below_minimum');
    if (quote && Number(quote.volume) < requirements.minLatestVolume) blockers.push('latest_volume_below_minimum');
    if (quote && Number(quote.close) > Number(requirements.maxSelectionPrice ?? Infinity)) blockers.push('price_above_selection_limit');

    const changePct = Number(quote?.change_pct);
    if (quote && riskRules.blockBuyOnLimitUp && changePct >= 9.8) blockers.push('limit_up_buy_block');
    if (quote && riskRules.blockSellOnLimitDown && changePct <= -9.8) blockers.push('limit_down_sell_block');

    return {
        code: candidate.code,
        name: candidate.name,
        market: candidate.market,
        configuredStatus: candidate.status,
        strategyValidation: validation ? {
            status: validation.validationStatus,
            outOfSample: validation.outOfSample,
            failures: validation.failures,
        } : null,
        admissionStatus: blockers.length ? 'BLOCKED' : 'ELIGIBLE_FOR_SIGNAL',
        latestQuote: quote ? {
            tradeDate: quote.trade_date ?? null,
            close: Number(quote.close),
            changePct: Number.isFinite(changePct) ? changePct : null,
            amount: Number(quote.amount),
            volume: Number(quote.volume)
        } : null,
        coverage: { historyDays, validHistoryDays: validRecords.length, invalidHistoryDays, missingRatio: Number(missingRatio.toFixed(4)) },
        blockers,
        riskBoundary: {
            maxWeightPct: 5,
            initialStopLossPct: riskRules.initialStopLossPct * 100,
            maxParticipationRatePct: 2,
            orderLotSize: 100
        }
    };
}

function main() {
    if (!fs.existsSync(UNIVERSE_PATH)) throw new Error('missing V4.0 universe config');
    const universe = loadJson(UNIVERSE_PATH);
    const selectionStrategy = loadJson(SELECTION_STRATEGY_PATH);
    const snapshot = fs.existsSync(SNAPSHOT_PATH) ? loadJson(SNAPSHOT_PATH) : {};
    const quotes = new Map((snapshot.watchStocks ?? []).map(quote => [quoteCode(quote), quote]));
    const validation = fs.existsSync(VALIDATION_PATH) ? loadJson(VALIDATION_PATH) : { assets: [] };
    const validationByCode = new Map((validation.assets ?? []).map(asset => [asset.code, asset]));
    const monitorPool = fs.existsSync(MONITOR_POOL_PATH) ? loadJson(MONITOR_POOL_PATH) : null;
    const stockSatellite = {
        ...universe.stockSatellite,
        candidates: monitorPool?.candidates ?? universe.stockSatellite.candidates,
        dataRequirements: {
            ...universe.stockSatellite.dataRequirements,
            maxSelectionPrice: Number(selectionStrategy.universe.max_price)
        }
    };
    const reviews = stockSatellite.candidates.map(candidate => reviewCandidate(
        candidate,
        quotes,
        stockSatellite.dataRequirements,
        stockSatellite.riskRules,
        validationByCode
    ));
    const eligible = reviews.filter(item => item.admissionStatus === 'ELIGIBLE_FOR_SIGNAL');
    const result = {
        version: '4.0.0',
        generatedAt: new Date().toISOString(),
        recommendationStatus: eligible.length ? 'SIGNAL_ELIGIBLE' : 'BLOCKED_NO_ACTIONABLE_SIGNAL',
        brokerOrderSent: false,
        policy: universe.portfolioPolicy,
        regimeHandling: 'ETF core regime is independent. New stock buys are additionally blocked during BEAR.',
        counts: { candidates: reviews.length, eligible: eligible.length, blocked: reviews.length - eligible.length },
        candidates: reviews,
        notice: '个股候选通过数据准入后可生成规则化买卖提醒；提示仅供研究参考，不连接券商、不自动下单。'
    };
    fs.mkdirSync(OUTPUT_DIR, { recursive: true });
    fs.writeFileSync(OUTPUT_PATH, `${JSON.stringify(result, null, 2)}\n`);
    console.log(JSON.stringify(result, null, 2));
}

main();
