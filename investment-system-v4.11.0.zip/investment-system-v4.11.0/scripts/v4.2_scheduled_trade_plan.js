#!/usr/bin/env node
/** Stable scheduled entry point for V4.5 live-decision reports. */
const { spawnSync } = require('child_process');
const path = require('path');

const phase = process.argv[2] ?? 'close';
const BASE = path.join(__dirname, '..');
const result = spawnSync(process.execPath, [path.join(__dirname, 'v4.5_scheduled_trade_report.js'), phase], { cwd: BASE, encoding: 'utf8' });
if (result.status !== 0) {
    console.error(result.stderr || result.stdout || `V4.5 ${phase} plan failed`);
    process.exit(result.status || 1);
}
process.stdout.write(result.stdout);
