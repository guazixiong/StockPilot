#!/usr/bin/env bash
set -u
ROOT="/home/ubuntu/.openclaw/workspace/investment-system"
NODE_BIN="/home/ubuntu/.nvm/versions/node/v22.23.1/bin/node"
LOG_DIR="$ROOT/data/logs"
mkdir -p "$LOG_DIR"
exec 9>"$LOG_DIR/v4.3.lock"
flock -n 9 || exit 0
hour=$(TZ=Asia/Shanghai date +%H)
minute=$(TZ=Asia/Shanghai date +%M)
if (( (10#$hour < 9) || (10#$hour == 9 && 10#$minute < 30) || (10#$hour > 14) || (10#$hour == 11 && 10#$minute > 30) || (10#$hour == 12) )); then exit 0; fi
cd "$ROOT" || exit 1
if [[ ! -x "$NODE_BIN" ]]; then
  printf '%s\n' "V4.4 scheduler failed: Node runtime not found at $NODE_BIN" >&2
  exit 1
fi
LOG_FILE="$LOG_DIR/v4.3-$(TZ=Asia/Shanghai date +%F).log"
printf '%s start\n' "$(TZ=Asia/Shanghai date --iso-8601=seconds)" >>"$LOG_FILE"
"$NODE_BIN" scripts/run_v4.3_intraday.js >>"$LOG_FILE" 2>&1
rc=$?
printf '%s finish rc=%s\n' "$(TZ=Asia/Shanghai date --iso-8601=seconds)" "$rc" >>"$LOG_FILE"
exit "$rc"
