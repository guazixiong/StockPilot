#!/usr/bin/env python3
"""
Collect historical daily data for 11 ETFs using akshare,
save as parquet files in the snapshot directory structure.
"""
import os
import sys
import time
import datetime
import akshare as ak
import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq

# ETF codes and their metadata
ETF_INFO = {
    '159330': {'name': '沪深300ETF东财', 'market': 'SZ', 'industry': '宽基-沪深300'},
    '159107': {'name': '创业板软件ETF富国', 'market': 'SZ', 'industry': '行业-创业板软件'},
    '159599': {'name': '芯片ETF东财', 'market': 'SZ', 'industry': '行业-芯片'},
    '159611': {'name': '电力ETF', 'market': 'SZ', 'industry': '行业-电力'},
    '512010': {'name': '医药ETF易方达', 'market': 'SH', 'industry': '行业-医药'},
    '512880': {'name': '证券ETF', 'market': 'SH', 'industry': '行业-证券'},
    '513650': {'name': '标普500ETF南方', 'market': 'SH', 'industry': '跨境-标普500'},
    '513880': {'name': '日经225ETF', 'market': 'SH', 'industry': '跨境-日经225'},
    '515070': {'name': '人工智能ETF', 'market': 'SH', 'industry': '主题-人工智能'},
    '516160': {'name': '新能源ETF', 'market': 'SH', 'industry': '主题-新能源'},
    '159825': {'name': '农业ETF富国', 'market': 'SZ', 'industry': '行业-农业'},
}

SNAPSHOT_DIR = '/home/ubuntu/.openclaw/workspace/investment-system/data/snapshot'
START_DATE = '20230401'
END_DATE = '20260726'

def fetch_etf_data(code, start_date, end_date, retries=3):
    """Fetch ETF historical data with retries."""
    for attempt in range(retries):
        try:
            df = ak.fund_etf_hist_em(
                symbol=code,
                period="daily",
                start_date=start_date,
                end_date=end_date,
                adjust="qfq"
            )
            return df
        except Exception as e:
            print(f"  Attempt {attempt+1} failed for {code}: {e}")
            if attempt < retries - 1:
                time.sleep(3)
    return None

def build_snapshot_rows(code, info, df):
    """Convert akshare DataFrame to snapshot format."""
    rows = []
    for _, row in df.iterrows():
        # akshare returns: 日期, 开盘, 收盘, 最高, 最低, 成交量, 成交额, 振幅, 涨跌幅, 涨跌额, 换手率
        date_str = str(row['日期'])[:10]  # YYYY-MM-DD
        rows.append({
            'date': date_str,
            'code': code,
            'name': info['name'],
            'market': info['market'],
            'industry': info['industry'],
            'close': float(row['收盘']),
            'change_pct': float(row['涨跌幅']),
            'open': float(row['开盘']),
            'high': float(row['最高']),
            'low': float(row['最低']),
            'volume': float(row['成交量']),
            'amount': float(row['成交额']),
            'turnover': float(row['换手率']) if '换手率' in row and pd.notna(row['换手率']) else 0.0,
            'pe': None,
            'pb': None,
            'is_st': False,
            'is_suspend': False,
        })
    return rows

def save_parquet(date_str, records):
    """Save records as parquet for a given date."""
    year = date_str[:4]
    month = date_str[5:7]
    dir_path = os.path.join(SNAPSHOT_DIR, year, month)
    os.makedirs(dir_path, exist_ok=True)
    
    file_path = os.path.join(dir_path, f"{date_str}.parquet")
    
    if records:
        df = pd.DataFrame(records)
        # Ensure column order matches existing format
        cols = ['date', 'code', 'name', 'market', 'industry', 'close', 'change_pct',
                'open', 'high', 'low', 'volume', 'amount', 'turnover', 'pe', 'pb',
                'is_st', 'is_suspend']
        df = df[cols]
        df.to_parquet(file_path, index=False)
    return file_path

def main():
    all_rows_by_date = {}  # date -> [records]
    total_etfs = len(ETF_INFO)
    
    for i, (code, info) in enumerate(ETF_INFO.items()):
        print(f"[{i+1}/{total_etfs}] Fetching {code} ({info['name']})...")
        df = fetch_etf_data(code, START_DATE, END_DATE)
        
        if df is None or df.empty:
            print(f"  WARNING: No data for {code}")
            continue
        
        print(f"  Got {len(df)} rows ({df['日期'].min()} to {df['日期'].max()})")
        
        rows = build_snapshot_rows(code, info, df)
        for row in rows:
            d = row['date']
            if d not in all_rows_by_date:
                all_rows_by_date[d] = []
            all_rows_by_date[d].append(row)
        
        # Rate limit between ETFs
        if i < total_etfs - 1:
            time.sleep(1)
    
    # Save parquet files by date
    print(f"\nSaving {len(all_rows_by_date)} date files...")
    saved = 0
    for date_str in sorted(all_rows_by_date.keys()):
        records = all_rows_by_date[date_str]
        if len(records) >= 10:  # At least 10 of 11 ETFs
            save_parquet(date_str, records)
            saved += 1
    
    total_records = sum(len(v) for v in all_rows_by_date.values())
    print(f"\nDone! Saved {saved} parquet files, {total_records} total records")
    print(f"Date range: {min(all_rows_by_date.keys())} to {max(all_rows_by_date.keys())}")

if __name__ == '__main__':
    main()
