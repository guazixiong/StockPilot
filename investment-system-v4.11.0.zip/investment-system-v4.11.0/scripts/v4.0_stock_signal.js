#!/usr/bin/env node
/** Close-only stock satellite signal generator. Never creates broker orders. */
const fs = require('fs');
const path = require('path');
const BASE = path.join(__dirname, '..');
const universe = JSON.parse(fs.readFileSync(path.join(BASE, 'config/v4.0_universe.json')));
const selectionStrategy = JSON.parse(fs.readFileSync(path.join(BASE, 'config/stock_selection_strategy_v1.json')));
const monitorPoolPath = path.join(BASE, 'data/stock_monitor_pool.json');
const monitorPool = fs.existsSync(monitorPoolPath) ? JSON.parse(fs.readFileSync(monitorPoolPath)) : null;
const snapshot = JSON.parse(fs.readFileSync(path.join(BASE, 'data/market_snapshot.json')));
const holdings = JSON.parse(fs.readFileSync(path.join(BASE, 'config/holdings.json')));
const validationPath = path.join(BASE, 'data/paper_trading_v4.0/stock_satellite_backtest.json');
const out = path.join(BASE, 'data/paper_trading_v4.0/latest_stock_signals.json');
const quoteByCode = new Map((snapshot.watchStocks ?? []).map(q => [String(q.code).replace(/^(sh|sz)/, ''), q]));
const validation = fs.existsSync(validationPath) ? JSON.parse(fs.readFileSync(validationPath, 'utf8')) : { assets: [] };
const validationByCode = new Map((validation.assets ?? []).map(asset => [asset.code, asset]));
const etfQuoteByCode = new Map((snapshot.etfs ?? []).map(q => [String(q.code ?? q.symbol ?? '').replace(/^(sh|sz)/, ''), q]));
const totalPortfolioValue = Number(holdings.available_cash) + holdings.holdings.reduce((total, holding) => {
    const quote = etfQuoteByCode.get(String(holding.code));
    const price = Number(quote?.close);
    return total + Number(holding.shares) * (price > 0 ? price : Number(holding.cost));
}, 0);
function rows(code) { const file = path.join(BASE, 'data/v4.0/history/stocks', `${code}.json`); return fs.existsSync(file) ? JSON.parse(fs.readFileSync(file)) : []; }
function avg(values) { return values.reduce((a, b) => a + b, 0) / values.length; }
function validQuote(quote) {
    return Number(quote?.open) > 0 && Number(quote?.high) > 0 && Number(quote?.low) > 0 &&
        Number(quote?.close) > 0 && Number(quote.high) >= Math.max(Number(quote.open), Number(quote.close)) &&
        Number(quote.low) <= Math.min(Number(quote.open), Number(quote.close));
}
const candidates = monitorPool?.candidates ?? universe.stockSatellite.candidates;
const signals = candidates.map(candidate => {
    const history = rows(candidate.code);
    const q = quoteByCode.get(candidate.code);
    const validationResult = validationByCode.get(candidate.code);
    const closes = history.map(x => Number(x.close)).filter(Number.isFinite);
    const selectedVariant = validation.selectedVariant ?? { fast: 20, slow: 60, stopPct: 0.10 };
    const recent = closes.slice(-selectedVariant.slow);
    const sma20 = recent.length >= selectedVariant.fast ? avg(recent.slice(-selectedVariant.fast)) : null;
    const sma60 = recent.length >= selectedVariant.slow ? avg(recent) : null;
    const close = Number(q?.close);
    const change = Number(q?.change_pct);
    const latestHistoryDate = history.at(-1)?.date ?? null;
    const quoteValid = validQuote(q);
    const quoteSynchronized = quoteValid && latestHistoryDate === q?.trade_date;
    const dataReady = history.length >= 252 && sma20 && sma60 && close > 0 && quoteSynchronized;
    const trendPass = Boolean(dataReady && close > sma20 && sma20 > sma60);
    const blockers = [];
    if (!validationResult) blockers.push('strategy_validation_missing');
    else if (validationResult.validationStatus !== 'PASSED_RESEARCH_ONLY') blockers.push('strategy_validation_failed');
    if (!dataReady) blockers.push('insufficient_signal_data');
    if (!q || !Number.isFinite(change)) blockers.push('latest_quote_missing');
    else if (close > Number(selectionStrategy.universe.max_price)) blockers.push('price_above_selection_limit');
    else if (!quoteValid) blockers.push('latest_quote_invalid_ohlc');
    else if (!quoteSynchronized) blockers.push('history_quote_date_mismatch');
    if (universe.stockSatellite.riskRules.blockBuyOnLimitUp && change >= 9.8) blockers.push('limit_up_buy_block');
    const maxPositionAmount = Math.min(totalPortfolioValue * universe.portfolioPolicy.singleStockMaxWeight, Number(holdings.available_cash));
    const lotSize = universe.portfolioPolicy.stockLotSize;
    const suggestedShares = close > 0 ? Math.floor(maxPositionAmount / close / lotSize) * lotSize : 0;
    const minimumLotAmount = close > 0 ? Number((close * lotSize).toFixed(2)) : null;
    const minimumLotWeightPct = minimumLotAmount && totalPortfolioValue > 0
        ? Number((minimumLotAmount / totalPortfolioValue * 100).toFixed(2))
        : null;
    const sizingStatus = suggestedShares > 0 ? 'WITHIN_POSITION_LIMIT' : 'ONE_LOT_EXCEEDS_SINGLE_STOCK_LIMIT';
    const stopLossPrice = close ? Number((close * (1 - selectedVariant.stopPct)).toFixed(2)) : null;
    const takeProfitPrice = close ? Number((close * (1 + universe.stockSatellite.riskRules.takeProfitTargetPct)).toFixed(2)) : null;
    const status = blockers.length ? 'BLOCKED' : trendPass ? 'WATCH_BUY_SETUP' : 'NO_SIGNAL';
    return {
        code: candidate.code, name: candidate.name, signalDate: q?.trade_date ?? null, historyDate: latestHistoryDate, status, trendPass,
        close: close || null, sma20, sma60, selectedVariant: selectedVariant.id, referencePrice: close || null,
        suggestedRange: close ? { lower: Number((close * .98).toFixed(2)), upper: Number((close * 1.01).toFixed(2)) } : null,
        strategyValidation: validationResult?.validationStatus ?? 'MISSING', blockers,
        positionPlan: { maxWeightPct: universe.portfolioPolicy.singleStockMaxWeight * 100, maxAmount: Number(maxPositionAmount.toFixed(2)), suggestedShares, estimatedAmount: Number((suggestedShares * close).toFixed(2)), minimumLotShares: lotSize, minimumLotAmount, minimumLotWeightPct, sizingStatus, lotSize },
        riskPlan: { stopLossPrice, stopLossPct: Number((-selectedVariant.stopPct * 100).toFixed(2)), takeProfitPrice, takeProfitTargetPct: Number((universe.stockSatellite.riskRules.takeProfitTargetPct * 100).toFixed(2)), trendExit: `收盘价跌破 SMA${selectedVariant.fast}（当前 ${sma20 ? sma20.toFixed(2) : '不可用'}）` },
        maxParticipationRatePct: universe.portfolioPolicy.maxParticipationRate * 100
    };
});
const result = { version: '4.2.0', generatedAt: new Date().toISOString(), source: 'daily-close-only', portfolioValueForSizing: Number(totalPortfolioValue.toFixed(2)), brokerOrderSent: false, signals };
fs.mkdirSync(path.dirname(out), { recursive: true });
fs.writeFileSync(out, `${JSON.stringify(result, null, 2)}\n`);
console.log(JSON.stringify(result, null, 2));
