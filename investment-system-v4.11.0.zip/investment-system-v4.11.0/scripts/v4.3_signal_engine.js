#!/usr/bin/env node
/** V4.3 deterministic intraday signal layer. No broker or Feishu side effects. */
const fs = require('fs');
const path = require('path');

const BASE = path.join(__dirname, '..');
const SNAPSHOT = path.join(BASE, 'data', 'market_snapshot.json');
const PLAN = path.join(BASE, 'config', 'v4.1_manual_alert_plan.json');
const DECISIONS = path.join(BASE, 'data', 'paper_trading_v4.0', 'latest_live_trade_decisions.json');
const OUTPUT = path.join(BASE, 'data', 'paper_trading_v4.0', 'latest_v4.3_signals.json');
const HOLDINGS = path.join(BASE, 'config', 'holdings.json');
const BACKTEST = path.join(BASE, 'data', 'paper_trading_v4.0', 'v4.3_layered_backtest.json');
const { allocate } = require('./portfolio_allocator_v4.3');

const load = file => JSON.parse(fs.readFileSync(file, 'utf8'));
const n = (v, fallback = 0) => Number.isFinite(Number(v)) ? Number(v) : fallback;
const round = (v, d = 3) => Number(n(v).toFixed(d));
const inRange = (v, range) => n(v) >= n(range?.[0]) && n(v) <= n(range?.[1]);

function quoteMap(snapshot) {
    return new Map((snapshot.etfs || []).map(q => [String(q.symbol || '').replace(/^(sh|sz)/, ''), q]));
}

function classify(plan, quote, liveAction) {
    const close = n(quote?.close);
    if (!close) return { level: 'BLOCKED', reason: '行情缺失' };
    if (liveAction?.action === 'BUY') return { level: 'BUY', reason: liveAction.reason, executable: true };
    if (liveAction?.action === 'SELL_ALL' || liveAction?.action === 'SELL_PARTIAL') {
        return { level: 'RISK', reason: liveAction.reason, executable: true };
    }
    if (close > n(plan.doNotChaseAbove)) return { level: 'WATCH', reason: `高于追价上限 ${plan.doNotChaseAbove}` };
    if (inRange(close, plan.firstBuyRange)) {
        return { level: 'PROBE_BUY', reason: '进入首笔试探区间，等待趋势确认', executable: true, range: plan.firstBuyRange };
    }
    if (inRange(close, plan.addBuyRange)) {
        return { level: 'PROBE_BUY', reason: '进入回落试探区间，禁止追价', executable: true, range: plan.addBuyRange };
    }
    const distance = Math.min(
        Math.abs(close - n(plan.firstBuyRange?.[0])),
        Math.abs(close - n(plan.firstBuyRange?.[1])),
        Math.abs(close - n(plan.addBuyRange?.[0])),
        Math.abs(close - n(plan.addBuyRange?.[1]))
    );
    return { level: 'WATCH', reason: `未进入建仓区间，最近触发距离 ${round(distance, 3)}` };
}

function applyDecisionMode(signal, item, plan, sizing) {
    const policy = plan.decisionModePolicy || {};
    if (plan.decisionMode !== 'formal_only_low_capital') return signal;
    if (signal.level === 'PROBE_BUY') {
        return { ...signal, level: 'WATCH', executable: false, reason: '低本金确定性模式：试探仓不执行，等待正式买入条件' };
    }
    if (signal.level === 'BUY') {
        const amount = n(sizing?.estimatedAmount);
        const commission = n(sizing?.estimatedCommission);
        const commissionPct = amount > 0 ? commission / amount : Infinity;
        if (amount < n(policy.minOrderAmount, 1000)) return { ...signal, level: 'WATCH', executable: false, reason: `低本金模式：订单金额低于最低门槛 ${policy.minOrderAmount}` };
        if (commissionPct > n(policy.maxCommissionPctOfOrder, 0.005)) return { ...signal, level: 'WATCH', executable: false, reason: '低本金模式：预计手续费占比过高' };
        if (policy.requireFormalValidation && item.validationStatus !== 'PASSED') return { ...signal, level: 'WATCH', executable: false, reason: '正式验证尚未通过，不生成买入提醒' };
    }
    return signal;
}

function main() {
    const snapshot = load(SNAPSHOT);
    const plan = load(PLAN);
    const live = fs.existsSync(DECISIONS) ? load(DECISIONS) : { actions: [] };
    const backtest = fs.existsSync(BACKTEST) ? load(BACKTEST) : { assets: [] };
    const validationByCode = new Map((backtest.assets || []).map(x => [String(x.code), x.validationStatus || 'UNKNOWN']));
    const liveByCode = new Map((live.actions || []).map(x => [String(x.code), x]));
    const quotes = quoteMap(snapshot);
    const holdings = fs.existsSync(HOLDINGS) ? load(HOLDINGS) : { holdings: [], available_cash: 0 };
    const portfolioValue = (holdings.holdings || []).reduce((sum, h) => sum + n(h.shares) * n(quotes.get(String(h.code))?.close, n(h.cost)), 0) + n(holdings.available_cash);
    const allocation = { portfolioValue: round(portfolioValue, 2), probeMaxWeight: n(plan.allocationPolicy?.probeMaxWeight, 0.15), singleProbeMaxWeight: n(plan.allocationPolicy?.singleProbeMaxWeight, 0.03), singleFormalMaxWeight: n(plan.allocationPolicy?.singleFormalMaxWeight, 0.05), singleOrderMaxWeight: n(plan.allocationPolicy?.singleOrderMaxWeight, 0.1), availableCash: n(holdings.available_cash), brokerOrderSent: false, note: '组合资金口径以持仓文件为准；可用现金未知或为0时不生成下单金额。' };
    const signals = (plan.buyPlans || []).filter(x => x.enabled !== false).map(item => {
        const code = String(item.code), quote = quotes.get(code), result = classify(item, quote, liveByCode.get(code));
        const validationStatus = validationByCode.get(code) || item.validationStatus || 'UNKNOWN';
        const validatedItem = { ...item, validationStatus };
        const sizing = result.executable ? allocate({ price: quote?.close, availableCash: holdings.available_cash, portfolioValue, targetAmount: item.targetAmount, level: result.level, policy: { ...plan.executionPolicy, ...plan.allocationPolicy } }) : null;
        const gated = applyDecisionMode(result, validatedItem, plan, sizing);
        const executable = Boolean(gated.executable && sizing?.status === 'PAPER_ORDER_READY');
        return { code, name: item.name, assetType: 'etf', level: executable ? gated.level : gated.level === 'PROBE_BUY' ? 'WATCH' : gated.level, executable, close: round(quote?.close), changePct: round(quote?.change_pct, 2), range: gated.range || null, validationStatus, reason: executable ? gated.reason : sizing?.status === 'BLOCKED_CASH_UNKNOWN_OR_ZERO' ? '进入价格区间，但可用现金为0或未提供，不能生成金额' : gated.reason, sizing, quoteDate: quote?.trade_date || null };
    });
    for (const action of live.actions || []) {
        if (!signals.some(x => x.code === String(action.code))) {
            const isBuy = action.action === 'BUY';
            signals.push({
                code: String(action.code), name: action.name, assetType: action.assetType || 'unknown',
                level: isBuy && plan.decisionMode === 'formal_only_low_capital' ? 'WATCH' : isBuy ? 'BUY' : 'RISK',
                executable: !isBuy, close: round(action.close),
                reason: isBuy && plan.decisionMode === 'formal_only_low_capital' ? '低本金确定性模式：实时买入信号仍需正式验证通过' : action.reason,
                quoteDate: action.quoteDate || null
            });
        }
    }
    const result = { version: '4.4.0', generatedAt: new Date().toISOString(), quoteTimestamp: snapshot.timestamp || null, decisionMode: plan.decisionMode, allocation, signals, counts: signals.reduce((a, x) => { a[x.level] = (a[x.level] || 0) + 1; return a; }, {}), brokerOrderSent: false, notice: 'V4.4 纯规则确定性机会闸门；仅生成人工研究提醒，不连接券商。' };
    fs.writeFileSync(OUTPUT, `${JSON.stringify(result, null, 2)}\n`);
    console.log(JSON.stringify(result, null, 2));
}
if (require.main === module) main();
module.exports = { classify };
