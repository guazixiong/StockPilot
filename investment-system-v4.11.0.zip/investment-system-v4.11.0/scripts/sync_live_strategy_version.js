#!/usr/bin/env node
/** Keep one strategy release version for all live decision artifacts. */
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const BASE = path.join(__dirname, '..');
const VERSION_PATH = path.join(BASE, 'config', 'live_strategy_version.json');
const RULE_SOURCES = [
    path.join(BASE, 'config', 'v4.1_manual_alert_plan.json'),
    path.join(__dirname, 'v4.2_live_decision_engine.js'),
    path.join(__dirname, 'v4.1_intraday_manual_alert.js'),
    path.join(__dirname, 'v4.5_scheduled_trade_report.js')
];

function fingerprint() {
    const hash = crypto.createHash('sha256');
    for (const file of RULE_SOURCES) {
        hash.update(path.basename(file));
        hash.update(fs.readFileSync(file));
    }
    return hash.digest('hex');
}

function nextMinor(version) {
    const match = /^(\d+)\.(\d+)\.(\d+)$/.exec(version);
    if (!match) throw new Error(`invalid semantic version: ${version}`);
    return `${match[1]}.${Number(match[2]) + 1}.0`;
}

function sync() {
    const registry = JSON.parse(fs.readFileSync(VERSION_PATH, 'utf8'));
    const currentFingerprint = fingerprint();
    const changed = registry.ruleFingerprint !== currentFingerprint;
    const result = {
        ...registry,
        version: changed ? nextMinor(registry.version) : registry.version,
        ruleFingerprint: currentFingerprint,
        updated: changed ? new Date().toISOString() : registry.updated
    };
    fs.writeFileSync(VERSION_PATH, `${JSON.stringify(result, null, 2)}\n`);
    return { version: result.version, changed };
}

if (require.main === module) console.log(JSON.stringify(sync()));
module.exports = { sync };
