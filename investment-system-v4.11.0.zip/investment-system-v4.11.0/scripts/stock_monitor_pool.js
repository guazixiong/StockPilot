#!/usr/bin/env node
/** Build the combined stock monitor pool: permanent watchlist + rolling 7-day selections. */
const fs = require('fs');
const path = require('path');

const BASE = path.join(__dirname, '..');
const UNIVERSE = path.join(BASE, 'config', 'v4.0_universe.json');
const HISTORY = path.join(BASE, 'data', 'stock_selection_history.json');
const OUTPUT = path.join(BASE, 'data', 'stock_monitor_pool.json');
const HOLDINGS = path.join(BASE, 'config', 'holdings.json');
const ROLLING_DAYS = 7;

function load(file, fallback) {
  try { return fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : fallback; }
  catch { return fallback; }
}

function codeOf(item) { return String(item?.code ?? '').replace(/^(sh|sz|bj)/, ''); }
function cutoff() { return Date.now() - ROLLING_DAYS * 86400000; }

function main() {
  const universe = load(UNIVERSE, {});
  const base = universe.stockSatellite?.candidates ?? [];
  const history = load(HISTORY, []);
  const byCode = new Map(base.map(item => [codeOf(item), { ...item, source: 'permanent_watchlist' }]));
  // Real holdings are always monitored, even when absent from the watchlist.
  for (const item of load(HOLDINGS, {}).holdings ?? []) {
    const code = codeOf(item);
    if (!/^\d{6}$/.test(code)) continue;
    const existing = byCode.get(code);
    byCode.set(code, {
      ...(existing ?? {}), code, name: item.name ?? existing?.name ?? code,
      market: item.market ?? existing?.market ?? (code.startsWith('6') ? 'SH' : 'SZ'),
      source: existing ? `${existing.source}+actual_holding` : 'actual_holding',
      holding: true
    });
  }
  const recent = [];
  for (const batch of Array.isArray(history) ? history : []) {
    const timestamp = Date.parse(batch.generatedAt ?? batch.date ?? '');
    if (!Number.isFinite(timestamp) || timestamp < cutoff()) continue;
    for (const item of batch.candidates ?? batch.stocks ?? []) {
      const code = codeOf(item);
      if (!/^\d{6}$/.test(code)) continue;
      const existing = byCode.get(code);
      byCode.set(code, {
        ...(existing ?? {}),
        code,
        name: item.name ?? existing?.name ?? code,
        market: item.market ?? existing?.market ?? (code.startsWith('6') ? 'SH' : 'SZ'),
        status: item.status ?? existing?.status ?? 'RECENT_SELECTION',
        source: existing ? 'permanent_watchlist+recent_selection' : 'recent_selection',
        selectedAt: batch.generatedAt ?? batch.date
      });
      if (!existing) recent.push(code);
    }
  }
  const candidates = [...byCode.values()].sort((a, b) => a.code.localeCompare(b.code));
  const result = {
    version: 'monitor-pool-v1', generatedAt: new Date().toISOString(), rollingDays: ROLLING_DAYS,
    counts: { permanent: base.length, recentAdded: recent.length, total: candidates.length },
    candidates
  };
  fs.writeFileSync(OUTPUT, `${JSON.stringify(result, null, 2)}\n`);
  console.log(JSON.stringify(result, null, 2));
}

if (require.main === module) main();
module.exports = { main, OUTPUT };
