#!/usr/bin/env node
/** V4.4 deterministic alert throttling. Emits at most one digest per run. */
const fs = require('fs');
const path = require('path');
const BASE = path.join(__dirname, '..');
const SIGNALS = path.join(BASE, 'data', 'paper_trading_v4.0', 'latest_v4.3_signals.json');
const STATE = path.join(BASE, 'data', 'paper_trading_v4.0', 'v4.3_alert_state.json');
const CONFIG = path.join(BASE, 'config', 'v4.1_manual_alert_plan.json');
const load = f => JSON.parse(fs.readFileSync(f, 'utf8'));
const now = Date.now();
const cfg = load(CONFIG), signals = load(SIGNALS), state = fs.existsSync(STATE) ? load(STATE) : { lastSentAt: 0, sentToday: 0, date: null, items: {} };
const date = new Intl.DateTimeFormat('en-CA', { timeZone: 'Asia/Shanghai' }).format(new Date());
if (state.date !== date) { state.date = date; state.sentToday = 0; state.sentTimestamps = []; }
state.sentTimestamps = (state.sentTimestamps || []).filter(t => now - t < 60 * 60 * 1000);
const priority = { RISK: 1, BUY: 2, PROBE_BUY: 3, WATCH: 9 };
function intervalMs(value) { return Number(value || 30) * 60 * 1000; }
const candidates = signals.signals.filter(s => ['RISK', 'BUY', 'PROBE_BUY'].includes(s.level)).sort((a, b) => priority[a.level] - priority[b.level]);
const eligible = candidates.filter(s => {
    const key = `${s.code}:${s.level}:${s.reason}`;
    const previous = state.items[key];
    return (!previous || now - previous.sentAt >= intervalMs(cfg.maxAlertIntervalMinutes)) && (!state.lastSentAt || now - state.lastSentAt >= Number(cfg.alertRateLimit?.minIntervalSeconds ?? 10) * 1000);
}).slice(0, Number(cfg.alertRateLimit?.maxItemsPerDigest ?? 8));
let message = 'NO_REPLY';
if (eligible.length && state.sentToday < Number(cfg.alertRateLimit?.maxPerDay ?? 30) && state.sentTimestamps.length < Number(cfg.alertRateLimit?.maxPerHour ?? 6)) {
    message = [`🔔 V4.4 确定性机会/风险信号 | ${date}`, ...eligible.map(s => `- 【${s.level}】${s.name}（${s.code}）现价 ${s.close}，${s.reason}${s.range ? `；区间 ${s.range[0]}-${s.range[1]}` : ''}`), '- 低本金模式不提醒试探仓；同一条件30分钟去重；仅人工执行，不自动下单。'].join('\n');
    state.lastSentAt = now;
    state.sentToday += 1;
    state.sentTimestamps.push(now);
    for (const s of eligible) state.items[`${s.code}:${s.level}:${s.reason}`] = { sentAt: now, price: s.close };
}
fs.writeFileSync(STATE, `${JSON.stringify(state, null, 2)}\n`);
console.log(message);
