#!/usr/bin/env node
/** Deterministic V4.3 sizing. This module calculates paper/manual quantities only. */
const fs = require('fs');
const path = require('path');

const BASE = path.join(__dirname, '..');
const PLAN_PATH = path.join(BASE, 'config', 'v4.1_manual_alert_plan.json');
const HOLDINGS_PATH = path.join(BASE, 'config', 'holdings.json');

const load = file => JSON.parse(fs.readFileSync(file, 'utf8'));
const number = (value, fallback = 0) => Number.isFinite(Number(value)) ? Number(value) : fallback;
const roundLot = (shares, lot) => Math.floor(Math.max(0, shares) / lot) * lot;

function allocate({ price, availableCash, portfolioValue, currentShares = 0, targetAmount, level = 'PROBE_BUY', policy }) {
    const close = number(price);
    const cash = Math.max(0, number(availableCash));
    const nav = Math.max(0, number(portfolioValue));
    const heldValue = Math.max(0, number(currentShares)) * close;
    const maxWeight = level === 'PROBE_BUY'
        ? number(policy.singleProbeMaxWeight, 0.03)
        : number(policy.singleFormalMaxWeight, 0.05);
    const maxPositionValue = nav * maxWeight;
    const desiredValue = Math.min(Math.max(0, number(targetAmount)), Math.max(0, maxPositionValue - heldValue));
    const lotSize = Math.max(1, Math.floor(number(policy.lotSize, 100)));
    const shares = close > 0 ? roundLot(Math.min(desiredValue, cash) / close, lotSize) : 0;
    const amount = Number((shares * close).toFixed(2));
    const commission = Number(Math.max(number(policy.minimumCommission), amount * number(policy.commissionRate)).toFixed(2));
    const executable = shares > 0 && amount + commission <= cash;
    return {
        level, price: close, availableCash: cash, portfolioValue: nav, currentShares: number(currentShares),
        maxWeightPct: Number((maxWeight * 100).toFixed(2)), maxPositionValue: Number(maxPositionValue.toFixed(2)),
        targetAmount: Number(number(targetAmount).toFixed(2)), shares: executable ? shares : 0,
        estimatedAmount: executable ? amount : 0, estimatedCommission: executable ? commission : 0,
        totalCashRequired: executable ? Number((amount + commission).toFixed(2)) : 0,
        status: executable ? 'PAPER_ORDER_READY' : cash <= 0 ? 'BLOCKED_CASH_UNKNOWN_OR_ZERO' : 'BLOCKED_BELOW_ONE_LOT_OR_LIMIT',
        brokerOrderSent: false
    };
}

function main() {
    const plan = load(PLAN_PATH), holdings = load(HOLDINGS_PATH);
    const portfolioValue = number(holdings.available_cash) + (holdings.holdings || []).reduce((sum, item) => sum + number(item.shares) * number(item.cost), 0);
    const result = { version: '4.3.0', brokerOrderSent: false, portfolioValue, availableCash: number(holdings.available_cash), allocations: [] };
    for (const item of plan.buyPlans || []) {
        result.allocations.push(allocate({
            price: 0, availableCash: holdings.available_cash, portfolioValue,
            targetAmount: item.targetAmount, policy: { ...plan.executionPolicy, ...plan.allocationPolicy }
        }));
    }
    console.log(JSON.stringify(result, null, 2));
}

if (require.main === module) main();
module.exports = { allocate };
