#!/usr/bin/env node
/** Refresh V4.2 inputs and emit the single live-ready manual trade alert. */
const { spawnSync } = require('child_process');
const path = require('path');

const BASE = path.join(__dirname, '..');
function run(script, args = []) {
    const result = spawnSync(process.execPath, [path.join(__dirname, script), ...args], { cwd: BASE, encoding: 'utf8' });
    if (result.status !== 0) throw new Error(result.stderr || result.stdout || `${script} failed`);
    return result.stdout.trim();
}

try {
    run('fetch_market_snapshot.js', ['--index', '--etf', '--json']);
    run('v4.0_stock_signal.js');
    run('v4.0_stock_satellite_review.js');
    run('v4.2_live_decision_engine.js');
    console.log(run('v4.1_intraday_manual_alert.js') || 'NO_REPLY');
} catch (error) {
    console.error(`V4.2 live trade cycle failed: ${error.message}`);
    process.exit(1);
}
