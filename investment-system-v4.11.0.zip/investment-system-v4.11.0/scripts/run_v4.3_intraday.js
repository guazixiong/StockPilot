#!/usr/bin/env node
/** V4.4 intraday cycle: refresh all monitored quotes, calculate, throttle. */
const { spawnSync } = require('child_process');
const path = require('path');
const BASE = path.join(__dirname, '..');
function run(script, args = []) { const r = spawnSync(process.execPath, [path.join(__dirname, script), ...args], { cwd: BASE, encoding: 'utf8' }); if (r.status !== 0) throw new Error(r.stderr || r.stdout || `${script} failed`); return r.stdout.trim(); }
try {
    run('stock_monitor_pool.js');
    const snapshotRun = spawnSync(process.execPath, [path.join(__dirname, 'fetch_market_snapshot.js'), '--index', '--etf', '--stocks', '--json'], { cwd: BASE, encoding: 'utf8' });
    // fetch_market_snapshot writes the artifact before returning its status;
    // accept a non-zero status only when the persisted snapshot is complete.
    const snapshotPath = path.join(BASE, 'data', 'market_snapshot.json');
    if (!require('fs').existsSync(snapshotPath)) throw new Error(snapshotRun.stderr || snapshotRun.stdout || 'market snapshot missing');
    const snapshot = JSON.parse(require('fs').readFileSync(snapshotPath, 'utf8'));
    if (snapshotRun.status !== 0 && (snapshot.errors || []).length) throw new Error(`market snapshot errors: ${JSON.stringify(snapshot.errors)}`);
    run('v4.0_stock_signal.js');
    run('v4.0_stock_satellite_review.js');
    run('v4.2_live_decision_engine.js');
    run('v4.3_signal_engine.js');
    console.log(run('v4.3_alert_router.js') || 'NO_REPLY');
} catch (error) { console.error(`V4.3 intraday cycle failed: ${error.message}`); process.exit(1); }
