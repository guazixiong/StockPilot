#!/usr/bin/env python3
"""
Collect historical daily data for 11 ETFs using Sina Finance API,
save as parquet files in the snapshot directory structure.
"""
import os
import sys
import time
import json
import re
import datetime
import requests
import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq

# ETF codes and their metadata
ETF_INFO = {
    '159330': {'name': '沪深300ETF东财', 'market': 'SZ', 'industry': '宽基-沪深300'},
    '159107': {'name': '创业板软件ETF富国', 'market': 'SZ', 'industry': '行业-创业板软件'},
    '159599': {'name': '芯片ETF东财', 'market': 'SZ', 'industry': '行业-芯片'},
    '159611': {'name': '电力ETF', 'market': 'SZ', 'industry': '行业-电力'},
    '512010': {'name': '医药ETF易方达', 'market': 'SH', 'industry': '行业-医药'},
    '512880': {'name': '证券ETF', 'market': 'SH', 'industry': '行业-证券'},
    '513650': {'name': '标普500ETF南方', 'market': 'SH', 'industry': '跨境-标普500'},
    '513880': {'name': '日经225ETF', 'market': 'SH', 'industry': '跨境-日经225'},
    '515070': {'name': '人工智能ETF', 'market': 'SH', 'industry': '主题-人工智能'},
    '516160': {'name': '新能源ETF', 'market': 'SH', 'industry': '主题-新能源'},
    '159825': {'name': '农业ETF富国', 'market': 'SZ', 'industry': '行业-农业'},
}

SNAPSHOT_DIR = '/home/ubuntu/.openclaw/workspace/investment-system/data/snapshot'
START_DATE = '2023-04-01'
END_DATE = '2026-07-26'

def fetch_sina_data(code, market):
    """Fetch ETF historical data from Sina Finance API."""
    symbol = f"{market.lower()}{code}"
    url = f"https://quotes.sina.cn/cn/api/jsonp_v2.php/var%20_suggestdata_{code}=/CN_MarketDataService.getKLineData?symbol={symbol}&scale=240&ma=no&datalen=1000"
    
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Referer': 'https://finance.sina.com.cn/',
    }
    
    try:
        resp = requests.get(url, headers=headers, timeout=15)
        resp.raise_for_status()
        data = resp.text
        
        # Extract JSON array from JSONP response
        match = re.search(r'\(\[.*\]\)', data)
        if match:
            arr = json.loads(match.group().strip('()'))
            return arr
    except Exception as e:
        print(f"  Error fetching {code}: {e}")
    return None

def build_snapshot_rows(code, info, data_arr):
    """Convert Sina data array to snapshot format rows."""
    rows = []
    for item in data_arr:
        date_str = item['day']
        # Filter by date range
        if date_str < START_DATE or date_str > END_DATE:
            continue
        
        open_price = float(item['open'])
        high_price = float(item['high'])
        low_price = float(item['low'])
        close_price = float(item['close'])
        volume = float(item['volume'])
        
        # Calculate change_pct from close prices (need prev close)
        rows.append({
            'date': date_str,
            'code': code,
            'name': info['name'],
            'market': info['market'],
            'industry': info['industry'],
            'close': close_price,
            'change_pct': 0.0,  # Will calculate after sorting
            'open': open_price,
            'high': high_price,
            'low': low_price,
            'volume': volume,
            'amount': volume * close_price,  # Approximate amount
            'turnover': 0.0,
            'pe': None,
            'pb': None,
            'is_st': False,
            'is_suspend': False,
            '_sort_key': date_str,
        })
    
    # Calculate change_pct
    rows.sort(key=lambda x: x['_sort_key'])
    for i in range(len(rows)):
        if i > 0:
            prev_close = rows[i-1]['close']
            if prev_close > 0:
                rows[i]['change_pct'] = round((rows[i]['close'] - prev_close) / prev_close * 100, 2)
        del rows[i]['_sort_key']
    
    return rows

def save_parquet(date_str, records):
    """Save records as parquet for a given date."""
    year = date_str[:4]
    month = date_str[5:7]
    dir_path = os.path.join(SNAPSHOT_DIR, year, month)
    os.makedirs(dir_path, exist_ok=True)
    
    file_path = os.path.join(dir_path, f"{date_str}.parquet")
    
    if records:
        df = pd.DataFrame(records)
        # Ensure column order matches existing format
        cols = ['date', 'code', 'name', 'market', 'industry', 'close', 'change_pct',
                'open', 'high', 'low', 'volume', 'amount', 'turnover', 'pe', 'pb',
                'is_st', 'is_suspend']
        df = df[cols]
        df.to_parquet(file_path, index=False)
    return file_path

def main():
    all_rows_by_date = {}  # date -> [records]
    total_etfs = len(ETF_INFO)
    
    for i, (code, info) in enumerate(ETF_INFO.items()):
        print(f"[{i+1}/{total_etfs}] Fetching {code} ({info['name']})...")
        data_arr = fetch_sina_data(code, info['market'])
        
        if data_arr is None:
            print(f"  WARNING: No data for {code}")
            continue
        
        print(f"  Got {len(data_arr)} raw rows")
        
        rows = build_snapshot_rows(code, info, data_arr)
        print(f"  Filtered to {len(rows)} rows in range")
        
        for row in rows:
            d = row['date']
            if d not in all_rows_by_date:
                all_rows_by_date[d] = []
            all_rows_by_date[d].append(row)
        
        # Rate limit between ETFs
        if i < total_etfs - 1:
            time.sleep(0.5)
    
    # Save parquet files by date
    print(f"\nSaving {len(all_rows_by_date)} date files...")
    saved = 0
    for date_str in sorted(all_rows_by_date.keys()):
        records = all_rows_by_date[date_str]
        # Save if at least 8 of 11 ETFs (some newer ETFs don't have full history)
        if len(records) >= 8:
            save_parquet(date_str, records)
            saved += 1
    
    total_records = sum(len(v) for v in all_rows_by_date.values())
    print(f"\nDone! Saved {saved} parquet files, {total_records} total records")
    if all_rows_by_date:
        print(f"Date range: {min(all_rows_by_date.keys())} to {max(all_rows_by_date.keys())}")

if __name__ == '__main__':
    main()
