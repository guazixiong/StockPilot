#!/usr/bin/env node
/**
 * V4.2 single decision layer for live-ready manual execution.
 * It reads actual holdings and current quotes, but never places broker orders.
 */
const fs = require('fs');
const path = require('path');

const BASE = path.join(__dirname, '..');
const HOLDINGS_PATH = path.join(BASE, 'config', 'holdings.json');
const PLAN_PATH = path.join(BASE, 'config', 'v4.1_manual_alert_plan.json');
const UNIVERSE_PATH = path.join(BASE, 'config', 'v4.0_universe.json');
const SNAPSHOT_PATH = path.join(BASE, 'data', 'market_snapshot.json');
const STOCK_SIGNALS_PATH = path.join(BASE, 'data', 'paper_trading_v4.0', 'latest_stock_signals.json');
const STOCK_REVIEW_PATH = path.join(BASE, 'data', 'paper_trading_v4.0', 'latest_stock_satellite_review.json');
const MONITOR_POOL_PATH = path.join(BASE, 'data', 'stock_monitor_pool.json');
const STATE_PATH = path.join(BASE, 'data', 'paper_trading_v4.0', 'state.json');
const OUTPUT_PATH = path.join(BASE, 'data', 'paper_trading_v4.0', 'latest_live_trade_decisions.json');
const HISTORY_DIR = path.join(BASE, 'data', 'research_v4', 'raw');
const { sync: syncStrategyVersion } = require('./sync_live_strategy_version');

function load(file, fallback = null) {
    return fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : fallback;
}

function codeOf(item) {
    return String(item?.code ?? item?.symbol ?? '').replace(/^(sh|sz)/, '');
}

function roundLot(shares, lot = 100) {
    return Math.floor(Math.max(0, Number(shares) || 0) / lot) * lot;
}

function price(value, digits = 3) {
    return Number(Number(value).toFixed(digits));
}

function estimateCommission(amount, policy) {
    return Math.max(Number(policy.minimumCommission) || 0, amount * (Number(policy.commissionRate) || 0));
}

function minimumEfficientOrderAmount(policy) {
    const maxRate = Number(policy.maxEffectiveCommissionRate);
    const minimumCommission = Number(policy.minimumCommission) || 0;
    return maxRate > 0 ? minimumCommission / maxRate : 0;
}

function planBuyOrder(plan, close, availableCash, policy, isFirstBuy) {
    const minimumAmount = minimumEfficientOrderAmount(policy);
    const canSplitEfficiently = plan.targetAmount >= minimumAmount * 2;
    const targetAmount = canSplitEfficiently ? plan.targetAmount / 2 : plan.targetAmount;
    const reasonSuffix = canSplitEfficiently
        ? ''
        : `；总计划低于两笔有效单阈值¥${Math.round(minimumAmount)}，合并为单笔以避免重复最低佣金`;
    const maximumAmount = Math.min(
        availableCash,
        Math.max(targetAmount, minimumAmount) * (1 + (Number(policy.maxBuyAmountOvershootPct) || 0))
    );
    let buyShares = roundLot(Math.min(targetAmount, availableCash) / close, policy.lotSize);
    let estimatedAmount = price(buyShares * close);

    if (estimatedAmount < minimumAmount) {
        const sharesForMinimum = Math.ceil(minimumAmount / close / policy.lotSize) * policy.lotSize;
        const minimumOrderAmount = price(sharesForMinimum * close);
        if (minimumOrderAmount <= maximumAmount) {
            buyShares = sharesForMinimum;
            estimatedAmount = minimumOrderAmount;
        }
    }
    if (!buyShares || estimatedAmount < minimumAmount) return null;

    const estimatedCommission = price(estimateCommission(estimatedAmount, policy), 2);
    if (estimatedAmount + estimatedCommission > availableCash) return null;
    return {
        buyShares,
        estimatedAmount,
        estimatedCommission,
        effectiveCommissionRate: price(estimatedCommission / estimatedAmount * 100, 2),
        reasonSuffix,
        stage: canSplitEfficiently ? (isFirstBuy ? '首笔建仓' : '回落补仓') : '单笔建仓'
    };
}

function utcDay(value) {
    const timestamp = Date.parse(`${value}T00:00:00Z`);
    return Number.isFinite(timestamp) ? Math.floor(timestamp / 86400000) : null;
}

function average(values) {
    return values.reduce((sum, value) => sum + value, 0) / values.length;
}

function etfTrendGate(code, quote) {
    const file = path.join(HISTORY_DIR, `${code}.json`);
    if (!fs.existsSync(file)) return { passed: false, reason: '缺少趋势历史数据' };
    const history = load(file, []).filter(row => Number(row.close) > 0);
    const quoteDate = quote?.trade_date;
    const historyDate = history.at(-1)?.date;
    const ageDays = utcDay(quoteDate) - utcDay(historyDate);
    if (history.length < 20 || !Number.isFinite(ageDays) || ageDays > 5) {
        return { passed: false, reason: `趋势历史不足或过期（最新历史 ${historyDate ?? '未知'}，行情 ${quoteDate ?? '未知'}）` };
    }
    const closes = [...history.map(row => Number(row.close)), Number(quote.close)];
    const ma5 = average(closes.slice(-5));
    const ma10 = average(closes.slice(-10));
    const ma20 = average(closes.slice(-20));
    const close = Number(quote.close);
    const passed = close >= ma5 && ma5 >= ma10 && close >= ma20;
    return {
        passed,
        ma5: price(ma5, 4), ma10: price(ma10, 4), ma20: price(ma20, 4),
        reason: passed ? '价格站上 MA5/MA20，且 MA5 不低于 MA10' : `趋势未确认：现价 ${price(close)}，MA5 ${price(ma5)}，MA10 ${price(ma10)}，MA20 ${price(ma20)}`
    };
}

function reduceTrendGate(code, quote) {
    const file = path.join(HISTORY_DIR, `${code}.json`);
    if (!fs.existsSync(file)) return { passed: false, reason: '减仓仅观察：缺少最新趋势历史数据' };
    const history = load(file, []).filter(row => Number(row.close) > 0);
    const quoteDate = quote?.trade_date;
    const historyDate = history.at(-1)?.date;
    const ageDays = utcDay(quoteDate) - utcDay(historyDate);
    if (history.length < 10 || !Number.isFinite(ageDays) || ageDays > 1) {
        return { passed: false, reason: `减仓仅观察：趋势历史不足或过期（最新历史 ${historyDate ?? '未知'}，行情 ${quoteDate ?? '未知'}）` };
    }
    const closes = [...history.map(row => Number(row.close)), Number(quote.close)];
    const ma5 = average(closes.slice(-5));
    const ma10 = average(closes.slice(-10));
    const close = Number(quote.close);
    const passed = close < Number(quote.prevClose) && close < ma5 && ma5 < ma10;
    return {
        passed,
        ma5: price(ma5, 4), ma10: price(ma10, 4),
        reason: passed
            ? '日内回落、跌破 MA5 且 MA5 低于 MA10，确认走弱'
            : `减仓仅观察：未确认走弱（现价 ${price(close)}，昨收 ${price(quote.prevClose)}，MA5 ${price(ma5)}，MA10 ${price(ma10)}）`
    };
}

function main() {
    const strategyVersion = syncStrategyVersion().version;
    const holdingsFile = load(HOLDINGS_PATH);
    const planFile = load(PLAN_PATH);
    const universe = load(UNIVERSE_PATH);
    const snapshot = load(SNAPSHOT_PATH, {});
    const stockSignals = load(STOCK_SIGNALS_PATH, { signals: [] });
    const stockReview = load(STOCK_REVIEW_PATH, { candidates: [] });
    const monitorPool = load(MONITOR_POOL_PATH, { candidates: [] });
    const paperState = load(STATE_PATH, {});
    if (!holdingsFile || !planFile || !universe) throw new Error('V4.2 configuration is incomplete');

    const policy = planFile.executionPolicy;
    if (!policy) throw new Error('missing executionPolicy in v4.1_manual_alert_plan.json');
    const etfQuotes = new Map((snapshot.etfs ?? []).map(item => [codeOf(item), item]));
    const stockQuotes = new Map((snapshot.watchStocks ?? []).map(item => [codeOf(item), item]));
    const stockCodes = new Set((monitorPool.candidates?.length ? monitorPool.candidates : universe.stockSatellite?.candidates ?? []).map(item => String(item.code)));
    const holdingPlans = new Map((planFile.holdingPlans ?? []).map(item => [item.code, item]));
    const stockSignalByCode = new Map((stockSignals.signals ?? []).map(item => [item.code, item]));
    const stockReviewByCode = new Map((stockReview.candidates ?? []).map(item => [item.code, item]));
    const heldSharesByCode = new Map((holdingsFile.holdings ?? []).map(item => [String(item.code), Number(item.shares) || 0]));
    const decisions = [];
    const blockedBuys = [];

    for (const holding of holdingsFile.holdings ?? []) {
        const code = String(holding.code);
        // ETFs may be present in the actual-holdings monitor pool, but must
        // continue to use ETF quotes and ETF plan logic rather than stock rules.
        const isStock = stockCodes.has(code) && !etfQuotes.has(code);
        const quote = (isStock ? stockQuotes : etfQuotes).get(code);
        const close = Number(quote?.close);
        const shares = Number(holding.shares);
        const cost = Number(holding.cost);
        if (!(close > 0) || !(shares > 0) || !(cost > 0)) {
            decisions.push({ code, name: holding.name, action: 'HOLD', reason: '行情、成本或持仓信息不完整', executable: false });
            continue;
        }
        const pnlPct = (close / cost - 1) * 100;
        const stopPrice = price(cost * (1 + policy.hardStopLossPct));
        const takeProfitPrice = price(cost * (1 + policy.takeProfitPct));
        const base = {
            code, name: holding.name, assetType: isStock ? 'stock' : 'etf', close: price(close), cost: price(cost), shares,
            pnlPct: price(pnlPct, 2), stopPrice, takeProfitPrice, quoteDate: quote.trade_date ?? null,
            executable: true, brokerOrderSent: false
        };

        // Risk exits always dominate profit-taking and discretionary reductions.
        if (close <= stopPrice) {
            decisions.push({ ...base, action: 'SELL_ALL', sellShares: shares, reason: `硬止损：现价不高于 ${stopPrice}` });
            continue;
        }
        if (isStock) {
            const signal = stockSignalByCode.get(code);
            const fastSma = Number(signal?.sma20);
            if (fastSma > 0 && close < fastSma) {
                decisions.push({ ...base, action: 'SELL_ALL', sellShares: shares, trendExitPrice: price(fastSma, 2), reason: `趋势卖出：收盘价跌破 SMA${signal.selectedVariant?.match(/sma(\d+)_/)?.[1] ?? ''}` });
                continue;
            }
        }
        const holdingPlan = holdingPlans.get(code);
        if (holdingPlan?.weaknessPrice && close < holdingPlan.weaknessPrice) {
            decisions.push({ ...base, action: 'SELL_PARTIAL', sellShares: Math.min(shares, holdingPlan.plannedSharesToReduce), reason: `弱势减仓：现价跌破 ${holdingPlan.weaknessPrice}` });
            continue;
        }
        if (holdingPlan?.reduceRange && close >= holdingPlan.reduceRange[0] && close <= holdingPlan.reduceRange[1]) {
            const reductionGate = reduceTrendGate(code, quote);
            const minimumCoreShares = Number(holdingPlan.minimumCoreShares) || 0;
            const sellShares = Math.min(
                Math.max(0, shares - minimumCoreShares),
                Number(holdingPlan.plannedSharesToReduce) || 0
            );
            if (!reductionGate.passed || !sellShares) {
                decisions.push({ ...base, action: 'HOLD', reason: `减仓区间仅观察：${reductionGate.reason}` });
                continue;
            }
            decisions.push({ ...base, action: 'SELL_PARTIAL', sellShares, reason: `确认走弱后的减仓区间：${holdingPlan.reduceRange.join('-')}；保留 ${minimumCoreShares} 份核心仓` });
            continue;
        }
        if (close >= takeProfitPrice) {
            const sellShares = roundLot(shares * policy.takeProfitSellRatio, policy.lotSize);
            decisions.push({ ...base, action: sellShares ? 'SELL_PARTIAL' : 'HOLD', sellShares, reason: `止盈：现价达到 ${takeProfitPrice}（+${policy.takeProfitPct * 100}%）` });
            continue;
        }
        decisions.push({ ...base, action: 'HOLD', reason: '未触发卖出条件' });
    }

    const totalValue = Number(holdingsFile.available_cash) + (holdingsFile.holdings ?? []).reduce((sum, holding) => {
        const quote = (stockCodes.has(String(holding.code)) ? stockQuotes : etfQuotes).get(String(holding.code));
        return sum + Number(holding.shares) * (Number(quote?.close) || Number(holding.cost) || 0);
    }, 0);
    let remainingCash = Number(holdingsFile.available_cash);
    for (const plan of planFile.buyPlans ?? []) {
        if (plan.enabled === false) continue;
        const quote = etfQuotes.get(plan.code);
        const close = Number(quote?.close);
        if (!(close > 0)) continue;
        const range = close >= plan.firstBuyRange[0] && close <= plan.firstBuyRange[1] ? plan.firstBuyRange
            : close >= plan.addBuyRange[0] && close <= plan.addBuyRange[1] ? plan.addBuyRange : null;
        if (!range) continue;
        const trend = etfTrendGate(String(plan.code), quote);
        if (!trend.passed) {
            blockedBuys.push({ code: plan.code, name: plan.name, reason: trend.reason, trend });
            continue;
        }
        const heldShares = heldSharesByCode.get(String(plan.code)) || 0;
        const heldValue = heldShares * close;
        const remainingTargetAmount = Math.max(0, Number(plan.targetAmount) - heldValue);
        // A target is a total position, not a fresh order budget. Do not turn a
        // small residual amount into an oversized minimum-commission order.
        if (remainingTargetAmount < minimumEfficientOrderAmount(policy)) continue;
        const isFirstBuy = heldShares === 0 && close >= plan.firstBuyRange[0] && close <= plan.firstBuyRange[1];
        const order = planBuyOrder({ ...plan, targetAmount: remainingTargetAmount }, close, remainingCash, policy, isFirstBuy);
        if (!order) continue;
        remainingCash -= order.estimatedAmount + order.estimatedCommission;
        decisions.push({
            code: plan.code, name: plan.name, assetType: 'etf', action: 'BUY', buyShares: order.buyShares,
            estimatedAmount: order.estimatedAmount, estimatedCommission: order.estimatedCommission,
            effectiveCommissionRate: order.effectiveCommissionRate, close: price(close), buyRange: { lower: range[0], upper: range[1] },
            stopPrice: price(close * (1 + policy.hardStopLossPct)), takeProfitPrice: price(close * (1 + policy.takeProfitPct)),
            targetAmount: Number(plan.targetAmount), heldValue: price(heldValue, 2), remainingTargetAmount: price(remainingTargetAmount, 2),
            reason: `${isFirstBuy ? order.stage : `目标仓位补仓（已持约¥${Math.round(heldValue)}，尚差约¥${Math.round(remainingTargetAmount)}）`}区间${order.reasonSuffix}`,
            executable: true, brokerOrderSent: false
        });
    }
    for (const signal of stockSignals.signals ?? []) {
        const review = stockReviewByCode.get(signal.code);
        if (heldSharesByCode.get(String(signal.code))) continue;
        if (signal.status !== 'WATCH_BUY_SETUP' || review?.admissionStatus !== 'ELIGIBLE_FOR_SIGNAL' || signal.positionPlan?.sizingStatus !== 'WITHIN_POSITION_LIMIT') continue;
        const estimatedAmount = Number(signal.positionPlan.estimatedAmount);
        if (estimatedAmount > remainingCash) continue;
        remainingCash -= estimatedAmount;
        decisions.push({
            code: signal.code, name: signal.name, assetType: 'stock', action: 'BUY', buyShares: signal.positionPlan.suggestedShares,
            estimatedAmount, close: signal.close, buyRange: signal.suggestedRange,
            stopPrice: signal.riskPlan.stopLossPrice, takeProfitPrice: signal.riskPlan.takeProfitPrice,
            reason: '样本外验证、流动性和趋势条件均满足', executable: true, brokerOrderSent: false
        });
    }

    const actions = decisions.filter(item => item.action !== 'HOLD');
    const result = {
        version: strategyVersion, generatedAt: new Date().toISOString(), quoteTimestamp: snapshot.timestamp ?? null,
        mode: 'LIVE_READY_MANUAL_EXECUTION', brokerOrderSent: false, portfolioValue: price(totalValue, 2), availableCash: holdingsFile.available_cash, remainingCashAfterPlannedBuys: price(remainingCash, 2),
        policy: { sellPriority: ['hard_stop', 'stock_trend_exit', 'weakness_exit', 'planned_reduction', 'take_profit'], ...policy },
        regime: paperState.confirmedState ?? null, decisions, blockedBuys, actionableCount: actions.length, actions,
        notice: '根据实时行情生成可执行的人工交易提醒；系统不连接券商、不自动下单。成交后须更新真实持仓，后续止盈止损才会以新成本和数量计算。'
    };
    fs.writeFileSync(OUTPUT_PATH, `${JSON.stringify(result, null, 2)}\n`);
    console.log(JSON.stringify(result, null, 2));
}

if (require.main === module) main();

module.exports = { etfTrendGate, minimumEfficientOrderAmount, planBuyOrder, reduceTrendGate, roundLot };
