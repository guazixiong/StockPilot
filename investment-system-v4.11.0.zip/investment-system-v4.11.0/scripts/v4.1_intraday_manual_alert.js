#!/usr/bin/env node
/**
 * V4.2 price-zone alerts for manual execution.
 * Uses the single live decision artifact when available.
 */

const fs = require('fs');
const path = require('path');

const BASE = path.join(__dirname, '..');
const CONFIG_PATH = path.join(BASE, 'config', 'v4.1_manual_alert_plan.json');
const LIVE_DECISIONS_PATH = path.join(BASE, 'data', 'paper_trading_v4.0', 'latest_live_trade_decisions.json');
const STATE_PATH = path.join(BASE, 'data', 'v4.1_alert_state.json');
const FORCE = process.argv.includes('--force');

function loadJson(file) {
    return JSON.parse(fs.readFileSync(file, 'utf8'));
}

function nowShanghai() {
    const parts = new Intl.DateTimeFormat('en-CA', {
        timeZone: 'Asia/Shanghai', year: 'numeric', month: '2-digit', day: '2-digit',
        hour: '2-digit', minute: '2-digit', hour12: false
    }).formatToParts(new Date());
    const fields = Object.fromEntries(parts.filter(p => p.type !== 'literal').map(p => [p.type, p.value]));
    return { date: `${fields.year}-${fields.month}-${fields.day}`, time: `${fields.hour}:${fields.minute}` };
}

function loadState() {
    if (!fs.existsSync(STATE_PATH)) return { alerts: {} };
    try { return loadJson(STATE_PATH); } catch { return { alerts: {} }; }
}

function isRateLimited(state, key, intervalMinutes) {
    const last = state.alerts[key];
    return last && Date.now() - last < intervalMinutes * 60 * 1000;
}

function main() {
    if (!fs.existsSync(CONFIG_PATH)) {
        throw new Error('V4.1 config is missing');
    }
    const config = loadJson(CONFIG_PATH);
    const state = loadState();
    const { date, time } = nowShanghai();
    const candidates = [];

    if (fs.existsSync(LIVE_DECISIONS_PATH)) {
        const live = loadJson(LIVE_DECISIONS_PATH);
        for (const decision of live.actions ?? []) {
            const quantity = decision.action === 'BUY' ? decision.buyShares : decision.sellShares;
            const actionLabel = decision.action === 'BUY' ? '买入' : decision.action === 'SELL_ALL' ? '卖出全部' : '卖出部分';
            const pricing = decision.action === 'BUY'
                ? `可买区间 ${decision.buyRange.lower}-${decision.buyRange.upper}`
                : `现价 ${Number(decision.close).toFixed(3)}，成本 ${Number(decision.cost).toFixed(3)}，盈亏 ${decision.pnlPct >= 0 ? '+' : ''}${decision.pnlPct}%`;
            candidates.push({
                key: `${date}:${decision.code}:${decision.action}:${decision.reason}`,
                priority: decision.action === 'SELL_ALL' ? 1 : decision.action === 'SELL_PARTIAL' ? 5 : 20,
                line: `【${actionLabel}】${decision.name}（${decision.code}）${pricing}；${decision.action === 'BUY' ? `建议 ${quantity} 份（约¥${Math.round(decision.estimatedAmount)}，预估单边手续费¥${Number(decision.estimatedCommission ?? 0).toFixed(2)}，费率${Number(decision.effectiveCommissionRate ?? 0).toFixed(2)}%）` : `建议 ${quantity} 份`}。原因：${decision.reason}。止损 ${decision.stopPrice}，止盈 ${decision.takeProfitPrice}。`
            });
        }
    }

    // No static-zone fallback: a missing live decision artifact is a data
    // failure, never permission to revive a legacy price-only recommendation.
    if (!fs.existsSync(LIVE_DECISIONS_PATH)) {
        console.log('NO_REPLY');
        return;
    }

    const alerts = candidates
        .sort((a, b) => a.priority - b.priority)
        .filter(item => FORCE || !isRateLimited(state, item.key, config.maxAlertIntervalMinutes));
    if (!alerts.length) {
        console.log('NO_REPLY');
        return;
    }
    for (const alert of alerts) state.alerts[alert.key] = Date.now();
    fs.writeFileSync(STATE_PATH, `${JSON.stringify(state, null, 2)}\n`);
    console.log([
        `🔔 V${liveVersion()} 盘中买卖提醒 | ${time}`,
        ...alerts.map(alert => `- ${alert.line}`),
        `- ${config.riskNotice}`
    ].join('\n'));
}

function liveVersion() {
    if (!fs.existsSync(LIVE_DECISIONS_PATH)) return '4.3.0';
    try { return String(loadJson(LIVE_DECISIONS_PATH).version ?? '4.3.0'); }
    catch { return '4.3.0'; }
}

try { main(); } catch (error) { console.error(`V4.1 alert failed: ${error.message}`); process.exit(1); }
