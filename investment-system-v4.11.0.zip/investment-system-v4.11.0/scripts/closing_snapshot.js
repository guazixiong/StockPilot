/**
 * 收盘量化快照脚本（基于v3.5基准引擎）
 * 每日15:35运行
 * 
 * 功能：
 * - Regime状态判断
 * - 精确执行计划（含止损线、拆单建议）
 * - 风险估算（流动性）
 * - 板块强弱排名
 * - 今日操作建议（买/卖/等）
 */

const fs = require('fs');
const path = require('path');
const RegimeEngineV3_5 = require('../engine/regime_engine_v3.5');
const { ExecutionPlanGenerator } = require('../engine/execution_plan');
const { RiskAnalyzer } = require('../engine/risk_analyzer');
const { recordSignal } = require('../monitor/paper_trading');

const DATA_DIR = path.join(__dirname, '../data');

const ETF_NAMES = {
    '159330': '沪深300ETF东财', '159107': '创业板软件ETF富国',
    '159599': '芯片ETF东财', '159611': '电力ETF',
    '512010': '医药ETF易方达', '512880': '证券ETF',
    '513650': '标普500ETF南方', '513880': '日经225ETF',
    '515070': '人工智能ETF', '516160': '新能源ETF',
    '159825': '农业ETF富国'
};

const STOP_LOSS = { BULL: -0.05, RANGE: -0.05, BEAR: -0.08 };

function loadETFData() {
    const filePath = path.join(DATA_DIR, 'etf_realtime.json');
    if (!fs.existsSync(filePath)) {
        console.error('[Error] 未找到ETF实时数据文件');
        return null;
    }
    return JSON.parse(fs.readFileSync(filePath, 'utf8'));
}

function loadCurrentPositions() {
    // 优先读取实际持仓配置
    const holdingsPath = path.join(__dirname, '../config/holdings.json');
    if (fs.existsSync(holdingsPath)) {
        const holdings = JSON.parse(fs.readFileSync(holdingsPath, 'utf8'));
        const positions = {};
        const etfData = loadETFData();
        (holdings.holdings || []).forEach(h => {
            // 从实时数据中查找价格
            const etf = etfData ? etfData.find(e => e.code === h.code || e.symbol === h.symbol) : null;
            const price = etf ? (etf.close || etf.price || 1) : 1;
            positions[h.code] = {
                weight: 1 / (holdings.holdings.length || 1),
                amount: 0,
                name: h.name,
                price: price,
                change_pct: etf ? (etf.change_pct || 0) : 0
            };
        });
        return positions;
    }
    // 备用：读取纸上交易记录
    const historyPath = path.join(DATA_DIR, 'paper_trading/history.json');
    if (!fs.existsSync(historyPath)) return {};
    const history = JSON.parse(fs.readFileSync(historyPath, 'utf8'));
    const trades = history.trades || [];
    if (trades.length === 0) return {};
    const latest = trades[trades.length - 1];
    const positions = {};
    (latest.suggestion || []).forEach(s => {
        positions[s.code] = { weight: (s.weight || 0) / 100, amount: s.amount || 0 };
    });
    return positions;
}

function getSectorRanking(etfData) {
    const sorted = [...etfData].sort((a, b) => (b.change_pct || 0) - (a.change_pct || 0));
    return {
        strong: sorted.slice(0, 4),
        weak: sorted.slice(-4).reverse()
    };
}

function main() {
    const today = new Date().toISOString().split('T')[0];
    const etfData = loadETFData();
    if (!etfData) process.exit(1);

    const date = etfData[0]?.date || today;
    const engine = new RegimeEngineV3_5();

    // 1. 分类
    const classification = engine.classify(etfData);

    // 2. 获取配置
    const allocation = engine.getAllocation(classification.state);
    const positionSizing = engine.getPositionSizing(classification.state);
    const stopLossPct = STOP_LOSS[classification.state] || -0.05;
    const stopLoss = { default: stopLossPct };

    // 3. 风险分析
    const riskAnalyzer = new RiskAnalyzer();
    const liquidity = riskAnalyzer.assessLiquidity(etfData);

    // 4. 生成执行计划
    const planGen = new ExecutionPlanGenerator();
    const currentPositions = loadCurrentPositions();
    const plan = planGen.generate({
        regime: classification.state,
        allocation,
        positionSizing,
        decay: null,
        currentPositions,
        etfData,
        stopLoss,
        liquidity
    });

    // 5. 板块强弱
    const sectorRanking = getSectorRanking(etfData);

    // ============ 输出报告 ============
    let report = `📊 收盘量化快照 | ${date}\n`;
    report += `${'═'.repeat(50)}\n\n`;

    // 一、Regime 状态
    report += `一、Regime 状态\n`;
    report += `${'─'.repeat(40)}\n`;
    report += `状态: ${classification.state} | Breadth: ${(classification.score * 100).toFixed(0)}%\n`;
    report += `上涨ETF: ${classification.advancing}/${classification.total} | 信心指数: ${(classification.confidence * 100).toFixed(1)}%\n`;

    // 二、执行计划
    report += `\n${planGen.toTextReport(plan)}`;

    // 三、风险估算
    const riskReport = riskAnalyzer.generateRiskReport(etfData, allocation, positionSizing, []);
    report += `\n${riskReport.report}`;

    // 四、板块强弱
    report += `\n四、板块强弱跟踪\n`;
    report += `${'─'.repeat(40)}\n`;
    report += `强势: ${sectorRanking.strong.map(e => `${ETF_NAMES[e.code] || e.name}(${(e.change_pct || 0) > 0 ? '+' : ''}${(e.change_pct || 0).toFixed(1)}%)`).join(' > ')}\n`;
    report += `弱势: ${sectorRanking.weak.map(e => `${ETF_NAMES[e.code] || e.name}(${(e.change_pct || 0) > 0 ? '+' : ''}${(e.change_pct || 0).toFixed(1)}%)`).join(' > ')}\n`;

    // 五、今日操作建议
    report += `\n五、今日操作建议\n`;
    report += `${'─'.repeat(40)}\n`;

    const needsRebalance = plan.trades.length > 0;

    if (!needsRebalance) {
        report += `📋 调仓状态：✅ 无需调仓\n`;
        report += `所有ETF持仓已在目标范围内，维持现有配置\n`;
        report += `\n⏰ 今日无需操作\n`;
    } else {
        report += `📋 调仓状态：需要调仓\n`;

        const buyTrades = plan.trades.filter(t => t.diff > 0);
        const sellTrades = plan.trades.filter(t => t.diff < 0);

        if (buyTrades.length > 0) {
            report += `\n🟢 建议买入（共${buyTrades.length}只）：\n`;
            buyTrades.forEach((t, i) => {
                report += `  ${i + 1}. ${t.name}(${t.code}) - 买入 ¥${Math.abs(t.diff).toLocaleString()}`;
                if (t.tradeLots.lots > 1) report += ` [分${t.tradeLots.lots}笔]`;
                report += `\n`;
            });
        }

        if (sellTrades.length > 0) {
            report += `\n🔴 建议卖出（共${sellTrades.length}只）：\n`;
            sellTrades.forEach((t, i) => {
                report += `  ${i + 1}. ${t.name}(${t.code}) - 卖出 ¥${Math.abs(t.diff).toLocaleString()}`;
                if (t.tradeLots.lots > 1) report += ` [分${t.tradeLots.lots}笔]`;
                report += `\n`;
            });
        }

        // 执行时机
        report += `\n⏰ 执行建议：\n`;
        const aShareTrades = plan.trades.filter(t => t.code !== '513650' && t.code !== '513880');
        const hasSp500 = plan.trades.some(t => t.code === '513650');
        const hasNikkei = plan.trades.some(t => t.code === '513880');

        if (aShareTrades.length > 0) {
            report += `  - A股ETF：建议14:30后分批执行\n`;
        }
        if (hasSp500) {
            report += `  - 标普500ETF：今晚21:30美股开盘后执行\n`;
        }
        if (hasNikkei) {
            report += `  - 日经225ETF：明日08:00日股开盘后执行\n`;
        }
    }

    // 风险提示
    report += `\n⚠️ 风险提示：\n`;
    const riskyETFs = etfData.filter(e => Math.abs(e.change_pct || 0) > 3);
    if (riskyETFs.length > 0) {
        riskyETFs.forEach(e => {
            report += `  - ${ETF_NAMES[e.code] || e.name}今日波动${(e.change_pct || 0) > 0 ? '+' : ''}${(e.change_pct || 0).toFixed(2)}%，注意风险\n`;
        });
    } else {
        report += `  - 暂无特别风险提示\n`;
    }

    report += `\n${'═'.repeat(50)}\n`;
    report += `📊 Regime Engine v3.5 | ⚠️ 以上为量化分析，不构成投资建议\n`;

    // 六、生成待执行买入计划
    const buyTradesForPlan = plan.trades.filter(t => t.diff > 0);
    if (buyTradesForPlan.length > 0) {
        const tradePlan = {
            date: date,
            regime: classification.state,
            plan: buyTradesForPlan.map(t => ({
                code: t.code,
                name: t.name,
                targetAmount: Math.abs(t.diff),
                boughtAmount: 0,
                refPrice: etfData.find(e => e.code === t.code)?.close || 0,
                status: 'pending'
            }))
        };
        const planPath = path.join(DATA_DIR, 'trade_plan.json');
        fs.writeFileSync(planPath, JSON.stringify(tradePlan, null, 2));
        console.log(`📋 已生成买入计划: ${planPath}`);
    }

    console.log(report);

    // 保存报告
    const reportPath = path.join(DATA_DIR, `closing_snapshot_${date}.txt`);
    fs.writeFileSync(reportPath, report);
    console.log(`💾 已保存: ${reportPath}`);

    // 记录到纸上交易
    recordSignal(date, etfData);
}

try {
    main();
} catch(err) {
    console.error('[Error]', err);
    process.exit(1);
}
