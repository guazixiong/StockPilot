#!/usr/bin/env node
/** Human-readable audit snapshot for the V4.4 deterministic-opportunity mode. */
const fs = require('fs');
const path = require('path');
const BASE = path.join(__dirname, '..');
const read = file => JSON.parse(fs.readFileSync(file, 'utf8'));
const signals = read(path.join(BASE, 'data', 'paper_trading_v4.0', 'latest_v4.3_signals.json'));
const decisions = read(path.join(BASE, 'data', 'paper_trading_v4.0', 'latest_live_trade_decisions.json'));
const holdings = read(path.join(BASE, 'config', 'holdings.json'));
const report = {
    version: '4.4.0', generatedAt: new Date().toISOString(), decisionMode: 'formal_only_low_capital',
    data: { quoteTimestamp: signals.quoteTimestamp, availableCash: holdings.available_cash, cashStatus: holdings.cash_status },
    action: { buy: signals.signals.filter(x => x.executable && ['BUY', 'PROBE_BUY'].includes(x.level)), risk: decisions.actions || [] },
    rules: ['不提醒试探仓', '正式买入必须通过单标的样本外验证', '订单金额至少1000元且手续费占比不超过0.5%', '仅生成提醒，不自动下单'],
    brokerOrderSent: false
};
console.log(JSON.stringify(report, null, 2));
