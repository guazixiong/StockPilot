#!/usr/bin/env node
/**
 * Record a user-confirmed manual fill. This is the only mutation path for
 * actual holdings; it never submits an order or connects to a broker.
 * Usage: node scripts/record_v4.2_manual_fill.js <buy|sell> <code> <shares> <price>
 */
const fs = require('fs');
const path = require('path');

const BASE = path.join(__dirname, '..');
const HOLDINGS_PATH = path.join(BASE, 'config', 'holdings.json');
const PLAN_PATH = path.join(BASE, 'config', 'v4.1_manual_alert_plan.json');
const UNIVERSE_PATH = path.join(BASE, 'config', 'v4.0_universe.json');
const AUDIT_PATH = path.join(BASE, 'data', 'paper_trading_v4.0', 'manual_fill_audit.jsonl');
const [action, code, sharesRaw, priceRaw] = process.argv.slice(2);
const shares = Number(sharesRaw);
const fillPrice = Number(priceRaw);
if (!['buy', 'sell'].includes(action) || !/^\d{6}$/.test(String(code)) || !Number.isInteger(shares) || shares <= 0 || shares % 100 || !(fillPrice > 0)) {
    throw new Error('usage: record_v4.2_manual_fill.js <buy|sell> <six_digit_code> <shares_multiple_of_100> <price>');
}

const holdingsFile = JSON.parse(fs.readFileSync(HOLDINGS_PATH, 'utf8'));
const plans = JSON.parse(fs.readFileSync(PLAN_PATH, 'utf8'));
const universe = JSON.parse(fs.readFileSync(UNIVERSE_PATH, 'utf8'));
let index = holdingsFile.holdings.findIndex(item => String(item.code) === String(code));
if (action === 'sell' && index < 0) throw new Error(`cannot sell ${code}: not in actual holdings`);
if (action === 'buy' && index < 0) {
    const etf = (plans.buyPlans ?? []).find(item => item.code === String(code));
    const stock = (universe.stockSatellite?.candidates ?? []).find(item => item.code === String(code));
    const source = etf ?? stock;
    if (!source) throw new Error(`cannot buy ${code}: not in configured ETF or stock universe`);
    holdingsFile.holdings.push({ code: String(code), name: source.name, market: stock?.market ?? 'SH', shares: 0, cost: 0 });
    index = holdingsFile.holdings.length - 1;
}
const holding = holdingsFile.holdings[index];
const gross = Number((shares * fillPrice).toFixed(2));
if (action === 'buy') {
    if (gross > Number(holdingsFile.available_cash)) throw new Error(`insufficient recorded cash: need ${gross}, available ${holdingsFile.available_cash}`);
    const previousValue = Number(holding.shares) * Number(holding.cost);
    holding.shares += shares;
    holding.cost = Number(((previousValue + gross) / holding.shares).toFixed(6));
    holdingsFile.available_cash = Number((Number(holdingsFile.available_cash) - gross).toFixed(2));
} else {
    if (shares > Number(holding.shares)) throw new Error(`cannot sell ${shares}: only ${holding.shares} recorded`);
    holding.shares -= shares;
    holdingsFile.available_cash = Number((Number(holdingsFile.available_cash) + gross).toFixed(2));
    if (holding.shares === 0) holdingsFile.holdings.splice(index, 1);
}
holdingsFile.updated = new Date().toISOString().slice(0, 10);
holdingsFile.notes = 'available_cash and holdings reflect user-confirmed manual fills only; the system never submits broker orders.';
const audit = { timestamp: new Date().toISOString(), action, code: String(code), shares, fillPrice, gross, brokerOrderSent: false, holdingsAfter: holdingsFile.holdings, cashAfter: holdingsFile.available_cash };
fs.writeFileSync(HOLDINGS_PATH, `${JSON.stringify(holdingsFile, null, 2)}\n`);
fs.appendFileSync(AUDIT_PATH, `${JSON.stringify(audit)}\n`);
console.log(JSON.stringify({ status: 'RECORDED', ...audit }, null, 2));
