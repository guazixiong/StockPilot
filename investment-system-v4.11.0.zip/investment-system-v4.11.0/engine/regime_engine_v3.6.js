/**
 * Regime Engine v3.6 - 多因子智能版
 * 
 * 解决 v3.5 的 10 项缺陷：
 * - 多因子打分（breadth + 跌幅 + 量能）
 * - 5态：BULL / RANGE / BEAR / CHOPPING / EMERGENCY
 * - 衰减确认（首日60%权重，连续两日100%）
 * - 盘中应急风控
 * - 对冲失效检测
 * - 下跌类型判断
 * 
 * 回测待跑，暂用 v3.5 参数作为基线
 */

const fs = require('fs');
const path = require('path');

class RegimeEngineV3_6 {
    constructor(config = {}) {
        // 多因子权重
        this.weights = {
            breadth:    0.35,   // 涨跌广度
            avgChange:  0.25,   // 平均涨跌幅
            median:     0.20,   // 涨跌幅中位数
            maxDrop:    0.10,   // 最大单只跌幅
            volume:     0.10    // 量能因子
        };

        // 状态阈值
        this.bullThreshold    = config.bullThreshold    || 0.60;
        this.bearThreshold    = config.bearThreshold    || 0.30;
        this.emergencyThreshold = config.emergencyThreshold || 0.10; // breadth ≤10% 触发应急
        this.emergencyDropPct   = config.emergencyDropPct   || -3.5; // 平均跌幅 ≤-3.5% 触发应急

        // CHOPPING 参数
        this.choppingWindow   = config.choppingWindow   || 5;   // 5日内
        this.choppingFlips    = config.choppingFlips    || 3;   // 信号切换≥3次
        this.choppingCooldown = config.choppingCooldown || 10;  // 强制冷却10天

        // 衰减确认参数
        this.decayConfirmDays = config.decayConfirmDays || 2;   // 需要2日确认
        this.decayFirstWeight = config.decayFirstWeight || 0.6; // 首日仓位权重

        // 仓位配置
        this.positionSizing = {
            BULL:      1.0,
            RANGE:     0.70,
            BEAR:      0.40,
            CHOPPING:  0.50,
            EMERGENCY: 0.20
        };

        // 配置权重
        this.allocation = {
            BULL: {
                "159330": 0.10,  // 沪深300
                "515070": 0.15,  // 人工智能
                "159599": 0.15,  // 芯片
                "516160": 0.10,  // 新能源
                "512880": 0.10,  // 证券
                "513650": 0.20,  // 标普500
                "513880": 0.20   // 日经225
            },
            BEAR: {
                "512010": 0.30,  // 医药
                "159611": 0.30,  // 电力
                "513650": 0.20,  // 标普500
                "513880": 0.20   // 日经225
            },
            RANGE: {
                "159330": 0.15,  // 沪深300
                "515070": 0.15,  // 人工智能
                "159599": 0.15,  // 芯片
                "513650": 0.20,  // 标普500
                "513880": 0.20,  // 日经225
                "512010": 0.15   // 医药
            },
            CHOPPING: {
                "159330": 0.20,  // 沪深300（低波动宽基）
                "512010": 0.25,  // 医药
                "159611": 0.25,  // 电力
                "513650": 0.15,  // 标普500
                "513880": 0.15   // 日经225
            },
            EMERGENCY: {
                "512010": 0.40,  // 医药（纯防御）
                "159611": 0.40,  // 电力
                "513650": 0.10,  // 标普500
                "513880": 0.10   // 日经225
            }
        };

        // 止损线配置（占成本价百分比）
        this.stopLoss = {
            BULL:      { default: -0.08 },
            RANGE:     { default: -0.06 },
            BEAR:      { default: -0.05 },
            CHOPPING:  { default: -0.04 },
            EMERGENCY: { default: -0.03 }
        };

        // 历史状态记录（用于CHOPPING检测和衰减确认）
        this.stateHistory = [];
    }

    /**
     * 多因子状态分类（核心升级）
     * @param {Object[]} etfData - 当日ETF行情数组
     * @param {Object[]} [prev5Days] - 前5日数据（用于CHOPPING检测和量能对比）
     * @returns {Object} 分类结果
     */
    classify(etfData, prev5Days = []) {
        if (!etfData || etfData.length === 0) {
            return this._emptyResult();
        }

        const total = etfData.length;

        // --- 因子1：Breadth（涨跌广度）---
        const advancing = etfData.filter(e => e.change_pct > 0).length;
        const breadthScore = advancing / total;

        // --- 因子2：平均涨跌幅 ---
        const changes = etfData.map(e => e.change_pct || 0);
        const avgChange = changes.reduce((s, c) => s + c, 0) / total;
        // 归一化到 0-1：-5%→0, +3%→1
        const avgChangeScore = Math.max(0, Math.min(1, (avgChange + 5) / 8));

        // --- 因子3：涨跌幅中位数 ---
        const sorted = [...changes].sort((a, b) => a - b);
        const median = sorted[Math.floor(sorted.length / 2)];
        const medianScore = Math.max(0, Math.min(1, (median + 5) / 8));

        // --- 因子4：最大单只跌幅（负向因子）---
        const maxDrop = Math.min(...changes);
        // -10%→0, 0%→1
        const maxDropScore = Math.max(0, Math.min(1, (maxDrop + 10) / 10));

        // --- 因子5：量能因子 ---
        let volumeScore = 0.5; // 默认中性
        if (prev5Days.length > 0) {
            const todayVolume = etfData.reduce((s, e) => s + (e.volume || 0), 0);
            const avgVolume = prev5Days.reduce((s, day) => {
                return s + day.reduce((ds, e) => ds + (e.volume || 0), 0);
            }, 0) / prev5Days.length;
            if (avgVolume > 0) {
                const volRatio = todayVolume / avgVolume;
                // 放量下跌加重BEAR权重（分数降低），缩量下跌减轻
                if (avgChange < 0) {
                    // 放量下跌 → 恐慌，分数更低
                    volumeScore = Math.max(0, 0.5 - (volRatio - 1) * 0.3);
                } else {
                    // 放量上涨 → 积极，分数更高
                    volumeScore = Math.min(1, 0.5 + (volRatio - 1) * 0.3);
                }
            }
        }

        // --- 综合得分 ---
        const compositeScore =
            this.weights.breadth   * breadthScore   +
            this.weights.avgChange * avgChangeScore  +
            this.weights.median    * medianScore     +
            this.weights.maxDrop   * maxDropScore    +
            this.weights.volume    * volumeScore;

        // --- 状态判定 ---
        let rawState = 'RANGE';
        if (compositeScore >= this.bullThreshold) {
            rawState = 'BULL';
        } else if (compositeScore <= this.bearThreshold) {
            rawState = 'BEAR';
        }

        // --- EMERGENCY 检测 ---
        // 更严格：breadth ≤10% 且 平均跌幅 ≤-4%，或 平均跌幅 ≤-6%（单边暴跌）
        const isEmergency = (breadthScore <= this.emergencyThreshold && avgChange <= this.emergencyDropPct) ||
                            (avgChange <= -6.0);

        // --- CHOPPING 检测 ---
        const isChopping = this._detectChopping(rawState, prev5Days);

        // 最终状态
        let finalState = rawState;
        if (isEmergency) {
            finalState = 'EMERGENCY';
        } else if (isChopping) {
            finalState = 'CHOPPING';
        }

        // --- 衰减确认 ---
        const decayResult = this._applyDecayConfirmation(finalState);

        // 记录历史
        this.stateHistory.push({ date: etfData[0]?.date, state: finalState });

        // --- 对冲失效检测 ---
        const hedgeWarning = this._detectHedgeFailure(etfData);

        // --- 下跌类型判断 ---
        const declineType = this._classifyDeclineType(etfData, prev5Days, avgChange);

        return {
            state: decayResult.effectiveState,
            rawState: finalState,
            compositeScore: Math.round(compositeScore * 1000) / 1000,
            confidence: Math.abs(compositeScore - 0.5) * 2,

            // 各因子明细
            factors: {
                breadth:      Math.round(breadthScore * 1000) / 1000,
                avgChange:    Math.round(avgChange * 100) / 100,
                avgChangeScore: Math.round(avgChangeScore * 1000) / 1000,
                median:       Math.round(median * 100) / 100,
                maxDrop:      Math.round(maxDrop * 100) / 100,
                volumeRatio:  this._calcVolumeRatio(etfData, prev5Days),
                volumeScore:  Math.round(volumeScore * 1000) / 1000
            },

            // 基础统计
            advancing,
            total,
            breadth: advancing / total,

            // 衰减确认信息
            decay: decayResult,

            // 风控警告
            emergency: isEmergency,
            chopping: isChopping,
            hedgeWarning,
            declineType
        };
    }

    /**
     * 衰减确认机制
     * 首日信号给60%仓位权重，连续两日确认才给100%
     */
    _applyDecayConfirmation(currentState) {
        if (this.stateHistory.length < 2) {
            return {
                effectiveState: currentState,
                confirmed: false,
                positionWeight: this.decayFirstWeight,
                daysInState: 1,
                note: '首日信号，仓位打6折'
            };
        }

        const prev = this.stateHistory[this.stateHistory.length - 2];
        const isConfirmed = (prev.state === currentState);

        if (isConfirmed) {
            // 连续两日同状态，确认
            let daysInState = 1;
            for (let i = this.stateHistory.length - 1; i >= 0; i--) {
                if (this.stateHistory[i].state === currentState) daysInState++;
                else break;
            }
            return {
                effectiveState: currentState,
                confirmed: true,
                positionWeight: 1.0,
                daysInState,
                note: `连续${daysInState}日确认，满仓权重`
            };
        } else {
            // 状态刚切换，衰减
            return {
                effectiveState: currentState,
                confirmed: false,
                positionWeight: this.decayFirstWeight,
                daysInState: 1,
                note: `状态切换（${prev.state}→${currentState}），仓位打${this.decayFirstWeight * 100}%`
            };
        }
    }

    /**
     * CHOPPING 检测
     * 5日内信号切换≥3次 → 震荡市
     */
    _detectChopping(currentState, prev5Days) {
        if (this.stateHistory.length < this.choppingWindow) return false;

        const recent = this.stateHistory.slice(-this.choppingWindow);
        let flips = 0;
        for (let i = 1; i < recent.length; i++) {
            if (recent[i].state !== recent[i - 1].state) flips++;
        }
        return flips >= this.choppingFlips;
    }

    /**
     * 对冲失效检测
     * A股ETF与跨境ETF同向下跌 → 对冲失效
     */
    _detectHedgeFailure(etfData) {
        const domesticCodes = ['159330', '515070', '159599', '516160', '512880', '512010', '159611', '159825'];
        const crossCodes = ['513650', '513880'];

        const domestic = etfData.filter(e => domesticCodes.includes(e.code));
        const cross = etfData.filter(e => crossCodes.includes(e.code));

        if (domestic.length === 0 || cross.length === 0) return null;

        const domAvgChange = domestic.reduce((s, e) => s + (e.change_pct || 0), 0) / domestic.length;
        const crossAvgChange = cross.reduce((s, e) => s + (e.change_pct || 0), 0) / cross.length;

        // 同向下跌
        if (domAvgChange < -1.0 && crossAvgChange < -1.0) {
            return {
                detected: true,
                severity: 'HIGH',
                domesticAvg: Math.round(domAvgChange * 100) / 100,
                crossAvg: Math.round(crossAvgChange * 100) / 100,
                message: `⚠️ 对冲失效：A股(${domAvgChange.toFixed(1)}%)与跨境(${crossAvgChange.toFixed(1)}%)同步下跌`
            };
        }

        // 跨境微跌，A股大跌
        if (domAvgChange < -2.0 && crossAvgChange < 0 && crossAvgChange > -1.0) {
            return {
                detected: true,
                severity: 'MEDIUM',
                domesticAvg: Math.round(domAvgChange * 100) / 100,
                crossAvg: Math.round(crossAvgChange * 100) / 100,
                message: `⚠️ 对冲减弱：A股(${domAvgChange.toFixed(1)}%)大跌，跨境(${crossAvgChange.toFixed(1)}%)未能有效对冲`
            };
        }

        return null;
    }

    /**
     * 下跌类型判断
     * 事件驱动 vs 趋势下跌
     */
    _classifyDeclineType(etfData, prev5Days, avgChange) {
        if (avgChange >= -1.0) return null; // 不算下跌

        const totalVolume = etfData.reduce((s, e) => s + (e.volume || 0), 0);
        let avgVolume = 0;
        if (prev5Days.length > 0) {
            avgVolume = prev5Days.reduce((s, day) => {
                return s + day.reduce((ds, e) => ds + (e.volume || 0), 0);
            }, 0) / prev5Days.length;
        }
        const volRatio = avgVolume > 0 ? totalVolume / avgVolume : 1;

        // 事件驱动：单日暴跌 + 放量
        if (avgChange <= -3.0 && volRatio >= 1.5) {
            return {
                type: 'EVENT_DRIVEN',
                label: '事件驱动（单日暴跌+放量）',
                avgChange: Math.round(avgChange * 100) / 100,
                volumeRatio: Math.round(volRatio * 100) / 100,
                advice: '优先降仓位，观察2-3日再做趋势判断。情绪杀跌通常有修复性反弹机会。'
            };
        }

        // 趋势下跌：连续多日小幅下跌
        if (prev5Days.length >= 3) {
            const recent3 = prev5Days.slice(-3).map(day =>
                day.reduce((s, e) => s + (e.change_pct || 0), 0) / day.length
            );
            const allNegative = recent3.every(c => c < 0) && avgChange < 0;
            const gentleDrop = recent3.every(c => c > -2.0) && avgChange > -3.0;

            if (allNegative && gentleDrop) {
                return {
                    type: 'TREND_DRIVEN',
                    label: '趋势下跌（连续多日阴跌）',
                    avgChange: Math.round(avgChange * 100) / 100,
                    recent3Days: recent3.map(c => Math.round(c * 100) / 100),
                    advice: '趋势性下跌，建议维持低仓位，等待明确反转信号再加仓。'
                };
            }
        }

        // 恐慌踩踏：暴跌但量能不算特别大
        if (avgChange <= -4.0) {
            return {
                type: 'PANIC_SELL',
                label: '恐慌踩踏（无量暴跌或有量暴跌）',
                avgChange: Math.round(avgChange * 100) / 100,
                volumeRatio: Math.round(volRatio * 100) / 100,
                advice: '恐慌性卖出，若缩量则可能是最后一跌，若放量则需警惕继续下行。'
            };
        }

        return {
            type: 'NORMAL_CORRECTION',
            label: '正常调整',
            avgChange: Math.round(avgChange * 100) / 100,
            volumeRatio: Math.round(volRatio * 100) / 100,
            advice: '幅度可控的调整，无需过度反应。'
        };
    }

    /**
     * 计算量比
     */
    _calcVolumeRatio(etfData, prev5Days) {
        if (prev5Days.length === 0) return null;
        const todayVol = etfData.reduce((s, e) => s + (e.volume || 0), 0);
        const avgVol = prev5Days.reduce((s, day) => {
            return s + day.reduce((ds, e) => ds + (e.volume || 0), 0);
        }, 0) / prev5Days.length;
        return avgVol > 0 ? Math.round((todayVol / avgVol) * 100) / 100 : null;
    }

    /**
     * 获取仓位比例
     */
    getPositionSizing(regime) {
        return this.positionSizing[regime] || 0.70;
    }

    /**
     * 获取配置权重
     */
    getAllocation(regime) {
        return this.allocation[regime] || this.allocation.RANGE;
    }

    /**
     * 获取止损线
     */
    getStopLoss(regime) {
        return this.stopLoss[regime] || this.stopLoss.RANGE;
    }

    /**
     * 获取板块强弱排名
     */
    getSectorRanking(etfData) {
        const sectors = etfData.map(e => ({
            code: e.code,
            name: e.name || e.code,
            change_pct: e.change_pct || 0
        })).sort((a, b) => b.change_pct - a.change_pct);

        const third = Math.ceil(sectors.length / 3);
        return {
            strong: sectors.slice(0, third),
            middle: sectors.slice(third, -third),
            weak: sectors.slice(-third)
        };
    }

    /**
     * 空结果
     */
    _emptyResult() {
        return {
            state: 'RANGE',
            rawState: 'RANGE',
            compositeScore: 0.5,
            confidence: 0,
            factors: { breadth: 0.5, avgChange: 0, median: 0, maxDrop: 0, volumeRatio: null, volumeScore: 0.5 },
            advancing: 0,
            total: 0,
            breadth: 0,
            decay: { effectiveState: 'RANGE', confirmed: false, positionWeight: 0.6, daysInState: 0, note: '无数据' },
            emergency: false,
            chopping: false,
            hedgeWarning: null,
            declineType: null
        };
    }

    /**
     * 简化版 classify（兼容 v3.5 接口）
     * 只传 etfData，不需要历史数据
     */
    classifySimple(etfData) {
        return this.classify(etfData, []);
    }
}

module.exports = RegimeEngineV3_6;
