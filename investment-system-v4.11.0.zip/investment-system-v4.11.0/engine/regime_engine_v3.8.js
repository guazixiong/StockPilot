/**
 * Regime Engine v3.8 - daily-data validation core.
 *
 * This engine deliberately excludes intraday T+0 and stock satellite rules:
 * the repository does not contain the intraday history needed to validate them.
 * It uses only information available at a daily close.  The caller must execute
 * the returned target at the following trading day's open.
 */

class RegimeEngineV3_8 {
    constructor(config = {}) {
        this.bullThreshold = config.bullThreshold ?? 0.60;
        this.bearThreshold = config.bearThreshold ?? 0.30;
        this.confirmDays = config.confirmDays ?? 3;

        // Codes with continuous daily OHLC coverage in the available 2023-2026 dataset.
        this.universe = config.universe ?? [
            '512010', '512880', '513650', '513880', '515070', '516160'
        ];

        // V3.5 core allocation, renormalized only across the continuously available ETF set.
        this.allocation = {
            BULL: { '515070': 0.16, '516160': 0.10, '512880': 0.10, '513650': 0.32, '513880': 0.32 },
            BEAR: { '512010': 0.30, '512880': 0.15, '513650': 0.275, '513880': 0.275 },
            RANGE: { '512010': 0.17, '515070': 0.17, '512880': 0.10, '513650': 0.28, '513880': 0.28 }
        };
        this.positionSizing = { BULL: 0.90, BEAR: 0.40, RANGE: 0.70 };
        this.pendingState = null;
        this.pendingDays = 0;
        this.confirmedState = 'RANGE';
    }

    classify(records) {
        const usable = records.filter(record => (
            this.universe.includes(record.code) &&
            Number.isFinite(record.change_pct)
        ));

        if (usable.length !== this.universe.length) {
            return { state: this.confirmedState, valid: false, reason: 'incomplete_universe' };
        }

        const advancing = usable.filter(record => record.change_pct > 0).length;
        const score = advancing / usable.length;
        const rawState = score >= this.bullThreshold ? 'BULL' : score <= this.bearThreshold ? 'BEAR' : 'RANGE';

        if (rawState === this.confirmedState) {
            this.pendingState = null;
            this.pendingDays = 0;
        } else if (rawState === this.pendingState) {
            this.pendingDays += 1;
        } else {
            this.pendingState = rawState;
            this.pendingDays = 1;
        }

        if (this.pendingDays >= this.confirmDays) {
            this.confirmedState = rawState;
            this.pendingState = null;
            this.pendingDays = 0;
        }

        return {
            state: this.confirmedState,
            rawState,
            score,
            advancing,
            total: usable.length,
            valid: true
        };
    }

    getTargetWeights(state) {
        const allocation = this.allocation[state] ?? this.allocation.RANGE;
        const exposure = this.positionSizing[state] ?? this.positionSizing.RANGE;
        return Object.fromEntries(Object.entries(allocation).map(([code, weight]) => [code, weight * exposure]));
    }
}

module.exports = RegimeEngineV3_8;
