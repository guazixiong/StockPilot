/**
 * evaluation_engine.js
 * 
 * 职责：评估 Regime Engine 的识别质量
 * 
 * 评价指标体系（v3.1 冻结）：
 *   1. State Accuracy    - 各状态未来收益是否符合预期
 *   2. Transition Lead Time - 提前识别能力
 *   3. Distribution Risk Score - 风险区识别能力
 *   4. Recovery False Signal Rate - 假恢复信号率
 *   5. Risk Reduction - 回撤控制能力
 */

const fs = require('fs');
const path = require('path');

class EvaluationEngine {
  constructor(config = {}) {
    this.forwardDays = config.forwardDays || 20;
  }

  /**
   * 全面评估 Regime 回测结果
   * @param {RegimeResult[]} regimeResults - regime_engine.backtest() 的输出
   * @returns {EvaluationReport}
   */
  evaluate(regimeResults) {
    console.log('[Eval] 开始评估 Regime 质量...');

    const stateAccuracy = this._evaluateStateAccuracy(regimeResults);
    const transitionLeadTime = this._evaluateTransitionLeadTime(regimeResults);
    const distributionScore = this._evaluateDistribution(regimeResults);
    const recoveryFalseSignal = this._evaluateRecovery(regimeResults);
    const regimeDistribution = this._getRegimeDistribution(regimeResults);

    return {
      version: '3.1',
      evaluation_date: new Date().toISOString().split('T')[0],
      total_trading_days: regimeResults.length,
      date_range: `${regimeResults[0]?.date} ~ ${regimeResults[regimeResults.length - 1]?.date}`,

      regime_distribution: regimeDistribution,
      state_accuracy: stateAccuracy,
      transition_lead_time: transitionLeadTime,
      distribution_score: distributionScore,
      recovery_false_signal: recoveryFalseSignal,

      summary: this._generateSummary(stateAccuracy, transitionLeadTime, distributionScore, recoveryFalseSignal)
    };
  }

  /**
   * 评估各状态的未来收益表现
   */
  _evaluateStateAccuracy(results) {
    const states = ['BULL', 'BEAR', 'RANGE', 'RECOVERY', 'DISTRIBUTION'];
    const accuracy = {};

    for (const state of states) {
      const stateDays = results.filter(r => r.state === state);
      if (stateDays.length === 0) {
        accuracy[state] = { count: 0, avg_forward_return: null };
        continue;
      }

      // 计算每个状态日之后的 forward return
      const forwardReturns = [];
      for (const day of stateDays) {
        const idx = results.findIndex(r => r.date === day.date);
        if (idx < 0) continue;

        const futureIdx = Math.min(idx + this.forwardDays, results.length - 1);
        if (futureIdx <= idx) continue;

        // 使用 breadth.avg_change 近似累计收益
        let cumReturn = 0;
        for (let i = idx + 1; i <= futureIdx; i++) {
          cumReturn += results[i].breadth?.avg_change || 0;
        }
        forwardReturns.push(cumReturn);
      }

      if (forwardReturns.length === 0) {
        accuracy[state] = { count: stateDays.length, avg_forward_return: null };
        continue;
      }

      const avg = forwardReturns.reduce((s, r) => s + r, 0) / forwardReturns.length;
      const positive = forwardReturns.filter(r => r > 0).length;
      const negative = forwardReturns.filter(r => r < 0).length;

      accuracy[state] = {
        count: stateDays.length,
        avg_forward_return: Math.round(avg * 100) / 100,
        positive_count: positive,
        negative_count: negative,
        win_rate: Math.round(positive / forwardReturns.length * 100) / 100
      };
    }

    return accuracy;
  }

  /**
   * 评估 Transition Lead Time
   */
  _evaluateTransitionLeadTime(results) {
    const transitions = results.filter(r => r.transition && r.transition !== null);

    if (transitions.length === 0) {
      return { total: 0, avg_lead_time: null };
    }

    return {
      total: transitions.length,
      types: transitions.reduce((acc, t) => {
        acc[t.transition] = (acc[t.transition] || 0) + 1;
        return acc;
      }, {})
    };
  }

  /**
   * 评估 Distribution 的风险识别能力
   */
  _evaluateDistribution(results) {
    const distDays = results.filter(r => r.state === 'DISTRIBUTION');
    if (distDays.length === 0) return { count: 0 };

    // 计算 Distribution 期间的最大回撤和波动率
    const forwardReturns = [];
    for (const day of distDays) {
      const idx = results.findIndex(r => r.date === day.date);
      if (idx < 0) continue;

      const futureIdx = Math.min(idx + this.forwardDays, results.length - 1);
      let cumReturn = 0;
      let maxReturn = 0;
      let maxDrawdown = 0;

      for (let i = idx + 1; i <= futureIdx; i++) {
        cumReturn += results[i].breadth?.avg_change || 0;
        maxReturn = Math.max(maxReturn, cumReturn);
        maxDrawdown = Math.min(maxDrawdown, cumReturn - maxReturn);
      }

      forwardReturns.push({
        cum_return: cumReturn,
        max_drawdown: maxDrawdown
      });
    }

    const avgReturn = forwardReturns.reduce((s, r) => s + r.cum_return, 0) / forwardReturns.length;
    const avgDrawdown = forwardReturns.reduce((s, r) => s + r.max_drawdown, 0) / forwardReturns.length;
    const drawdownCount = forwardReturns.filter(r => r.max_drawdown < -3).length;

    return {
      count: distDays.length,
      avg_forward_return: Math.round(avgReturn * 100) / 100,
      avg_max_drawdown: Math.round(avgDrawdown * 100) / 100,
      significant_drawdown_rate: Math.round(drawdownCount / forwardReturns.length * 100) / 100
    };
  }

  /**
   * 评估 Recovery 假信号率
   */
  _evaluateRecovery(results) {
    const recoveryDays = results.filter(r => r.state === 'RECOVERY');
    if (recoveryDays.length === 0) return { count: 0 };

    let falseSignal = 0;
    for (const day of recoveryDays) {
      const idx = results.findIndex(r => r.date === day.date);
      if (idx < 0) continue;

      // 检查 Recovery 后是否转回 BEAR
      const futureIdx = Math.min(idx + this.forwardDays, results.length - 1);
      for (let i = idx + 1; i <= futureIdx; i++) {
        if (results[i].state === 'BEAR') {
          falseSignal++;
          break;
        }
      }
    }

    return {
      count: recoveryDays.length,
      false_signals: falseSignal,
      false_signal_rate: Math.round(falseSignal / recoveryDays.length * 100) / 100
    };
  }

  _getRegimeDistribution(results) {
    const dist = {};
    for (const r of results) {
      dist[r.state] = (dist[r.state] || 0) + 1;
    }
    return dist;
  }

  _generateSummary(stateAccuracy, transitionLeadTime, distributionScore, recoveryFalseSignal) {
    const issues = [];
    const strengths = [];

    // 检查 BULL 表现
    if (stateAccuracy.BULL?.win_rate > 0.55) {
      strengths.push(`BULL胜率${(stateAccuracy.BULL.win_rate * 100).toFixed(0)}%，有效`);
    } else if (stateAccuracy.BULL?.count > 0) {
      issues.push(`BULL胜率不足，需调整阈值`);
    }

    // 检查 RECOVERY 假信号
    if (recoveryFalseSignal.false_signal_rate < 0.4) {
      strengths.push(`RECOVERY假信号率${(recoveryFalseSignal.false_signal_rate * 100).toFixed(0)}%，可接受`);
    } else {
      issues.push(`RECOVERY假信号率${(recoveryFalseSignal.false_signal_rate * 100).toFixed(0)}%，过高`);
    }

    // 检查 DISTRIBUTION 回撤识别
    if (distributionScore.avg_max_drawdown < -3) {
      strengths.push(`DISTRIBUTION平均最大回撤${distributionScore.avg_max_drawdown}%，风险识别有效`);
    }

    return { strengths, issues };
  }
}

module.exports = { EvaluationEngine };
