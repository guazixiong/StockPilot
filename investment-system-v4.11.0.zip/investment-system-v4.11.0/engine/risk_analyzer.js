/**
 * Risk Analyzer - 风险分析模块
 * 
 * 功能：
 * 1. VaR 估算（历史模拟法）
 * 2. 流动性风险评分
 * 3. 最大回撤前瞻预警
 * 4. 仓位风险汇总
 */

const fs = require('fs');
const path = require('path');

class RiskAnalyzer {
    constructor(config = {}) {
        this.varConfidence = config.varConfidence || 0.95; // 95%置信度
        this.varHorizon = config.varHorizon || 5;          // 5日VaR
        this.liquidityThresholds = {
            high:   50000000,  // 日均成交额>5000万 → 低冲击
            medium: 10000000,  // >1000万 → 中等冲击
            low:    0          // <1000万 → 高冲击
        };
    }

    /**
     * 计算组合 VaR（历史模拟法）
     * @param {Object[]} etfData - 当日ETF数据（含 code, change_pct）
     * @param {Object} allocation - 当前配置权重 { code: weight }
     * @param {Object} positionSizing - 仓位比例
     * @param {Object[]} history - 历史日收益率序列 [{ date, returns: { code: pct } }]
     * @returns {Object} VaR 结果
     */
    calculateVaR(etfData, allocation, positionSizing, history = []) {
        if (history.length < 20) {
            return {
                available: false,
                reason: '历史数据不足（需≥20天）',
                var5d: null,
                var10d: null
            };
        }

        // 计算组合每日收益率
        const portfolioReturns = history.map(day => {
            let dailyReturn = 0;
            for (const [code, weight] of Object.entries(allocation)) {
                const r = day.returns?.[code] || 0;
                dailyReturn += weight * r * positionSizing;
            }
            return dailyReturn;
        });

        portfolioReturns.sort((a, b) => a - b);

        // 5日 VaR（滚动窗口）
        const varIndex = Math.floor(portfolioReturns.length * (1 - this.varConfidence));
        const var1d = portfolioReturns[varIndex];
        const var5d = var1d * Math.sqrt(this.varHorizon);
        const var10d = var1d * Math.sqrt(10);

        // 最大单日损失
        const maxDailyLoss = portfolioReturns[0];

        // 期望回撤
        const avgLoss = portfolioReturns.slice(0, varIndex + 1).reduce((s, r) => s + r, 0) / (varIndex + 1);

        return {
            available: true,
            confidence: this.varConfidence,
            horizon: this.varHorizon,
            var1d: Math.round(var1d * 10000) / 100,   // 百分比
            var5d: Math.round(var5d * 10000) / 100,
            var10d: Math.round(var10d * 10000) / 100,
            maxDailyLoss: Math.round(maxDailyLoss * 10000) / 100,
            expectedLoss: Math.round(avgLoss * 10000) / 100,
            sampleSize: portfolioReturns.length
        };
    }

    /**
     * 流动性风险评分
     * @param {Object[]} etfData - 含 amount（成交额）字段
     * @returns {Object} 流动性评估
     */
    assessLiquidity(etfData) {
        const results = etfData.map(etf => {
            const amount = etf.amount || 0;
            let level, slippageEstimate, risk;

            if (amount >= this.liquidityThresholds.high) {
                level = 'HIGH';
                slippageEstimate = 0.05; // 0.05%
                risk = '低';
            } else if (amount >= this.liquidityThresholds.medium) {
                level = 'MEDIUM';
                slippageEstimate = 0.20; // 0.20%
                risk = '中';
            } else {
                level = 'LOW';
                slippageEstimate = 0.50; // 0.50%
                risk = '高';
            }

            return {
                code: etf.code,
                name: etf.name || etf.code,
                amount,
                level,
                slippageEstimate,
                risk
            };
        });

        const lowLiquidity = results.filter(r => r.level === 'LOW');
        const avgSlippage = results.reduce((s, r) => s + r.slippageEstimate, 0) / results.length;

        return {
            details: results,
            lowLiquidityCount: lowLiquidity.length,
            lowLiquidityETFs: lowLiquidity.map(r => r.name),
            avgSlippage: Math.round(avgSlippage * 100) / 100,
            hasWarning: lowLiquidity.length > 0,
            warning: lowLiquidity.length > 0
                ? `⚠️ ${lowLiquidity.length}只ETF流动性较低，极端行情下滑点可能放大`
                : null
        };
    }

    /**
     * 综合风险报告
     */
    generateRiskReport(etfData, allocation, positionSizing, history = []) {
        const varResult = this.calculateVaR(etfData, allocation, positionSizing, history);
        const liquidity = this.assessLiquidity(etfData);

        let report = `四、风险估算\n`;
        report += `${'─'.repeat(40)}\n`;

        if (varResult.available) {
            report += `5日VaR（${(varResult.confidence * 100).toFixed(0)}%置信度）: ${varResult.var5d}%\n`;
            report += `10日VaR: ${varResult.var10d}%\n`;
            report += `最大单日损失: ${varResult.maxDailyLoss}%\n`;
        } else {
            report += `VaR: ${varResult.reason}\n`;
        }

        report += `流动性风险: 平均滑点约 ${liquidity.avgSlippage}%\n`;
        if (liquidity.hasWarning) {
            report += `${liquidity.warning}\n`;
        }

        return { report, varResult, liquidity };
    }
}

module.exports = { RiskAnalyzer };
