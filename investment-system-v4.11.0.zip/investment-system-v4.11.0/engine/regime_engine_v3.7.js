/**
 * Regime Engine v3.7 - 个性化实战版
 * 基于: v3.5基准 + 用户实际持仓反馈
 * 保存日期: 2026-08-06
 * 
 * 核心改动（vs v3.5）:
 * 1. 止损放宽: -12%宽止损，避免底部建仓后频繁割肉
 * 2. 做T模块: 日经ETF T+0正式纳入系统
 * 3. 个股卫星仓: 5-10%用于个股博弈
 * 4. 资金适配: 按1.8万资金量优化最低买入单位
 * 5. 分层建仓: 首次50%建仓，回调3%再加50%
 * 
 * 用户画像:
 * - 总资产: ~1.8万元
 * - 每天盯盘
 * - 单笔亏损10%心情波动
 * - 有做T习惯（日经ETF T+0）
 * - ETF为主，但对个股心有不甘
 * 
 * 当前持仓（2026-08-06）:
 * - 船舶ETF: 4,005元 (+0.68%)
 * - 沪深300ETF东财: 2,786元 (+3.11%)
 * - 合计: 6,791元 (37.5%)
 * - 可用资金: 5,619元
 * 
 * 止损逻辑优化:
 * - v3.5问题: 底部建仓后触发止损太频繁
 * - v3.7方案: 
 *   a) 宽止损: 单只ETF -12%才触发
 *   b) 分层建仓: 首次买50%，跌3%再买50%，拉低均价
 *   c) 止损后冷却: 触发止损后等待3天再重新评估
 *   d) 状态保护: BEAR状态不建新仓，只维护现有持仓
 */

const fs = require('fs');
const path = require('path');

class RegimeEngineV3_7 {
    constructor(config = {}) {
        // 核心参数
        this.bullThreshold = config.bullThreshold || 0.60;
        this.bearThreshold = config.bearThreshold || 0.30;
        this.smoothingWindow = config.smoothingWindow || 5;
        this.cooldownDays = config.cooldownDays || 5;
        
        // v3.7 新增参数
        this.stopLossPct = config.stopLossPct || -0.12;        // 宽止损 -12%
        this.trancheDropPct = config.trancheDropPct || -0.03;   // 分层建仓触发 -3%
        this.trancheRatio = config.trancheRatio || 0.5;         // 每层50%
        this.postStopCooldown = config.postStopCooldown || 3;   // 止损后冷却3天
        
        // 个股卫星仓上限
        this.stockSatelliteMax = config.stockSatelliteMax || 0.10; // 最多10%
        this.singleStockMax = config.singleStockMax || 0.05;       // 单只个股最多5%
        
        // 做T参数
        this.t0Enabled = true;
        this.t0Target = "513880";     // 日经ETF
        this.t0PositionMax = 0.15;    // 做T仓位上限15%
        this.t0ProfitTarget = 0.005;  // 单次做T目标0.5%
        
        // v3.7 配置（适配1.8万资金量）
        this.allocation = {
            BULL: {
                "159330": 0.10,  // 沪深300
                "515070": 0.12,  // 人工智能
                "159599": 0.12,  // 芯片
                "516160": 0.08,  // 新能源
                "512880": 0.08,  // 证券
                "560710": 0.10,  // 船舶ETF
                "513650": 0.20,  // 标普500
                "513880": 0.20   // 日经225
            },
            BEAR: {
                "512010": 0.30,  // 医药
                "159611": 0.30,  // 电力
                "513650": 0.20,  // 标普500
                "513880": 0.20   // 日经225
            },
            RANGE: {
                "159330": 0.13,  // 沪深300
                "515070": 0.13,  // 人工智能
                "159599": 0.13,  // 芯片
                "560710": 0.08,  // 船舶ETF
                "513650": 0.20,  // 标普500
                "513880": 0.20,  // 日经225
                "512010": 0.13   // 医药
            }
        };
        
        // 仓位控制
        this.positionSizing = {
            BULL: 0.90,   // 留10%现金做T
            BEAR: 0.40,
            RANGE: 0.70
        };
        
        // 用户自选股（个股卫星仓候选）
        this.stockWatchlist = [
            { code: "601127", name: "赛力斯", market: "SH" },
            { code: "002772", name: "众兴菌业", market: "SZ" },
            { code: "600900", name: "长江电力", market: "SH" },
            { code: "600150", name: "中国船舶", market: "SH" },
            { code: "600460", name: "士兰微", market: "SH" },
            { code: "300961", name: "深水海纳", market: "SZ" },
            { code: "603956", name: "威派格", market: "SH" },
            { code: "688057", name: "金达莱", market: "SH" },
            { code: "000977", name: "浪潮信息", market: "SZ" },
            { code: "600941", name: "中国移动", market: "SH" },
            { code: "300008", name: "天海防务", market: "SZ" },
            { code: "601890", name: "亚星锚链", market: "SH" },
            { code: "430510", name: "丰光精密", market: "BJ" },
            { code: "603629", name: "利通电子", market: "SH" }, { code: "600186", name: "莲花控股", market: "SH" }, { code: "603881", name: "数据港", market: "SH" },
            { code: "000815", name: "美利云", market: "SZ" }, { code: "600602", name: "云赛智联", market: "SH" }, { code: "300738", name: "奥飞数据", market: "SZ" },
            { code: "601991", name: "大唐发电", market: "SH" }, { code: "600726", name: "华电能源", market: "SH" }, { code: "600396", name: "华电辽能", market: "SH" },
            { code: "600578", name: "京能电力", market: "SH" }, { code: "001258", name: "立新能源", market: "SZ" }, { code: "600863", name: "华能蒙电", market: "SH" },
            { code: "300058", name: "蓝色光标", market: "SZ" }, { code: "003032", name: "传智教育", market: "SZ" }, { code: "002354", name: "天娱数科", market: "SZ" },
            { code: "603598", name: "引力传媒", market: "SH" }, { code: "000676", name: "智度股份", market: "SZ" }, { code: "603466", name: "风语筑", market: "SH" },
            { code: "300502", name: "新易盛", market: "SZ" }, { code: "300308", name: "中际旭创", market: "SZ" }, { code: "300394", name: "天孚通信", market: "SZ" },
            { code: "603083", name: "剑桥科技", market: "SH" }, { code: "002281", name: "光迅科技", market: "SZ" }, { code: "002384", name: "东山精密", market: "SZ" },
            { code: "300476", name: "胜宏科技", market: "SZ" }, { code: "002938", name: "鹏鼎控股", market: "SZ" }, { code: "002552", name: "宝鼎科技", market: "SZ" },
            { code: "603186", name: "华正新材", market: "SH" }, { code: "603002", name: "宏昌电子", market: "SH" }, { code: "600176", name: "中国巨石", market: "SH" },
            { code: "601869", name: "长飞光纤", market: "SH" }, { code: "600487", name: "亨通光电", market: "SH" }, { code: "002491", name: "通鼎互联", market: "SZ" },
            { code: "603618", name: "杭电股份", market: "SH" }, { code: "600522", name: "中天科技", market: "SH" }, { code: "000070", name: "特发信息", market: "SZ" },
            { code: "600664", name: "哈药股份", market: "SH" }, { code: "603259", name: "药明康德", market: "SH" }, { code: "301520", name: "万邦医药", market: "SZ" },
            { code: "600613", name: "神奇制药", market: "SH" }, { code: "002437", name: "誉衡药业", market: "SZ" }, { code: "600829", name: "人民同泰", market: "SH" }
        ];
        
        // 历史记录
        this.regimeHistory = [];
        this.stopLossLog = [];
    }

    /**
     * 判断市场状态
     */
    classify(etfData) {
        if (!etfData || etfData.length === 0) {
            return { state: 'RANGE', score: 0.5, confidence: 0 };
        }

        const total = etfData.length;
        const advancing = etfData.filter(etf => {
            const changePct = etf.change_pct;
            return changePct !== null && changePct !== undefined && changePct > 0;
        }).length;

        const ratio = advancing / total;

        let state = 'RANGE';
        if (ratio >= this.bullThreshold) {
            state = 'BULL';
        } else if (ratio <= this.bearThreshold) {
            state = 'BEAR';
        }

        return {
            state,
            score: ratio,
            confidence: Math.abs(ratio - 0.5) * 2,
            advancing,
            total
        };
    }

    /**
     * 平滑状态（5日多数投票）
     */
    smoothRegime(rawStates) {
        const smoothed = [];
        for (let i = 0; i < rawStates.length; i++) {
            const start = Math.max(0, i - this.smoothingWindow + 1);
            const windowStates = rawStates.slice(start, i + 1);
            
            const counts = {};
            windowStates.forEach(s => {
                counts[s] = (counts[s] || 0) + 1;
            });
            
            const vote = Object.entries(counts).sort((a, b) => b[1] - a[1])[0][0];
            smoothed.push(vote);
        }
        return smoothed;
    }

    /**
     * 获取当前状态的配置
     */
    getAllocation(regime) {
        return this.allocation[regime] || this.allocation.RANGE;
    }

    /**
     * 获取仓位比例
     */
    getPositionSizing(regime) {
        return this.positionSizing[regime] || 0.70;
    }

    /**
     * v3.7 新增: 分层建仓逻辑
     * @param {string} code - ETF代码
     * @param {number} currentPrice - 当前价格
     * @param {number} avgCost - 持仓均价
     * @param {number} positionRatio - 当前仓位占比
     * @returns {object} 建仓建议
     */
    getTrancheAdvice(code, currentPrice, avgCost, positionRatio) {
        if (!avgCost || avgCost === 0) {
            return { action: 'INITIAL_BUY', ratio: this.trancheRatio, reason: '首次建仓50%' };
        }
        
        const drawdown = (currentPrice - avgCost) / avgCost;
        
        if (drawdown <= this.trancheDropPct && positionRatio < 1.0) {
            return { 
                action: 'ADD_TRANCHE', 
                ratio: this.trancheRatio,
                drawdown: drawdown,
                reason: `下跌${(drawdown*100).toFixed(1)}%，触发加仓`
            };
        }
        
        return { action: 'HOLD', reason: '持仓观望' };
    }

    /**
     * v3.7 新增: 止损判断
     * @param {string} code - ETF代码
     * @param {number} currentPrice - 当前价格
     * @param {number} avgCost - 持仓均价
     * @param {string} regime - 当前市场状态
     * @returns {object} 止损建议
     */
    checkStopLoss(code, currentPrice, avgCost, regime) {
        if (!avgCost || avgCost === 0) {
            return { triggered: false, reason: '无持仓' };
        }
        
        const loss = (currentPrice - avgCost) / avgCost;
        
        // BEAR状态下止损更严格
        const effectiveStopLoss = regime === 'BEAR' ? -0.10 : this.stopLossPct;
        
        if (loss <= effectiveStopLoss) {
            return {
                triggered: true,
                loss: loss,
                threshold: effectiveStopLoss,
                action: 'STOP_LOSS',
                reason: `亏损${(loss*100).toFixed(1)}%，触发止损（阈值${(effectiveStopLoss*100).toFixed(1)}%）`
            };
        }
        
        return { triggered: false, loss: loss };
    }

    /**
     * v3.7 新增: 做T信号
     * @param {string} code - ETF代码
     * @param {number} intradayLow - 日内最低价
     * @param {number} intradayHigh - 日内最高价
     * @param {number} currentPrice - 当前价格
     * @returns {object} 做T建议
     */
    getT0Signal(code, intradayLow, intradayHigh, currentPrice) {
        if (code !== this.t0Target) {
            return { action: 'NONE', reason: '非做T标的' };
        }
        
        const range = (intradayHigh - intradayLow) / intradayLow;
        const pricePosition = (currentPrice - intradayLow) / (intradayHigh - intradayLow);
        
        // 日内波动足够大才做T
        if (range < 0.008) {
            return { action: 'NONE', reason: `日内波动${(range*100).toFixed(2)}%太小，不做T` };
        }
        
        // 价格在日内低位，考虑买入
        if (pricePosition < 0.3) {
            return { 
                action: 'T0_BUY', 
                target: this.t0ProfitTarget,
                reason: `价格在日内低位${(pricePosition*100).toFixed(0)}%，可买入做T`
            };
        }
        
        // 价格在日内高位，考虑卖出
        if (pricePosition > 0.7) {
            return { 
                action: 'T0_SELL', 
                target: this.t0ProfitTarget,
                reason: `价格在日内高位${(pricePosition*100).toFixed(0)}%，可卖出锁定`
            };
        }
        
        return { action: 'HOLD', reason: '价格在中间位置，等待' };
    }

    /**
     * v3.7 新增: 个股卫星仓建议
     * @param {string} code - 股票代码
     * @param {number} totalAssets - 总资产
     * @param {number} currentStockExposure - 当前个股总暴露
     * @returns {object} 建仓建议
     */
    getStockSatelliteAdvice(code, totalAssets, currentStockExposure) {
        const stock = this.stockWatchlist.find(s => s.code === code);
        if (!stock) {
            return { allowed: false, reason: '不在自选列表中' };
        }
        
        const maxAmount = totalAssets * this.singleStockMax;
        const remainingCapacity = totalAssets * this.stockSatelliteMax - currentStockExposure;
        
        if (remainingCapacity <= 0) {
            return { 
                allowed: false, 
                reason: `个股卫星仓已达上限${(this.stockSatelliteMax*100).toFixed(0)}%`
            };
        }
        
        const suggestedAmount = Math.min(maxAmount, remainingCapacity);
        
        return {
            allowed: true,
            stock: stock,
            maxAmount: maxAmount,
            suggestedAmount: suggestedAmount,
            reason: `可配置${suggestedAmount.toFixed(0)}元（单只上限${(this.singleStockMax*100).toFixed(0)}%）`
        };
    }

    /**
     * 生成当前状态报告
     */
    generateReport(regime, portfolio, availableCash) {
        const allocation = this.getAllocation(regime);
        const positionRatio = this.getPositionSizing(regime);
        const targetPosition = portfolio.totalAssets * positionRatio;
        const currentPosition = portfolio.securitiesValue;
        const toInvest = targetPosition - currentPosition;
        
        return {
            regime: regime,
            date: new Date().toISOString().split('T')[0],
            portfolio: {
                totalAssets: portfolio.totalAssets,
                securitiesValue: portfolio.securitiesValue,
                availableCash: availableCash,
                positionRatio: (currentPosition / portfolio.totalAssets * 100).toFixed(1) + '%'
            },
            target: {
                positionRatio: (positionRatio * 100).toFixed(0) + '%',
                targetPosition: targetPosition.toFixed(0),
                toInvest: toInvest.toFixed(0)
            },
            allocation: allocation,
            features: {
                stopLoss: (this.stopLossPct * 100).toFixed(0) + '%',
                trancheDrop: (this.trancheDropPct * 100).toFixed(0) + '%',
                stockSatellite: (this.stockSatelliteMax * 100).toFixed(0) + '%',
                t0Target: this.t0Target
            }
        };
    }
}

module.exports = RegimeEngineV3_7;
