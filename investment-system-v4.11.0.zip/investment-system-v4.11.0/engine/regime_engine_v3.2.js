/**
 * Regime Engine v3.2 - 基准版本
 * 保存日期: 2026-07-26
 * 
 * 核心参数:
 * - BULL阈值: 70% ETF上涨
 * - BEAR阈值: 30% ETF上涨
 * - 5日多数投票平滑
 * - 5天调仓冷却期
 * 
 * 回测结果 (2023-04-04 ~ 2026-07-24):
 * - 策略总收益: +30.84%
 * - 超额收益: +30.84% vs 沪深300
 * - 最大回撤: -16.34%
 * - 夏普比率: 0.74
 * - 调仓次数: 100
 */

const fs = require('fs');
const path = require('path');

class RegimeEngineV3_2 {
    constructor(config = {}) {
        // v3.2 基准参数
        this.bullThreshold = config.bullThreshold || 0.70;  // 70% ETF上涨
        this.bearThreshold = config.bearThreshold || 0.30;  // 30% ETF上涨
        this.smoothingWindow = config.smoothingWindow || 5;  // 5日平滑
        this.cooldownDays = config.cooldownDays || 5;        // 5天冷却期
        
        this.positionSizing = {
            BULL: 1.0,
            BEAR: 0.4,
            RANGE: 0.7
        };
        
        this.regimeHistory = [];
    }

    classify(etfData) {
        if (!etfData || etfData.length === 0) {
            return { state: 'RANGE', score: 0.5, confidence: 0 };
        }

        const total = etfData.length;
        const advancing = etfData.filter(etf => {
            const changePct = etf.change_pct;
            return changePct !== null && changePct !== undefined && changePct > 0;
        }).length;

        const ratio = advancing / total;

        let state = 'RANGE';
        if (ratio >= this.bullThreshold) {
            state = 'BULL';
        } else if (ratio <= this.bearThreshold) {
            state = 'BEAR';
        }

        return {
            state,
            score: ratio,
            confidence: Math.abs(ratio - 0.5) * 2,
            advancing,
            total
        };
    }

    smoothRegime(rawStates) {
        const smoothed = [];
        for (let i = 0; i < rawStates.length; i++) {
            const start = Math.max(0, i - this.smoothingWindow + 1);
            const windowStates = rawStates.slice(start, i + 1);
            
            const counts = {};
            windowStates.forEach(s => {
                counts[s] = (counts[s] || 0) + 1;
            });
            
            const vote = Object.entries(counts).sort((a, b) => b[1] - a[1])[0][0];
            smoothed.push(vote);
        }
        return smoothed;
    }
}

module.exports = RegimeEngineV3_2;
