/**
 * Regime Engine v3.4 - 当前基准版本（跨境优化）
 * 保存日期: 2026-07-26
 * 
 * 核心参数:
 * - BULL阈值: 60%
 * - BEAR阈值: 30%
 * - 5日多数投票平滑
 * - 5天调仓冷却期
 * 
 * 配置优化（vs v3.3）:
 * - RANGE期间增加跨境ETF权重（标普+日经=50%）
 * - BULL期间减少宽基、增加行业ETF
 * 
 * 回测结果 (2023-04-04 ~ 2026-07-24):
 * - 策略总收益: +68.66%
 * - 超额收益: +68.66% vs 沪深300
 * - 年化收益: +17.72%
 * - 最大回撤: -16.29%
 * - 夏普比率: 1.29 (超过1.0目标)
 * - 月度胜率: 60% (超过55%目标)
 * 
 * 配置详情:
 * BULL: 沪深300 10%, 人工智能 20%, 芯片 20%, 新能源 15%, 证券 10%, 标普 15%, 日经 10%
 * BEAR: 医药 25%, 电力 25%, 农业 20%, 标普 15%, 日经 15%
 * RANGE: 沪深300 20%, 标普 25%, 日经 25%, 医药 10%, 芯片 10%, 人工智能 10%
 * 
 * 关键发现:
 * - 跨境ETF在RANGE期间能显著降低回撤
 * - 夏普比率从1.11提升到1.29
 * - 月度胜率从50%提升到60%
 */

const fs = require('fs');
const path = require('path');

class RegimeEngineV3_4 {
    constructor(config = {}) {
        this.bullThreshold = config.bullThreshold || 0.60;
        this.bearThreshold = config.bearThreshold || 0.30;
        this.smoothingWindow = config.smoothingWindow || 5;
        this.cooldownDays = config.cooldownDays || 5;
        
        // v3.4 跨境优化配置
        this.allocation = {
            BULL: {
                "159330": 0.10,  // 沪深300
                "515070": 0.20,  // 人工智能
                "159599": 0.20,  // 芯片
                "516160": 0.15,  // 新能源
                "512880": 0.10,  // 证券
                "513650": 0.15,  // 标普500
                "513880": 0.10   // 日经225
            },
            BEAR: {
                "512010": 0.25,  // 医药
                "159611": 0.25,  // 电力
                "159825": 0.20,  // 农业
                "513650": 0.15,  // 标普500
                "513880": 0.15   // 日经225
            },
            RANGE: {
                "159330": 0.20,  // 沪深300
                "513650": 0.25,  // 标普500
                "513880": 0.25,  // 日经225
                "512010": 0.10,  // 医药
                "159599": 0.10,  // 芯片
                "515070": 0.10   // 人工智能
            }
        };
        
        this.positionSizing = {
            BULL: 1.0,
            BEAR: 0.4,
            RANGE: 0.7
        };
        
        this.regimeHistory = [];
    }

    classify(etfData) {
        if (!etfData || etfData.length === 0) {
            return { state: 'RANGE', score: 0.5, confidence: 0 };
        }

        const total = etfData.length;
        const advancing = etfData.filter(etf => {
            const changePct = etf.change_pct;
            return changePct !== null && changePct !== undefined && changePct > 0;
        }).length;

        const ratio = advancing / total;

        let state = 'RANGE';
        if (ratio >= this.bullThreshold) {
            state = 'BULL';
        } else if (ratio <= this.bearThreshold) {
            state = 'BEAR';
        }

        return {
            state,
            score: ratio,
            confidence: Math.abs(ratio - 0.5) * 2,
            advancing,
            total
        };
    }

    smoothRegime(rawStates) {
        const smoothed = [];
        for (let i = 0; i < rawStates.length; i++) {
            const start = Math.max(0, i - this.smoothingWindow + 1);
            const windowStates = rawStates.slice(start, i + 1);
            
            const counts = {};
            windowStates.forEach(s => {
                counts[s] = (counts[s] || 0) + 1;
            });
            
            const vote = Object.entries(counts).sort((a, b) => b[1] - a[1])[0][0];
            smoothed.push(vote);
        }
        return smoothed;
    }

    getAllocation(regime) {
        return this.allocation[regime] || this.allocation.RANGE;
    }

    getPositionSizing(regime) {
        return this.positionSizing[regime] || 0.7;
    }
}

module.exports = RegimeEngineV3_4;
