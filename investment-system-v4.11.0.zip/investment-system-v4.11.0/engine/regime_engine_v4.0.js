/** V4.0 deterministic ETF regime engine. All inputs are daily-close records. */
class RegimeEngineV4_0 {
    constructor(config = {}) {
        this.bullThreshold = config.bullThreshold ?? 0.60;
        this.bearThreshold = config.bearThreshold ?? 0.30;
        this.confirmDays = config.confirmDays ?? 3;
        this.universe = config.universe ?? ['512010', '512880', '513650', '513880', '515070', '516160'];
        this.allocation = {
            BULL: { '515070': .16, '516160': .10, '512880': .10, '513650': .32, '513880': .32 },
            BEAR: { '512010': .30, '512880': .15, '513650': .275, '513880': .275 },
            RANGE: { '512010': .17, '515070': .17, '512880': .10, '513650': .28, '513880': .28 }
        };
        this.positionSizing = { BULL: .90, BEAR: .40, RANGE: .70 };
        this.pendingState = config.pendingState ?? null;
        this.pendingDays = config.pendingDays ?? 0;
        this.confirmedState = config.confirmedState ?? 'RANGE';
    }
    classify(records) {
        const usable = records.filter(r => this.universe.includes(r.code) && Number.isFinite(r.change_pct));
        if (usable.length !== this.universe.length) return { state: this.confirmedState, valid: false, reason: 'incomplete_universe' };
        const advancing = usable.filter(r => r.change_pct > 0).length;
        const score = advancing / usable.length;
        const rawState = score >= this.bullThreshold ? 'BULL' : score <= this.bearThreshold ? 'BEAR' : 'RANGE';
        if (rawState === this.confirmedState) { this.pendingState = null; this.pendingDays = 0; }
        else if (rawState === this.pendingState) this.pendingDays += 1;
        else { this.pendingState = rawState; this.pendingDays = 1; }
        if (this.pendingDays >= this.confirmDays) { this.confirmedState = rawState; this.pendingState = null; this.pendingDays = 0; }
        return { state: this.confirmedState, rawState, score, advancing, total: usable.length, valid: true };
    }
    getTargetWeights(state) {
        const allocation = this.allocation[state] ?? this.allocation.RANGE;
        const exposure = this.positionSizing[state] ?? this.positionSizing.RANGE;
        return Object.fromEntries(Object.entries(allocation).map(([code, weight]) => [code, weight * exposure]));
    }
}
module.exports = RegimeEngineV4_0;
