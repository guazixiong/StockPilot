/**
 * Regime Engine v3.3 - 当前基准版本
 * 保存日期: 2026-07-26
 * 
 * 核心参数:
 * - BULL阈值: 60% (从v3.2的70%优化)
 * - BEAR阈值: 30%
 * - 5日多数投票平滑
 * - 5天调仓冷却期
 * 
 * 回测结果 (2023-04-04 ~ 2026-07-24):
 * - 策略总收益: +64.67%
 * - 超额收益: +64.67% vs 沪深300
 * - 年化收益: +16.84%
 * - 最大回撤: -19.20%
 * - 夏普比率: 1.11 (超过1.0目标)
 * - 调仓次数: 120
 * - BULL天数: 317天 (39.6%)
 * - BEAR天数: 251天 (31.3%)
 * - RANGE天数: 233天 (29.1%)
 * 
 * 各Regime表现:
 * - BULL: +264.08% (317天)
 * - BEAR: -40.53% (251天)
 * - RANGE: -14.33% (233天)
 * 
 * 关键优化:
 * - BULL阈值从70%降到60%，捕捉更多上涨机会
 * - BULL天数从158天增加到317天
 * - 夏普比率从0.90提升到1.11
 */

const fs = require('fs');
const path = require('path');

class RegimeEngineV3_3 {
    constructor(config = {}) {
        // v3.3 基准参数
        this.bullThreshold = config.bullThreshold || 0.60;  // 60% ETF上涨
        this.bearThreshold = config.bearThreshold || 0.30;  // 30% ETF上涨
        this.smoothingWindow = config.smoothingWindow || 5;  // 5日平滑
        this.cooldownDays = config.cooldownDays || 5;        // 5天冷却期
        
        this.positionSizing = {
            BULL: 1.0,
            BEAR: 0.4,
            RANGE: 0.7
        };
        
        this.regimeHistory = [];
    }

    classify(etfData) {
        if (!etfData || etfData.length === 0) {
            return { state: 'RANGE', score: 0.5, confidence: 0 };
        }

        const total = etfData.length;
        const advancing = etfData.filter(etf => {
            const changePct = etf.change_pct;
            return changePct !== null && changePct !== undefined && changePct > 0;
        }).length;

        const ratio = advancing / total;

        let state = 'RANGE';
        if (ratio >= this.bullThreshold) {
            state = 'BULL';
        } else if (ratio <= this.bearThreshold) {
            state = 'BEAR';
        }

        return {
            state,
            score: ratio,
            confidence: Math.abs(ratio - 0.5) * 2,
            advancing,
            total
        };
    }

    smoothRegime(rawStates) {
        const smoothed = [];
        for (let i = 0; i < rawStates.length; i++) {
            const start = Math.max(0, i - this.smoothingWindow + 1);
            const windowStates = rawStates.slice(start, i + 1);
            
            const counts = {};
            windowStates.forEach(s => {
                counts[s] = (counts[s] || 0) + 1;
            });
            
            const vote = Object.entries(counts).sort((a, b) => b[1] - a[1])[0][0];
            smoothed.push(vote);
        }
        return smoothed;
    }
}

module.exports = RegimeEngineV3_3;
