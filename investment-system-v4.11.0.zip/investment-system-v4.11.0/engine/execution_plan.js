/**
 * Execution Plan Generator - 精确执行计划
 * 
 * 解决缺陷：
 * - #7 只输出仓位上限、配置方向，无精确执行标尺
 * - #10 调仓方案未考虑滑点、流动性冲击
 * 
 * 输出：每只ETF的具体调仓比例、参考价、止损位、拆单建议
 */

const fs = require('fs');
const path = require('path');

class ExecutionPlanGenerator {
    constructor(config = {}) {
        // 默认资金量
        this.capital = config.capital || 1000000;
        // 拆单阈值（单笔超过日均成交额的 2% 建议拆单）
        this.splitThreshold = config.splitThreshold || 0.02;
        // 最小调仓金额（低于此金额忽略）
        this.minTradeAmount = config.minTradeAmount || 5000;
    }

    /**
     * 生成精确执行计划
     * 
     * @param {Object} params
     * @param {string} params.regime - 当前状态
     * @param {Object} params.allocation - 目标配置 { code: weight }
     * @param {number} params.positionSizing - 仓位比例 (0-1)
     * @param {Object} params.decay - 衰减确认信息
     * @param {Object} params.currentPositions - 当前持仓 { code: { weight, amount } }
     * @param {Object[]} params.etfData - 当日ETF数据（含 close, amount）
     * @param {Object} params.stopLoss - 止损配置
     * @param {Object} params.liquidity - 流动性评估结果
     * @returns {Object} 执行计划
     */
    generate(params) {
        const {
            regime,
            allocation,
            positionSizing,
            decay,
            currentPositions = {},
            etfData = [],
            stopLoss = {},
            liquidity = null
        } = params;

        // 应用衰减确认权重
        const effectivePositionSizing = positionSizing * (decay?.positionWeight || 1.0);
        const investAmount = this.capital * effectivePositionSizing;

        // 构建ETF数据索引
        const etfMap = {};
        etfData.forEach(e => { etfMap[e.code] = e; });

        // 计算目标配置
        const trades = [];
        for (const [code, targetWeight] of Object.entries(allocation)) {
            const etf = etfMap[code];
            const name = etf?.name || code;
            const currentPrice = etf?.close || 0;
            const dailyAmount = etf?.amount || 0; // 日均成交额

            const current = currentPositions[code] || { weight: 0, amount: 0 };
            const targetAmount = investAmount * targetWeight;
            const currentAmount = investAmount * current.weight;
            const diff = targetAmount - currentAmount;

            // 止损价
            const stopLossPct = stopLoss.default || -0.05;
            const stopLossPrice = currentPrice * (1 + stopLossPct);

            // 拆单建议
            const tradeLots = this._calculateLots(diff, dailyAmount);

            // 流动性风险标记
            const liquidityRisk = liquidity?.details?.find(l => l.code === code);

            if (Math.abs(diff) >= this.minTradeAmount) {
                trades.push({
                    code,
                    name,
                    action: diff > 0 ? '加仓' : '减仓',
                    currentWeight: Math.round(current.weight * 100),
                    targetWeight: Math.round(targetWeight * 100),
                    currentAmount: Math.round(currentAmount),
                    targetAmount: Math.round(targetAmount),
                    diff: Math.round(diff),
                    diffPercent: currentAmount > 0 ? Math.round((diff / currentAmount) * 100) : null,
                    currentPrice,
                    stopLossPrice: Math.round(stopLossPrice * 100) / 100,
                    stopLossPercent: Math.round(stopLossPct * 100),
                    tradeLots,
                    slippageEstimate: liquidityRisk?.slippageEstimate || 0.05,
                    liquidityLevel: liquidityRisk?.level || 'MEDIUM'
                });
            }
        }

        // 按调仓金额绝对值排序
        trades.sort((a, b) => Math.abs(b.diff) - Math.abs(a.diff));

        // 现金比例
        const cashRatio = Math.round((1 - effectivePositionSizing) * 100);
        const cashAmount = this.capital - investAmount;

        return {
            regime,
            capital: this.capital,
            effectivePositionSizing: Math.round(effectivePositionSizing * 100),
            rawPositionSizing: Math.round(positionSizing * 100),
            decayApplied: decay?.positionWeight !== 1.0,
            decayNote: decay?.note || '',
            investAmount: Math.round(investAmount),
            cashRatio,
            cashAmount: Math.round(cashAmount),
            trades,
            totalTrades: trades.length,
            summary: this._generateSummary(trades, effectivePositionSizing, regime)
        };
    }

    /**
     * 拆单计算
     * 单笔超过日均成交额 2% 时建议拆单
     */
    _calculateLots(amount, dailyAmount) {
        if (dailyAmount <= 0 || Math.abs(amount) <= dailyAmount * this.splitThreshold) {
            return { lots: 1, perLot: Math.abs(Math.round(amount)), note: '可一次性执行' };
        }

        const maxPerLot = dailyAmount * this.splitThreshold;
        const lots = Math.ceil(Math.abs(amount) / maxPerLot);
        return {
            lots: Math.min(lots, 5), // 最多5笔
            perLot: Math.round(Math.abs(amount) / Math.min(lots, 5)),
            note: `建议分${Math.min(lots, 5)}笔执行，降低冲击成本`
        };
    }

    /**
     * 生成文本摘要
     */
    _generateSummary(trades, positionSizing, regime) {
        const buyTrades = trades.filter(t => t.diff > 0);
        const sellTrades = trades.filter(t => t.diff < 0);

        let summary = '';
        summary += `调仓方向: ${buyTrades.length > 0 ? `加仓${buyTrades.length}只` : ''}`;
        summary += `${sellTrades.length > 0 ? ` 减仓${sellTrades.length}只` : ''}`;
        summary += `\n仓位: ${Math.round(positionSizing * 100)}% | Regime: ${regime}`;
        return summary;
    }

    /**
     * 生成文本格式的执行计划报告
     */
    toTextReport(plan) {
        let report = `三、执行计划\n`;
        report += `${'─'.repeat(40)}\n`;
        report += `仓位: ${plan.rawPositionSizing}%`;
        if (plan.decayApplied) {
            report += ` → ${plan.effectivePositionSizing}%（${plan.decayNote}）`;
        }
        report += `\n投资金额: ¥${plan.investAmount.toLocaleString()} | 现金: ${plan.cashRatio}% (¥${plan.cashAmount.toLocaleString()})\n\n`;

        if (plan.trades.length === 0) {
            report += `无需调仓，维持现有配置\n`;
            return report;
        }

        // 表格
        const codeWidth = 10, weightWidth = 6, amountWidth = 10, actionWidth = 6;
        const header = [
            'ETF'.padEnd(codeWidth),
            '当前'.padStart(weightWidth),
            '目标'.padStart(weightWidth),
            '操作'.padStart(actionWidth),
            '金额'.padStart(amountWidth),
            '止损价'.padStart(8)
        ].join(' | ');
        report += header + '\n';
        report += '─'.repeat(header.length) + '\n';

        for (const t of plan.trades) {
            const row = [
                t.name.substring(0, 8).padEnd(codeWidth),
                `${t.currentWeight}%`.padStart(weightWidth),
                `${t.targetWeight}%`.padStart(weightWidth),
                t.action.padStart(actionWidth),
                `¥${Math.abs(t.diff).toLocaleString()}`.padStart(amountWidth),
                `¥${t.stopLossPrice}`.padStart(8)
            ].join(' | ');
            report += row + '\n';

            // 拆单提示
            if (t.tradeLots.lots > 1) {
                report += `  └─ ${t.tradeLots.note}\n`;
            }
            // 流动性警告
            if (t.liquidityLevel === 'LOW') {
                report += `  └─ ⚠️ 流动性低，滑点约${t.slippageEstimate}%\n`;
            }
        }

        // 止损汇总
        report += `\n止损线（${plan.regime}）:\n`;
        for (const t of plan.trades) {
            if (t.diff > 0) { // 只对加仓的标的提示止损
                report += `  ${t.name}: ${t.stopLossPercent}%（¥${t.stopLossPrice}）\n`;
            }
        }

        return report;
    }
}

module.exports = { ExecutionPlanGenerator };
