/**
 * etf_breadth.js
 * 
 * 职责：基于11只ETF计算市场宽度指标
 * 
 * 输入：某日所有ETF的行情数据（来自snapshot parquet）
 * 输出：BreadthReport
 * 
 * 指标体系：
 *   1. 基础breadth：涨跌家数
 *   2. 行业breadth：行业ETF涨跌
 *   3. 跨境breadth：跨境ETF涨跌
 *   4. 动量breadth：近期表现
 *   5. 波动breadth：波动率分布
 */

const fs = require('fs');
const path = require('path');

class EtfBreadth {
  constructor(config = {}) {
    this.etfConfig = this._loadEtfConfig();
    this.lookbackShort = config.lookbackShort || 5;
    this.lookbackLong = config.lookbackLong || 20;
    this.highVolThreshold = config.highVolThreshold || 2.0; // 日波动率>2%为高波动
  }

  /**
   * 计算单日的 Breadth 指标
   * @param {Object[]} etfRecords - 当日所有ETF的行情记录
   * @param {Object[]} [prevRecords] - 前一日记录（用于计算变化）
   * @returns {BreadthReport}
   */
  calculateDaily(etfRecords, prevRecords = []) {
    const date = etfRecords[0]?.date || 'unknown';
    const prevMap = {};
    for (const r of prevRecords) prevMap[r.code] = r;

    // 分类
    const broad = etfRecords.filter(r => this._getType(r.code) === 'broad');
    const industry = etfRecords.filter(r => this._getType(r.code) === 'industry');
    const theme = etfRecords.filter(r => this._getType(r.code) === 'theme');
    const crossBorder = etfRecords.filter(r => this._getType(r.code) === 'cross_border');

    // 1. 基础breadth
    const advance = etfRecords.filter(r => r.change_pct > 0).length;
    const decline = etfRecords.filter(r => r.change_pct < 0).length;
    const flat = etfRecords.filter(r => r.change_pct === 0).length;
    const total = etfRecords.length;
    const advanceRatio = total > 0 ? advance / total : 0;

    // 2. 行业breadth（行业+主题）
    const sectorAll = [...industry, ...theme];
    const sectorAdvance = sectorAll.filter(r => r.change_pct > 0).length;
    const sectorDecline = sectorAll.filter(r => r.change_pct < 0).length;
    const sectorRatio = sectorAll.length > 0 ? sectorAdvance / sectorAll.length : 0;

    // 3. 跨境breadth
    const overseasAdvance = crossBorder.filter(r => r.change_pct > 0).length;
    const overseasDecline = crossBorder.filter(r => r.change_pct < 0).length;
    const overseasRatio = crossBorder.length > 0 ? overseasAdvance / crossBorder.length : 0;

    // 4. 宽基表现
    const broadAvgChange = broad.length > 0
      ? broad.reduce((s, r) => s + r.change_pct, 0) / broad.length
      : 0;

    // 5. 平均涨跌幅
    const avgChange = etfRecords.reduce((s, r) => s + r.change_pct, 0) / total;

    // 6. 涨跌幅分布
    const changes = etfRecords.map(r => r.change_pct).sort((a, b) => a - b);
    const medianChange = changes[Math.floor(changes.length / 2)];
    const maxChange = changes[changes.length - 1];
    const minChange = changes[0];

    return {
      date,
      version: '1.0',

      // 基础 breadth
      advance,
      decline,
      flat,
      total,
      advance_ratio: Math.round(advanceRatio * 1000) / 1000,

      // 行业 breadth
      sector_advance: sectorAdvance,
      sector_decline: sectorDecline,
      sector_ratio: Math.round(sectorRatio * 1000) / 1000,

      // 跨境 breadth
      overseas_advance: overseasAdvance,
      overseas_decline: overseasDecline,
      overseas_ratio: Math.round(overseasRatio * 1000) / 1000,

      // 宽基表现
      broad_avg_change: Math.round(broadAvgChange * 100) / 100,

      // 统计
      avg_change: Math.round(avgChange * 100) / 100,
      median_change: Math.round(medianChange * 100) / 100,
      max_change: Math.round(maxChange * 100) / 100,
      min_change: Math.round(minChange * 100) / 100
    };
  }

  /**
   * 计算一段时间的 Breadth 动量
   * @param {BreadthReport[]} breadthSeries - 每日breadth时间序列
   * @returns {BreadthMomentum}
   */
  calculateMomentum(breadthSeries) {
    if (breadthSeries.length < this.lookbackShort) {
      return null;
    }

    const current = breadthSeries[breadthSeries.length - 1];
    const recent5 = breadthSeries.slice(-this.lookbackShort);
    const recent20 = breadthSeries.slice(-this.lookbackLong);

    // 5日均值
    const avg5 = recent5.reduce((s, b) => s + b.advance_ratio, 0) / recent5.length;
    
    // 20日均值（如果数据足够）
    const avg20 = recent20.length >= this.lookbackLong
      ? recent20.reduce((s, b) => s + b.advance_ratio, 0) / recent20.length
      : avg5;

    // Breadth Momentum = 当前 - 5日均值
    const momentum5 = current.advance_ratio - avg5;
    
    // Breadth Thrust = 5日上涨ETF累计比例
    const thrust5 = recent5.reduce((s, b) => s + b.advance, 0) / (recent5.length * current.total);

    // 趋势判断
    const improving = momentum5 > 0.05;  // 当前比5日均值高5%以上
    const deteriorating = momentum5 < -0.05;

    return {
      date: current.date,
      current_ratio: current.advance_ratio,
      avg5_ratio: Math.round(avg5 * 1000) / 1000,
      avg20_ratio: Math.round(avg20 * 1000) / 1000,
      momentum5: Math.round(momentum5 * 1000) / 1000,
      thrust5: Math.round(thrust5 * 1000) / 1000,
      trend: improving ? 'improving' : (deteriorating ? 'deteriorating' : 'stable')
    };
  }

  /**
   * 批量计算历史 Breadth 时间序列
   * @param {string} startDate - YYYY-MM-DD
   * @param {string} endDate - YYYY-MM-DD
   * @returns {BreadthReport[]}
   */
  calculateHistorical(startDate, endDate) {
    const snapshotDir = path.join(__dirname, '../data/snapshot');
    const dates = this._getAvailableDates(snapshotDir, startDate, endDate);
    
    // 批量预读所有 snapshot（一次子进程调用）
    console.log(`[Breadth] 预读 ${dates.length} 个日期的 snapshot...`);
    const allSnapshots = this._batchReadSnapshots(snapshotDir, dates);
    console.log(`[Breadth] 预读完成，${Object.keys(allSnapshots).length} 个有效日期`);

    const breadthSeries = [];
    let prevRecords = [];

    for (const date of dates) {
      const records = allSnapshots[date];
      if (!records || records.length === 0) continue;

      const breadth = this.calculateDaily(records, prevRecords);
      breadthSeries.push(breadth);
      prevRecords = records;
    }

    // 计算动量
    const withMomentum = [];
    for (let i = 0; i < breadthSeries.length; i++) {
      const slice = breadthSeries.slice(0, i + 1);
      const momentum = this.calculateMomentum(slice);
      withMomentum.push({
        ...breadthSeries[i],
        momentum: momentum
      });
    }

    return withMomentum;
  }

  /**
   * 批量预读所有 snapshot 文件（单次子进程调用，避免1000+次进程启动）
   */
  _batchReadSnapshots(snapshotDir, dates) {
    const { execSync } = require('child_process');
    const parquetFiles = dates.map(d => {
      const [year, month] = d.split('-');
      return { date: d, path: path.join(snapshotDir, year, month, `${d}.parquet`) };
    }).filter(f => fs.existsSync(f.path));

    const filesJson = JSON.stringify(parquetFiles);
    const script = `const parquet = require('parquetjs'); const fs = require('fs'); async function readAll() { const files = ${filesJson}; const result = {}; for (const f of files) { try { const reader = await parquet.ParquetReader.openFile(f.path); const cursor = reader.getCursor(); const rows = []; let row; while (row = await cursor.next()) rows.push(row); await reader.close(); result[f.date] = rows; } catch(e) {} } process.stdout.write(JSON.stringify(result)); } readAll();`;

    try {
      const result = execSync(script, {
        encoding: 'utf8',
        timeout: 60000,
        maxBuffer: 100 * 1024 * 1024
      });
      return JSON.parse(result);
    } catch (e) {
      console.warn('[Breadth] 批量读取失败:', e.message);
      return {};
    }
  }

  _getType(code) {
    const etf = this.etfConfig.portfolio.find(e => e.code === code);
    return etf?.type || 'unknown';
  }

  _loadEtfConfig() {
    const configPath = path.join(__dirname, '../config/etf.json');
    return JSON.parse(fs.readFileSync(configPath, 'utf8'));
  }

  _getAvailableDates(snapshotDir, startDate, endDate) {
    const dates = [];
    const [startYear, startMonth] = startDate.split('-').map(Number);
    const [endYear, endMonth] = endDate.split('-').map(Number);

    for (let y = startYear; y <= endYear; y++) {
      const mStart = (y === startYear) ? startMonth : 1;
      const mEnd = (y === endYear) ? endMonth : 12;

      for (let m = mStart; m <= mEnd; m++) {
        const dir = path.join(snapshotDir, String(y), String(m).padStart(2, '0'));
        if (!fs.existsSync(dir)) continue;

        const files = fs.readdirSync(dir).filter(f => f.endsWith('.parquet')).sort();
        for (const file of files) {
          const date = file.replace('.parquet', '');
          if (date >= startDate && date <= endDate) {
            dates.push(date);
          }
        }
      }
    }

    return dates.sort();
  }


}

module.exports = { EtfBreadth };
