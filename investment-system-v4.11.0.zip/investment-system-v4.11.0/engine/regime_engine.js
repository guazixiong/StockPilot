/**
 * regime_engine.js
 * 
 * 职责：基于 ETF Breadth 指标识别市场状态（Regime）
 * 
 * 状态定义（概率模型，非二元判定）：
 *   BULL        >70% ETF上涨，趋势向上
 *   BEAR        >70% ETF下跌，趋势向下
 *   RANGE       涨跌均衡，无明确方向
 *   RECOVERY    从BEAR转BULL初期，需确认
 *   DISTRIBUTION 从BULL转BEAR初期，顶部派发
 * 
 * 核心设计：
 *   - 使用概率模型，不是 yes/no 判定
 *   - 综合 breadth、momentum、趋势多维度
 *   - RECOVERY 需要连续确认，避免假信号
 */

const fs = require('fs');
const path = require('path');
const { EtfBreadth } = require('./etf_breadth');

class RegimeEngine {
  constructor(config = {}) {
    this.breadth = new EtfBreadth(config.breadth || {});
    
    // 状态概率阈值
    this.thresholds = {
      bull: config.bullThreshold || 0.70,
      bear: config.bearThreshold || 0.30,
      recovery_confirm_days: config.recoveryConfirmDays || 3,
      distribution_confirm_days: config.distributionConfirmDays || 3
    };
    
    // 持久化状态
    this.stateFile = path.join(__dirname, '../data/regime/regime_state.json');
    this.historyFile = path.join(__dirname, '../data/regime/regime_history.jsonl');
  }

  /**
   * 计算单日的 Regime 概率
   * @param {BreadthReport} breadth - 当日breadth指标
   * @param {BreadthMomentum} [momentum] - 动量指标
   * @param {RegimeState} [prevState] - 前一日状态
   * @returns {RegimeProbabilities}
   */
  calculateProbabilities(breadth, momentum, prevState) {
    // 各维度评分（0-1）
    const breadthScore = this._breadthScore(breadth);
    const momentumScore = momentum ? this._momentumScore(momentum) : 0.5;
    const trendScore = this._trendScore(breadth, prevState);
    const crossBorderScore = this._crossBorderScore(breadth);

    // 综合评分（加权平均）
    const weights = { breadth: 0.35, momentum: 0.25, trend: 0.25, crossBorder: 0.15 };
    
    const bullScore = 
      breadthScore.bull * weights.breadth +
      momentumScore.bull * weights.momentum +
      trendScore.bull * weights.trend +
      crossBorderScore.bull * weights.crossBorder;

    const bearScore = 
      breadthScore.bear * weights.breadth +
      momentumScore.bear * weights.momentum +
      trendScore.bear * weights.trend +
      crossBorderScore.bear * weights.crossBorder;

    // 归一化
    const total = bullScore + bearScore;
    const bullProb = total > 0 ? bullScore / total : 0.5;
    const bearProb = total > 0 ? bearScore / total : 0.5;

    // 判定状态
    let state;
    if (bullProb >= this.thresholds.bull) {
      state = 'BULL';
    } else if (bearProb >= this.thresholds.bear) {
      state = 'BEAR';
    } else {
      state = 'RANGE';
    }

    // 检测状态转换
    const transition = this._detectTransition(state, prevState);

    return {
      date: breadth.date,
      state: transition.state,
      previous_state: prevState?.state || null,
      transition: transition.type,
      confidence: Math.round(Math.max(bullProb, bearProb) * 1000) / 1000,
      probabilities: {
        bull: Math.round(bullProb * 1000) / 1000,
        bear: Math.round(bearProb * 1000) / 1000,
        range: Math.round((1 - bullProb - bearProb) * 1000) / 1000
      },
      scores: {
        breadth: breadthScore,
        momentum: momentumScore,
        trend: trendScore,
        cross_border: crossBorderScore
      }
    };
  }

  /**
   * Breadth 维度评分
   */
  _breadthScore(breadth) {
    const ratio = breadth.advance_ratio;
    
    // 强牛：>70% 上涨
    if (ratio >= 0.7) return { bull: 0.9, bear: 0.1 };
    // 弱牛：55-70%
    if (ratio >= 0.55) return { bull: 0.65, bear: 0.35 };
    // 中性：45-55%
    if (ratio >= 0.45) return { bull: 0.5, bear: 0.5 };
    // 弱熊：30-45%
    if (ratio >= 0.3) return { bull: 0.35, bear: 0.65 };
    // 强熊：<30%
    return { bull: 0.1, bear: 0.9 };
  }

  /**
   * 动量维度评分
   */
  _momentumScore(momentum) {
    const m5 = momentum.momentum5;
    const trend = momentum.trend;

    let bull = 0.5;
    let bear = 0.5;

    if (trend === 'improving') {
      bull = 0.7;
      bear = 0.3;
    } else if (trend === 'deteriorating') {
      bull = 0.3;
      bear = 0.7;
    }

    // thrust 调整
    if (momentum.thrust5 > 0.6) bull += 0.1;
    if (momentum.thrust5 < 0.3) bear += 0.1;

    return { 
      bull: Math.min(bull, 1), 
      bear: Math.min(bear, 1) 
    };
  }

  /**
   * 趋势维度评分（基于近期状态连续性）
   */
  _trendScore(breadth, prevState) {
    if (!prevState) return { bull: 0.5, bear: 0.5 };

    const prev = prevState.state;
    const current = breadth.advance_ratio;

    // 如果之前是BULL，当前breadth仍>50%，保持牛倾向
    if (prev === 'BULL' && current > 0.5) return { bull: 0.7, bear: 0.3 };
    if (prev === 'BULL' && current <= 0.5) return { bull: 0.4, bear: 0.6 };

    // 如果之前是BEAR，当前breadth<50%，保持熊倾向
    if (prev === 'BEAR' && current < 0.5) return { bull: 0.3, bear: 0.7 };
    if (prev === 'BEAR' && current >= 0.5) return { bull: 0.6, bear: 0.4 };

    return { bull: 0.5, bear: 0.5 };
  }

  /**
   * 跨境维度评分
   */
  _crossBorderScore(breadth) {
    const ratio = breadth.overseas_ratio;

    if (ratio >= 0.7) return { bull: 0.7, bear: 0.3 };
    if (ratio <= 0.3) return { bull: 0.3, bear: 0.7 };
    return { bull: 0.5, bear: 0.5 };
  }

  /**
   * 检测状态转换
   * RECOVERY: BEAR → RANGE 或 BEAR → BULL，需连续确认
   * DISTRIBUTION: BULL → RANGE 或 BULL → BEAR，需连续确认
   */
  _detectTransition(currentState, prevState) {
    if (!prevState) {
      return { state: currentState, type: null };
    }

    const prev = prevState.state;
    const confirmCount = prevState._confirmCount || 0;

    // 直接转换（BULL↔BEAR 不需要确认）
    if (prev === 'BULL' && currentState === 'BEAR') {
      return { state: 'DISTRIBUTION', type: 'BULL_TO_DISTRIBUTION' };
    }
    if (prev === 'BEAR' && currentState === 'BULL') {
      return { state: 'RECOVERY', type: 'BEAR_TO_RECOVERY' };
    }

    // BEAR → RANGE：可能是 RECOVERY 初期
    if (prev === 'BEAR' && currentState === 'RANGE') {
      if (confirmCount >= this.thresholds.recovery_confirm_days) {
        return { state: 'RECOVERY', type: 'BEAR_TO_RECOVERY_CONFIRMED' };
      }
      return { state: 'RANGE', type: 'POTENTIAL_RECOVERY', _confirmCount: confirmCount + 1 };
    }

    // BULL → RANGE：可能是 DISTRIBUTION 初期
    if (prev === 'BULL' && currentState === 'RANGE') {
      if (confirmCount >= this.thresholds.distribution_confirm_days) {
        return { state: 'DISTRIBUTION', type: 'BULL_TO_DISTRIBUTION_CONFIRMED' };
      }
      return { state: 'RANGE', type: 'POTENTIAL_DISTRIBUTION', _confirmCount: confirmCount + 1 };
    }

    // 状态不变
    if (prev === currentState) {
      return { state: currentState, type: null, _confirmCount: 0 };
    }

    return { state: currentState, type: null, _confirmCount: 0 };
  }

  /**
   * 批量回测历史 Regime
   * @param {string} startDate
   * @param {string} endDate
   * @returns {RegimeResult[]}
   */
  backtest(startDate, endDate) {
    console.log(`[Regime] 开始回测 ${startDate} ~ ${endDate}`);
    
    // 计算 breadth 时间序列
    const breadthSeries = this.breadth.calculateHistorical(startDate, endDate);
    console.log(`[Regime] 计算 ${breadthSeries.length} 个交易日的 Breadth`);

    // 逐日计算 regime
    const results = [];
    let prevState = null;

    for (const breadth of breadthSeries) {
      const regime = this.calculateProbabilities(breadth, breadth.momentum, prevState);
      results.push({
        ...regime,
        breadth: {
          advance_ratio: breadth.advance_ratio,
          sector_ratio: breadth.sector_ratio,
          overseas_ratio: breadth.overseas_ratio,
          avg_change: breadth.avg_change,
          momentum5: breadth.momentum?.momentum5,
          thrust5: breadth.momentum?.thrust5
        }
      });
      prevState = regime;
    }

    console.log(`[Regime] 回测完成，生成 ${results.length} 条 Regime 记录`);
    return results;
  }

  /**
   * 保存回测结果
   */
  saveResults(results) {
    const regimeDir = path.join(__dirname, '../data/regime');
    fs.mkdirSync(regimeDir, { recursive: true });

    // 保存历史
    const historyPath = path.join(regimeDir, 'regime_history.jsonl');
    fs.writeFileSync(historyPath, results.map(r => JSON.stringify(r)).join('\n') + '\n');

    // 保存最新状态
    const latest = results[results.length - 1];
    const statePath = path.join(regimeDir, 'regime_state.json');
    fs.writeFileSync(statePath, JSON.stringify(latest, null, 2));

    console.log(`[Regime] 已保存到 ${regimeDir}`);
  }
}

module.exports = { RegimeEngine };
