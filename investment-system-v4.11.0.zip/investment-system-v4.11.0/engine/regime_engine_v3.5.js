/**
 * Regime Engine v3.5 - 当前基准版本（稳健型）
 * 保存日期: 2026-07-26
 * 
 * 核心参数:
 * - BULL阈值: 60%
 * - BEAR阈值: 30%
 * - 5日多数投票平滑
 * - 5天调仓冷却期
 * 
 * 配置优化（vs v3.4）:
 * - BULL期间增加跨境ETF权重（标普+日经=40%）
 * - BEAR期间减少高波动ETF，增加医药/电力
 * - RANGE期间保持跨境权重（标普+日经=40%）
 * 
 * 回测结果 (2023-04-04 ~ 2026-07-24):
 * - 策略总收益: +69.07%
 * - 超额收益: +69.07% vs 沪深300
 * - 年化收益: +17.81%
 * - 最大回撤: -14.51%
 * - 夏普比率: 1.36 (接近优秀水平)
 * - 月度胜率: 60%
 * 
 * 配置详情:
 * BULL: 沪深300 10%, 人工智能 15%, 芯片 15%, 新能源 10%, 证券 10%, 标普 20%, 日经 20%
 * BEAR: 医药 30%, 电力 30%, 标普 20%, 日经 20%
 * RANGE: 沪深300 15%, 人工智能 15%, 芯片 15%, 标普 20%, 日经 20%, 医药 15%
 * 
 * vs v3.4 改进:
 * - 夏普比率: 1.29 → 1.36 (+5%)
 * - 最大回撤: -16.29% → -14.51% (+11%)
 * - BEAR保护: -36.45% → -33.54% (+2.92%)
 * - RANGE保护: -8.27% → -4.91% (+3.37%)
 */

const fs = require('fs');
const path = require('path');

class RegimeEngineV3_5 {
    constructor(config = {}) {
        this.bullThreshold = config.bullThreshold || 0.60;
        this.bearThreshold = config.bearThreshold || 0.30;
        this.smoothingWindow = config.smoothingWindow || 5;
        this.cooldownDays = config.cooldownDays || 5;
        
        // v3.5 稳健型配置
        this.allocation = {
            BULL: {
                "159330": 0.08,  // 沪深300
                "515070": 0.13,  // 人工智能
                "159599": 0.13,  // 芯片
                "516160": 0.08,  // 新能源
                "512880": 0.08,  // 证券
                "560710": 0.10,  // 船舶ETF富国
                "513650": 0.20,  // 标普500
                "513880": 0.20   // 日经225
            },
            BEAR: {
                "512010": 0.30,  // 医药
                "159611": 0.30,  // 电力
                "513650": 0.20,  // 标普500
                "513880": 0.20   // 日经225
            },
            RANGE: {
                "159330": 0.13,  // 沪深300
                "515070": 0.13,  // 人工智能
                "159599": 0.13,  // 芯片
                "560710": 0.08,  // 船舶ETF富国
                "513650": 0.20,  // 标普500
                "513880": 0.20,  // 日经225
                "512010": 0.13   // 医药
            }
        };
        
        this.positionSizing = {
            BULL: 1.0,
            BEAR: 0.4,
            RANGE: 0.7
        };
        
        this.regimeHistory = [];
    }

    classify(etfData) {
        if (!etfData || etfData.length === 0) {
            return { state: 'RANGE', score: 0.5, confidence: 0 };
        }

        const total = etfData.length;
        const advancing = etfData.filter(etf => {
            const changePct = etf.change_pct;
            return changePct !== null && changePct !== undefined && changePct > 0;
        }).length;

        const ratio = advancing / total;

        let state = 'RANGE';
        if (ratio >= this.bullThreshold) {
            state = 'BULL';
        } else if (ratio <= this.bearThreshold) {
            state = 'BEAR';
        }

        return {
            state,
            score: ratio,
            confidence: Math.abs(ratio - 0.5) * 2,
            advancing,
            total
        };
    }

    smoothRegime(rawStates) {
        const smoothed = [];
        for (let i = 0; i < rawStates.length; i++) {
            const start = Math.max(0, i - this.smoothingWindow + 1);
            const windowStates = rawStates.slice(start, i + 1);
            
            const counts = {};
            windowStates.forEach(s => {
                counts[s] = (counts[s] || 0) + 1;
            });
            
            const vote = Object.entries(counts).sort((a, b) => b[1] - a[1])[0][0];
            smoothed.push(vote);
        }
        return smoothed;
    }

    getAllocation(regime) {
        return this.allocation[regime] || this.allocation.RANGE;
    }

    getPositionSizing(regime) {
        return this.positionSizing[regime] || 0.7;
    }
}

module.exports = RegimeEngineV3_5;
