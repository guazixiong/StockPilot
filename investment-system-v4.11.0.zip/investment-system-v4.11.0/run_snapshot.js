const RegimeEngineV3_6 = require('./engine/regime_engine_v3.6.js');
const { RiskAnalyzer } = require('./engine/risk_analyzer.js');
const { ExecutionPlanGenerator } = require('./engine/execution_plan.js');
const fs = require('fs');

const snapshot = JSON.parse(fs.readFileSync('./data/market_snapshot.json', 'utf8'));
const etfConfig = JSON.parse(fs.readFileSync('./config/etf.json', 'utf8'));

const etfMap = {};
snapshot.etfs.forEach(e => {
  const code = e.symbol.replace('sh', '').replace('sz', '');
  etfMap[code] = { ...e, code };
});

const portfolioETFs = etfConfig.portfolio.map(p => {
  const data = etfMap[p.code];
  return data ? { ...data, name: p.name, type: p.type } : null;
}).filter(Boolean);

const regimeEngine = new RegimeEngineV3_6();
const regimeResult = regimeEngine.classify(portfolioETFs);
const positionSizing = regimeEngine.getPositionSizing(regimeResult.state);
const allocation = regimeEngine.getAllocation(regimeResult.state);
const stopLoss = regimeEngine.getStopLoss(regimeResult.state);
const riskAnalyzer = new RiskAnalyzer();
const liquidity = riskAnalyzer.assessLiquidity(portfolioETFs);
const executionGen = new ExecutionPlanGenerator({ capital: 1000000 });
const plan = executionGen.generate({
  regime: regimeResult.state, allocation, positionSizing,
  decay: regimeResult.decay, currentPositions: {}, etfData: portfolioETFs,
  stopLoss: stopLoss.default ? { default: stopLoss.default } : stopLoss, liquidity
});
const ranking = regimeEngine.getSectorRanking(portfolioETFs);

const output = { regime: regimeResult, positionSizing, allocation, stopLoss, liquidity, plan, ranking };
console.log(JSON.stringify(output, null, 2));
